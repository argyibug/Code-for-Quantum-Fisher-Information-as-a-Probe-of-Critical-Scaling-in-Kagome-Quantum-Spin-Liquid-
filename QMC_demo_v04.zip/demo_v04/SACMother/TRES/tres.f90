!--------------!
 module cordata
!--------------!

 integer :: nq,nt,nb,nbt,ski,sk_min,sk_max
 integer, allocatable :: ntq(:)
 integer, allocatable :: qlb(:)
 real(8), allocatable :: tau(:),cor(:,:,:),samp(:,:)
 real(8), allocatable :: sqt(:,:),sig(:,:),sq(:)
 integer, allocatable :: key(:)

 end module cordata
!------------------!

!=====================!
 program tcorrelations
!=========================================================!                                                                 
! Do statistics of time correlations stored in 'cor.dat'.
! Write averages and errors to:
! - sq.dat   : static structure factor for each q
! - tq.dat   : time correlations for all times, all q
! - qxxx.dat : normalized time correlations and inverse of
!              covariance matrix for q=xxx 
!----------------------------------------------------------! 
 use cordata; implicit none

 integer :: ns,qq1,qq2,rb
 real(8) :: beta

 open(10,file='qidx.log',status='old')
 read(10,*)nq    !  Number of q-points in file
 close(10)
 !nq=2*nq+1
 print*, nq

 open(10,file='temp.in',status='old')
 read(10,*)beta  !  Beta 
 close(10)

 open(10,file='tres.in',status='old')
 read(10,*)qq1,qq2    !  if 0 do covariance for all q, if not use q only
 read(10,*)nb    !  use number of bins (0=all)
 read(10,*)rb    !  Rebinning factor
 read(10,*)sk_min,sk_max    !  use every sk time point
 read(10,*)nbt   !  number of bootstrap samples
 close(10)

 open(10,file='tres.log',status='replace'); close(10)
 call initran(1)

 allocate(key(1:nq))
 key(:)=0

 call readindata_1(rb)
 call computemeans(0)
 call covariance(1,qq1,qq2,beta)
 call deallocateall

 do ski=sk_min,sk_max
  call readindata(ski,rb)
  call computemeans(1)
  call covariance(0,qq1,qq2,beta)
  call deallocateall
  print*,"checkpoint_1",ski
 enddo

 end program tcorrelations
!=========================!

!-----------------------!
 subroutine computemeans(s)
!-----------------------!
 use cordata; implicit none

 integer :: i,j,s

 allocate(sq(nq))
 allocate(ntq(nq))
 allocate(sqt(0:nt,nq))
 allocate(sig(0:nt,nq))
 allocate(samp(0:nt,0:nbt))

 open(10,file='sq.dat',status='replace')
 open(20,file='tq.dat',status='replace')
 do j=1,nq
    ntq(j)=nt
    call bootstraps(j,0)
    do i=0,nt       
       sqt(i,j)=samp(i,0)
       sig(i,j)=sqrt(sum((samp(i,1:nbt)-samp(i,0))**2)/dble(nbt))
       if (s==1 .and. ntq(j)==nt.and.sig(i,j)/sqt(i,j).gt.0.1d0) then
        ntq(j)=i-1
       endif
    enddo
 enddo
 do j=1,nq
    sq(j)=sqt(0,j)
    write(10,'(i5,2f15.9)')qlb(j),sqt(0,j),sig(0,j)
    write(20,*)j
    do i=0,nt
       write(20,'(3f15.9)')tau(i),sqt(i,j),sig(i,j)
    enddo
 enddo     
 close(10)
 close(20)

 end subroutine computemeans
!---------------------------!

!------------------------------!
 subroutine covariance(s,qq1,qq2,beta)
!------------------------------!
 use cordata; implicit none

 integer :: i,j,k,n,q,q1,q2,qq1,qq2,i1,i2,i3,ie,s
 real(8) :: beta
 character(8) :: fname

 real(8), allocatable :: cov(:,:),ss0(:)

 allocate(cov(nt,nt))
 allocate(ss0(nt))

  if(s.ne.1) then
    fname='q000.dat'
    if (qq1*qq2==0) then
      q1=1
      q2=nq
    else
      q1=qq1
      q2=qq2
    endif

    do q=q1,q2
      n=ntq(q)
      i3=qlb(q)/100
      i2=mod(qlb(q),100)/10
      i1=mod(qlb(q),10)
      fname(4:4)=achar(48+i1)
      fname(3:3)=achar(48+i2)
      fname(2:2)=achar(48+i3)

      call bootstraps(q,1)    
      do i=1,n       
        sqt(i,q)=samp(i,0)
        sig(i,q)=sqrt(sum((samp(i,1:nbt)-samp(i,0))**2)/dble(nbt))
      enddo
      call computecov(n,cov(1:n,1:n))
      call diasym(cov(1:n,1:n),ss0(1:n),n)

      if (key(q)==0) then
        if (ss0(1) > 0 .or. ski==sk_max) then
          open(10,file=fname,status='replace')
          write(10,'(f12.3,2i8,2f16.10)')beta,ntq(q),nbt,sq(q)
          do i=1,n
            write(10,'(f13.9,4f20.15)')tau(i),sqt(i,q),sig(i,q),sqrt(ss0(i)/nbt)
          enddo
          do j=1,n
            write(10,*)j
            do i=1,n
              write(10,*)cov(i,j)
            enddo
          enddo
          key(q)=ski
        endif
      endif
    enddo
    open(10,file="step.log",status='replace')
    do i=1,nq
      write(10,'(2i8)')i,key(i)
    enddo

  else
    fname='t000.dat'
    if (qq1*qq2==0) then
      q1=1
      q2=nq
    else
      q1=qq1
      q2=qq2
    endif
    do q=q1,q2
      n=ntq(q)
      i3=qlb(q)/100
      i2=mod(qlb(q),100)/10
      i1=mod(qlb(q),10)
      fname(4:4)=achar(48+i1)
      fname(3:3)=achar(48+i2)
      fname(2:2)=achar(48+i3)
      call bootstraps(q,1)    
      do i=1,n       
        sqt(i,q)=samp(i,0)
        sig(i,q)=sqrt(sum((samp(i,1:nbt)-samp(i,0))**2)/dble(nbt))
      enddo
      open(10,file=fname,status='replace')
      do i=1,n
        write(10,'(f13.9,4f20.15)')tau(i),sqt(i,q),sig(i,q)
      enddo
    enddo
  endif

  deallocate(ss0)
  deallocate(cor)

 end subroutine covariance
!-------------------------!

!----------------------------!
 subroutine computecov(n,cov)
!----------------------------!
 use cordata; implicit none

 integer :: i,j,n
 real(8) :: cov(n,n)

 do j=1,n
 do i=1,n
    cov(i,j)=sum((samp(i,1:nbt)-samp(i,0))*(samp(j,1:nbt)-samp(j,0)))
 enddo
 enddo  

 end subroutine computecov
!-------------------------!

!-----------------------------!
 subroutine bootstraps(q,norm)
!-------------------------------------------!
! Generates nb bootstrap samples for given q
! Normalize to 1 at tau=0 if nr==1
!-------------------------------------------!
 use cordata; implicit none

 integer :: i,j,r,q,norm

 real(8), external :: ran

 samp=0.d0
 do i=1,nb
    samp(:,0)=samp(:,0)+cor(:,i,q)
 enddo
 do j=1,nbt
 do i=1,nb
    r=int(ran()*dble(nb))+1
    samp(:,j)=samp(:,j)+cor(:,r,q)
 enddo
 enddo
 samp=samp/dble(nb)
 if (norm==1) samp=samp/sq(q)

 end subroutine bootstraps
!-------------------------!

!---------------------------!
 subroutine readindata(s,rb)
!---------------------------!
 use cordata; implicit none

 integer :: i,j,k,b,q,s,u,nu,rb,kk,n
 real(8) :: c,beta
 real(8), external :: sample
 real(8), external :: ran

 integer, allocatable :: pre_selected_point(:)
 integer, allocatable :: selected_point(:)
 

 open(10,file='tgrid.in',status='old')
 read(10,*)nt
 allocate(pre_selected_point(0:nt))
 pre_selected_point(:)=-2
 nu=-1
 n=0
 do i=0,nt
    read(10,*)c
    if (ran()<=sample(s,i)) then
       nu=nu+1
       pre_selected_point(n)=i
       n=n+1
    endif
 enddo
 rewind(10)
 read(10,*)nt
 allocate(tau(0:nu))
 allocate(selected_point(0:n))

 n=0
 do i=0,nt
 	if (pre_selected_point(n)>=0) then
 		selected_point(n)=pre_selected_point(i)
 		n=n+1
 	endif
 enddo
 deallocate(pre_selected_point)

 nu=-1
 n=0
 do i=0,nt
    read(10,*)c
    if (i==selected_point(n)) then
       n=n+1
       nu=nu+1
       tau(nu)=c
    endif
 enddo

 allocate(qlb(1:nq))
 open(10,file='tcor.in',status='old') 
 b=0
 do 
    do j=1,nq
       read(10,*,end=10)q
       qlb(j)=q
       do i=0,nt
          read(10,*)c
       enddo
    enddo
    b=b+1
 enddo
 10 rewind(10)
 if (nb==0) then
    nb=b
 else
    nb=min(b,nb)
 endif
 nb=(nb-mod(nb,rb))/rb
 allocate(cor(0:nu,nb,0:nq)); cor=0.d0
 do k=0,rb*nb-1
    kk=1+k/rb
    do j=1,nq
       read(10,*)q
       u=-1
       n=0
       do i=0,nt
          read(10,*)c
          if (i==selected_point(n)) then
          	 n=n+1
             u=u+1
             cor(u,kk,j)=cor(u,kk,j)+c
          endif
       enddo
       n=0
    enddo
 enddo
 close(10)
 cor=cor/dble(rb)
 nt=nu
 deallocate(selected_point)

 open(10,file='tres.log',position='append')
 write(10,*)'Number of bins read      : ',b
 write(10,*)'Using number of bins     : ',nb*rb
 write(10,*)'Rebinned to              : ',nb
 write(10,*)'Number of times          : ',nt
 close(10)
 
 end subroutine readindata
!-------------------------!

!---------------------------!
 subroutine readindata_1(rb)
!---------------------------!
 use cordata; implicit none

 integer :: i,j,k,b,q,s,u,nu,rb,kk
 real(8) :: c,beta
 s=1

 open(10,file='tgrid.in',status='old')
 read(10,*)nt
 nu=-1
 do i=0,nt
    read(10,*)c
    if (mod(i,s)==0) then
       nu=nu+1
    endif
 enddo
 rewind(10)
 read(10,*)nt
 allocate(tau(0:nu))
 nu=-1
 do i=0,nt
    read(10,*)c
    if (mod(i,s)==0) then
       nu=nu+1
       tau(nu)=c
    endif
 enddo

 allocate(qlb(1:nq))
 open(10,file='tcor.in',status='old') 
 b=0
 do 
    do j=1,nq
       read(10,*,end=10)q
       qlb(j)=q
       do i=0,nt
          read(10,*)c
       enddo
    enddo
    b=b+1
 enddo
 10 rewind(10)
 if (nb==0) then
    nb=b
 else
    nb=min(b,nb)
 endif
 nb=(nb-mod(nb,rb))/rb
 allocate(cor(0:nu,nb,0:nq)); cor=0.d0
 do k=0,rb*nb-1
    kk=1+k/rb
    do j=1,nq
       read(10,*)q
       u=-1
       do i=0,nt
          read(10,*)c
          if (mod(i,s)==0) then
             u=u+1
             cor(u,kk,j)=cor(u,kk,j)+c
          endif
       enddo
    enddo
 enddo
 close(10)
 cor=cor/dble(rb)
 nt=nu
 
 end subroutine readindata_1
!-------------------------!

!---------------------------!
 subroutine diasym(aa,eig,n)
!---------------------------!
 implicit none

 integer :: n,l,inf
 real(8) ::  aa(n,n),eig(n),work(n*(3+n/2))

 l=n*(3+n/2)
 call dsyev('V','U',n,aa,n,eig,work,l,inf)

 end subroutine diasym
!---------------------!

!----------------------!
 real(8) function ran()
!----------------------------------------------!
! 64-bit congruental generator                 !
! iran64=oran64*2862933555777941757+1013904243 !
!----------------------------------------------!
 implicit none

 real(8)    :: dmu64
 integer(8) :: ran64,mul64,add64
 common/bran64/dmu64,ran64,mul64,add64

 ran64=ran64*mul64+add64
 ran=0.5d0+dmu64*dble(ran64)

 end function ran
!----------------!

!---------------------!
 subroutine initran(w)
!---------------------!
 implicit none

 integer(8) :: irmax
 integer(4) :: w,nb,b

 real(8)    :: dmu64
 integer(8) :: ran64,mul64,add64
 common/bran64/dmu64,ran64,mul64,add64
      
 irmax=2_8**31
 irmax=2*(irmax**2-1)+1
 mul64=2862933555777941757_8
 add64=1013904243
 dmu64=0.5d0/dble(irmax)

 open(10,file='seed.in',status='old')
 read(10,*)ran64
 close(10)
 if (w.ne.0) then
    open(10,file='seed.in',status='unknown')
    write(10,*)abs((ran64*mul64)/5+5265361)
    close(10)
 endif

 end subroutine initran
!----------------------!

!---------------------!
subroutine deallocateall()
  use cordata; implicit none

  deallocate(sq)
  deallocate(ntq)
  deallocate(sqt)
  deallocate(sig)
  deallocate(samp)
  deallocate(tau)
  deallocate(qlb)

end subroutine deallocateall
!----------------------!

 real(8) function sample(s,n)
!----------------------------------------------!
!-scaling function-!
!----------------------------------------------!
  use cordata; implicit none

 integer :: s,n
 !sample=log(s*n*1.0+1)
 
 if (mod(n,s)==0) then
 	sample=1
 else
 	!sample=1/(1+exp(-(n-40)*1.0))
 	sample=0
 endif
 end function sample

!----------------------------------------------!
