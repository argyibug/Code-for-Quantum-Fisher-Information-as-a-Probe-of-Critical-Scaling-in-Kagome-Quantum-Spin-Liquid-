#!/bin/bash

for (( i=1; i<=13; i++ )); do
	cd $i
	if [ -f "t.in" ];then		
		#yhrun -n 1 a.out&
		./a.out
	else
		echo $i
		cp -f ../FakeSw.in sw.dat
		cp -f ../FakeQfi.in qfi.dat
	fi
	pwd
	cat qfi.dat >> ../qfi_all.dat
	cd ../
done
wait
exit 0
