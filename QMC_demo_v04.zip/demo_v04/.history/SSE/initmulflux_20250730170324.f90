module configuration
!----------------------------------------------!
! Most important parameters and data structures
!----------------------------------------------!
 save

 integer :: lx0
 integer :: ly0
 integer :: lz0
 integer :: lx
 integer :: ly
 integer :: lz
 integer :: nn0    ! number of sites
 integer :: nn    ! number of sites
 integer :: nb    ! number of bonds
 integer :: mm    ! total string length (mm=ns*ms)
 integer :: ns    ! number of substrings (time slices)
 integer :: mxl
 integer :: dxl
 !integer :: ms    ! maximum sub-string length
 integer :: tstp
 integer :: bincounter
 integer :: basis
 integer :: ntau
 integer :: nbs
 integer :: ofcc
 integer :: bb0
 integer :: bb1
 integer :: bb2

 integer :: clb_cur
 integer :: clb_nxt

 integer :: nms0
 integer :: bcty
 real(8) :: nhe1
 real(8) :: nhe2
 real(8) :: mag1
 real(8) :: mag2
 real(8) :: auen
 real(8) :: culg
 real(8) :: addele

 integer :: nms1=0
 integer :: nms2=0
 integer :: nms3=0

 real(8) :: beta  ! inverse temperature
 real(8) :: bet0  ! inverse temperature
 real(8) :: prob ! part of the acceptance probability for adding (removing) operator
 real(8) :: pbAc
 real(8) :: pbBs
 real(8) :: pbjp
 real(8) :: pbCn
 real(8) :: Ac0
 real(8) :: Bs0
 real(8) :: jp0
 real(8) :: hz0
 real(8) :: temp0
 real(8) :: temp1
 real(8) :: ntem
 real(8) :: dtem
 real(8) :: qastep
 real(8) :: lgstep
 real(8) :: Ac1
 real(8) :: Bs1
 real(8) :: jp1
 real(8) :: hz1
 real(8) :: Ac
 real(8) :: Bs
 real(8) :: jp
 real(8) :: hz
 real(8) :: dtau
 real(8) :: slpb
 real(8) :: slprob
 real(8) :: clustersize
 real(8) :: expb
 integer :: updtyp
 integer :: sitnum
 integer :: nnn
 integer :: bondmaker
 integer :: clustersignal
 integer, allocatable :: legn(:,:)
 integer :: nq
 integer :: nq_all
 integer :: cluster_lunch
 integer :: verdeg
 integer :: bonddeg
 integer :: grpbondnum
 integer :: btn
 integer :: grpbondepth
 real(8) :: time0
 real(8) :: time1
 
 integer, allocatable :: bondtab(:,:,:)
 integer, allocatable :: bondgrp(:,:,:)
 integer, allocatable :: vexgrptab(:,:,:,:,:)
 integer, allocatable :: vextag(:,:,:,:,:)
 integer, allocatable :: spingrpidx(:,:,:,:,:,:,:)
 integer, allocatable :: spingrploc(:,:)
 integer, allocatable :: spacevisit(:)
 integer, allocatable :: spingrptab(:,:,:,:,:,:,:)
 integer, allocatable :: spingrp(:,:,:)
 integer, allocatable :: loopgrploc(:)
 integer, allocatable :: bondchain(:,:)
 integer, allocatable :: hexagon(:,:,:)

 integer, allocatable :: parbok(:)
 real(8), allocatable :: parset(:,:)

 integer, allocatable :: ratab(:)
 integer, allocatable :: opvlog(:,:)
 integer, allocatable :: clusterflog(:,:)
 integer :: clusterbtm
 integer :: clusterdim
 integer :: clusterdimax

 real(8), allocatable :: weightable(:,:,:)

 integer, allocatable :: opstfp(:,:)
 integer, allocatable :: betable(:)
 integer, allocatable :: clustervislog(:,:)

 integer :: nh
 integer :: nh1
 integer :: nh2
 integer :: nh3
 integer :: nh4

 integer :: legcon
 integer :: legtot

 real(8) :: aclpre
 real(8) :: aclcrr

 !integer, allocatable :: nhpm(:,:)
 !integer, allocatable :: nhtp(:)

 integer, allocatable :: spin(:)
 integer, allocatable :: bsites(:,:)
 integer, allocatable :: sambon(:)
 integer, allocatable :: bontab(:)
 integer, allocatable :: opstring(:)
 integer, allocatable :: oporder(:)
 integer, allocatable :: tauscale(:)
 integer, allocatable :: vertexspin(:,:)
 integer, allocatable :: bondidx(:,:)
 !integer, allocatable :: opcluster(:,:)

 integer, allocatable :: frstspinop(:)
 integer, allocatable :: lastspinop(:)
 integer, allocatable :: vertexlist(:,:)
 integer, allocatable :: vertexlist_map(:)
 integer, allocatable :: opertyp(:)
 integer, allocatable :: dealtyp(:)
 integer, allocatable :: offoporder(:)
 integer, allocatable :: digoporder(:)
 real(8), allocatable :: rantau(:)
 integer, allocatable :: recorder(:,:)
 
 integer :: loop_eff_count
 integer :: loop_tot_count

 character(11) :: culgname
 character(11) :: loopname
 character(11) :: heauname

 real(8), parameter :: pi=3.14159265358979323d0
 real(8), parameter :: ex=2.71828182845904523d0

end module configuration

module measurementdata
 !--------------------------------------------!
 !Data we measured
 !--------------------------------------------!
 save

 real(8) :: enrg1=0.d0
 real(8) :: enrg2=0.d0
 real(8) :: amag1=0.d0
 real(8) :: amag2=0.d0
 real(8), allocatable :: bind1(:)
 real(8), allocatable :: bind2(:)
 real(8) :: tmag1=0.d0

 real(8), allocatable :: crr(:,:,:,:)      !correlation function in real space

 integer, allocatable :: qpts(:)    !list of q-points

 real(8), allocatable :: tcAc(:,:)    !correlation function in momentum space
 real(8), allocatable :: tc(:)
 real(8), allocatable :: ref(:,:)     ! real part of fourier transform of spins
 real(8), allocatable :: imf(:,:)      ! imaginary part of fourier transform of spins
 real(8), allocatable :: phi(:,:,:)   ! phase factors for fourier transforms
 real(8), allocatable :: cbbkgd(:)
 real(8), allocatable  :: ssbkgd(:)
 real(8), allocatable :: axie(:,:)

 real(8), allocatable :: stiff(:)


 integer, allocatable :: tgrd(:)    !grid of time points
 
 real(8), allocatable :: tcor(:,:)    !correlation function in momentum space
 real(8), allocatable :: tcorpm(:,:)    !correlation function in momentum space
 
 real(8), allocatable :: PMRS_temp(:,:,:,:)
 real(8), allocatable :: RealSpace(:,:,:,:)
 real(8), allocatable :: PMinRealSpace(:,:,:,:)
 real(8), allocatable :: demo_or(:,:,:,:)
 real(8), allocatable :: demo_pm(:,:,:,:)
 
 integer :: nc
 integer :: nf

 character(10) :: resname
 character(10) :: sffname
 character(10) :: bidname
 character(10) :: crrname
 character(11) :: tcAcname
 character(11) :: backname
 character(11) :: tcorname
 character(11) :: tcpmname
 character(11) :: tcdmname
 character(11) :: deorname
 character(11) :: depmname
 character(11) :: autoname
 character(11) :: etlgname

end module measurementdata

!==========================!
!main part of the programme!
!==========================!
! nn     =  number of spins
! beta   =  inverse temperature
! nbin   =  number of bins
! mstps  =  steps per bin for measurements
! istps  =  initial (equlibration) steps 

module vertexupdate
   save
   integer :: v0
   integer :: OpTy0
   integer :: site0
   integer :: v1
   integer :: v2
   integer :: vh0
   integer :: vh1
   integer :: vh2
   integer :: vht

   integer, allocatable :: x0(:)
   integer, allocatable :: x1(:)
   integer, allocatable :: x2(:)
   integer, allocatable :: vc(:,:)
   integer, allocatable :: xrelation(:,:)
   integer :: cerberus_flag
   integer :: bx
   integer :: opx
   integer, allocatable :: ix(:,:)
   integer :: iv

   integer :: looppm

   integer :: vt
   integer :: mmt
   integer :: bt
   integer :: opt
   integer :: udt
   integer :: typt
   integer :: sigt
   integer :: dealtyp_t

   integer :: lp
   integer :: lpdim
   integer :: lpdimax
   integer :: vdimcutoff
   integer :: vertexdim
   integer :: mvstep

   integer :: mm0
   integer :: b0
   integer :: op0
   integer :: ud0
   integer :: typ0
   integer :: sig0
   integer :: dltyp0
   integer :: nia

   integer :: length
   integer :: clustermark
   integer :: marker
   integer :: mrk0
   integer :: mrk1
   integer :: selfcest
   integer, allocatable :: cmplsg(:)
   integer :: update_counter
   integer :: cluster_counter
   integer :: counter
   integer :: dcounter
   integer :: ocounter
   integer :: probnum

   integer :: Spm_measure_signal
   integer :: OpTy1
   integer :: site1

   integer :: b
   integer :: op
   integer :: loop_counter

   integer :: vv
   integer :: dealtyp_v
   integer :: mmv

   integer :: udmrr
   integer :: rlmrr
   integer :: index_bp

   integer, allocatable :: pbcgcnt(:,:)
   integer, allocatable :: legtab(:,:)

   real(8) :: wgtaft
   real(8) :: wgtbfr
   real(8) :: totalwgt
   integer, allocatable :: state_leg(:,:)

   real(8) :: tau0
   real(8) :: delta_tau
   real(8), allocatable  :: dmweight(:)
   real(8), allocatable  :: fluxtable(:,:,:,:,:,:,:)
   real(8), allocatable :: fluxsut(:,:,:,:,:,:)
   integer, allocatable :: fluxnum(:,:,:,:,:,:)

end module vertexupdate

program initmulflux

   use configuration
   use measurementdata
   use vertexupdate
   implicit none
   integer :: ierr,nprocs,i1,i2,i3,a1,a2,a3,cerberus_signal
   integer :: njp,nhz,annealing_signal
   real(8) :: dhz,djp
   integer :: rank,btidx,comm
   integer :: i,j,k,r,l,nbins,msteps,isteps,tmsr,gtype,bsteps,dstep,xbins,cur_step
   integer :: pidx1,pidx2,nhtmp1,nhtmp2,idx1,idx2,aimproc,xsign,total_step,crr_step
   integer :: nhp1p1,nhn1p1,nhp2p1,nhn2p1,nhp1p2,nhn1p2,nhp2p2,nhn2p2,lt
   integer, allocatable :: extendhappen(:)
   real(8) :: jojo,beta_pev,beta_crr,en_crr,Ac_min,en_per,mg_crr,mg_per,m2_crr,m2_per
   real(8) :: tmax
   real(8), external :: ran

   o
   open(unit=10, file='read.in', status="old")
   read(10,*)lx0,ly0,bcty
   read(10,*)Ac0,nnn
   read(10,*)slprob
   read(10,*)Ac1
   read(10,*)qastep,lgstep
   read(10,*)nbins,msteps,isteps
   read(10,*)xbins,bsteps
   read(10,*)dtau
   read(10,*)gtype,tmax
   read(10,*)tstp,tmsr
   close(unit=10)
   time0=0d0
   time1=0d0

   Bs0=0d0
   Bs1=0d0
   bondmaker=0
   Spm_measure_signal=0d0
   cerberus_signal=0
   annealing_signal=1

   open(unit=10, file='temp_an.in', status="old")
   read(10,*)temp0
   read(10,*)temp1
   read(10,*)ntem
   close(unit=10)
   dtem=(temp1-temp0)/dble(ntem)
   bet0=temp1
   if (temp0==temp1) then
      beta=temp1
      ntem=0d0
   endif
   tmax=beta*0.5d0

   open(unit=10, file='jp.in', status="old")
   read(10,*)jp0
   read(10,*)jp1
   read(10,*)djp
   close(unit=10)
   njp=int((jp1-jp0)/dble(djp))
   if (jp0==jp1) then
      jp=jp0
      njp=0d0
   endif

   open(unit=10, file='hz.in', status="old")
   read(10,*)hz0
   read(10,*)hz1
   read(10,*)dhz
   close(unit=10)
   nhz=int((hz1-hz0)/dble(dhz))
   if (hz0==hz1) then
      hz=hz0
      nhz=0d0
   endif
   
   open(unit=10, file='jzz.in', status="old")
   read(10,*)jzz0
   read(10,*)jzz1
   read(10,*)djzz
   close(unit=10)
   njzz=int((jzz1-jzz0)/dble(djzz))
   if (jzz0==jzz1) then
      jzz=jzz0
      njzz=0d0
   endif

   basis=0d0

   lx=lx0
   ly=ly0
   nn0=3*lx0*ly0
   beta=bet0
   Ac=Ac0
   jp=jp0
   hz=hz0
   jzz=jzz0

   call makelattice()
   call initconfig(0,nprocs)

end program initmulflux

!==================================================!

!==================================================!

subroutine initconfig(rank,nprocs)
   use configuration
   use measurementdata
   implicit none

   integer :: i,j,s,x,i1,i2,i3
   integer :: rank,nprocs
   real(8) :: rate,bmin,Acmin,Bsmin,jpmin,hzmin
   real(8), external :: ran

   print*,"initweight"
   call initweight(1,1,1,nprocs)
   print*,"initflux"
   call initfluxmul(0,0)

end subroutine initconfig
!==================================================!
!==================================================!

subroutine makelattice()
   use configuration
   implicit none
   integer :: s,x1,x2,y1,y2,z1,z2,index,i
   integer :: s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,bt,bc
   integer :: s11,s12,s13,s14,s15,s16,s17,s18,s19,s20
   integer :: s21,s22,s23,s24,s25,bmk
   integer :: xx1,xx2,xx3,xx4,yy1,yy2,yy3,yy4
   integer :: numbd

   bondmaker=0

   allocate(legn(4,2))

   nn=lx*ly
   print*,nn,lx,ly
   bc=0d0
   pbAc=0d0
   pbBs=0d0
   pbCn=0d0

   if (bondmaker==0) then
      nb=6*nn
      mxl=5
      numbd=6-1
      bonddeg=1
   endif
   dxl=2*mxl
   
   allocate(bsites(mxl,nb))
   allocate(sambon(nb))
   sambon(:)=-1d0
   allocate(bontab(nb))
   bontab(:)=-1d0
   bsites(:,:)=-1
   do x1=0,lx-1
      do y1=0,ly-1
         s=1+x1+y1*lx

         s1=1+mod(x1+0+lx,lx)+mod(y1+0+ly,ly)*lx
         s2=1+mod(x1+0+lx,lx)+mod(y1+1+ly,ly)*lx
         s3=1+mod(x1-1+lx,lx)+mod(y1+1+ly,ly)*lx
         s4=1+mod(x1-1+lx,lx)+mod(y1+0+ly,ly)*lx
         s5=1+mod(x1+0+lx,lx)+mod(y1-1+ly,ly)*lx
         s6=1+mod(x1+1+lx,lx)+mod(y1-1+ly,ly)*lx
         s7=1+mod(x1+1+lx,lx)+mod(y1+0+ly,ly)*lx

         if (bondmaker==0) then
            bmk=0d0
            bsites(1,s+bmk*nn)=s1
            bsites(2,s+bmk*nn)=s1+1*nn
            bsites(3,s+bmk*nn)=s1+2*nn
            bsites(4,s+bmk*nn)=s7
            bsites(5,s+bmk*nn)=s2
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=1d0
            bsites(1,s+bmk*nn)=s1+1*nn
            bsites(2,s+bmk*nn)=s1+2*nn
            bsites(3,s+bmk*nn)=s1+0*nn
            bsites(4,s+bmk*nn)=s3+1*nn
            bsites(5,s+bmk*nn)=s4+1*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=2d0
            bsites(1,s+bmk*nn)=s1+2*nn
            bsites(2,s+bmk*nn)=s1+0*nn
            bsites(3,s+bmk*nn)=s1+1*nn
            bsites(4,s+bmk*nn)=s5+2*nn
            bsites(5,s+bmk*nn)=s6+2*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=3d0
            bsites(1,s+bmk*nn)=s1+0*nn
            bsites(2,s+bmk*nn)=s4+1*nn
            bsites(3,s+bmk*nn)=s5+2*nn
            bsites(4,s+bmk*nn)=s4+0*nn
            bsites(5,s+bmk*nn)=s5+0*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=4d0
            bsites(1,s+bmk*nn)=s1+1*nn
            bsites(2,s+bmk*nn)=s6+2*nn
            bsites(3,s+bmk*nn)=s7+0*nn
            bsites(4,s+bmk*nn)=s6+1*nn
            bsites(5,s+bmk*nn)=s7+1*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=5d0
            bsites(1,s+bmk*nn)=s1+2*nn
            bsites(2,s+bmk*nn)=s2+0*nn
            bsites(3,s+bmk*nn)=s3+1*nn
            bsites(4,s+bmk*nn)=s2+2*nn
            bsites(5,s+bmk*nn)=s3+2*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1
         endif

!+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

      enddo
   enddo
   sitnum=nn
   nn=3*nn
   nbs=bc
   print*,nbs,nb,nn,sitnum,pbAc,pbBs,pbCn
   !pause

   if (bondmaker==0) then
      legn(1,1)=2
      legn(1,2)=2**5-1
      legn(2,1)=2
      legn(2,2)=2**2-1
      legn(3,1)=1
      legn(3,2)=2**1-1
      legn(4,1)=2
      legn(4,2)=2**2-1
   endif

   verdeg=2**(mxl)-1
   allocate(spingrploc(nb,0:3))
   spingrploc(nb,:)=0d0
   allocate(spacevisit(nb))
   spacevisit(:)=0d0
   allocate(loopgrploc(nb))
   loopgrploc(nb)=1d0
   allocate(bondchain(nb,0:2))

end subroutine makelattice
!==================================================!

!==================================================!

subroutine initfluxmul(signal,rank)
!-----------------------------------------------------------!
! phase factors for fourier transforms of spin configuration
!-----------------------------------------------------------!
 use configuration
 use vertexupdate
 implicit none

 integer :: signal,typ,cur0,cur1,rank,option,mu_mark,notzero
 integer :: leg_in_0,leg_in_1,leg_out_0,leg_out_1,leg_out_idx,leg_in_idx
 integer :: i,j,k,l,cur2,cur3,leg_tmp,leg_tmp1,idx_in,idx_out,fluxbuild_typ
 integer :: v_dim,dim_dxl,flux_idx,flux_cage,flux_sign,max_cage,max_type
 real(8) :: w0,w2,w1,jptmp,w3,weight_tmp,weight_tmp1,dd,totalweight
 integer, allocatable :: state(:,:)
 integer, allocatable :: idx(:)
 integer, allocatable :: visit(:)
 real(8), allocatable :: delta(:,:)
 real(8), allocatable :: delta_tmp(:,:)
 integer, allocatable :: leg_in(:)
 integer, allocatable :: leg_out(:)
 real(8), allocatable :: loadtab(:)
 integer, allocatable :: loadnum(:)
 real(8), allocatable  :: fluxtamul(:,:,:,:,:)
 character(11) :: fluxname

 allocate(loadtab(0:verdeg+1))
 allocate(loadnum(0:verdeg+1))

 lpdim=3
 lpdimax=min(lpdim,3)
 !lpdimax>=4 no enough memory
 vertexdim=dxl**lpdimax

 allocate(state(0:dxl-1,0:1))
 allocate(delta(0:vertexdim-1,0:3))
 allocate(delta_tmp(0:vertexdim-1,0:3))
 allocate(idx(0:vertexdim-1))
 allocate(visit(0:mxl-1))
 allocate(leg_in(0:lpdimax-1))
 allocate(leg_out(0:lpdimax-1))
 delta(:,:)=0d0
 state(:,:)=0d0
 
 fluxbuild_typ=0d0 ! BC not DBC
 !fluxbuild_typ=1d0 ! heat bath
 !fluxbuild_typ=2d0 ! Mp
 print*, "fluxmul",lpdim

 if (signal==0) then
   allocate(fluxtamul(0:verdeg,0:verdeg,0:vertexdim-1,0:vertexdim-1,2))
   print*, "fluxmul",lpdim
   allocate(x0(lpdim))
   allocate(x1(lpdim))
   allocate(x2(lpdim))
   allocate(vc(lpdim,0:3))
   allocate(xrelation(lpdim,lpdim))
   allocate(ix(0:lpdim,0:2))
   allocate(state_leg(0:dxl-1,0:1))
 endif
 fluxtamul(:,:,:,:,:)=0d0
 max_cage=0
 max_type=0
 !print*, "fluxmul"
 
 do mu_mark=1,lpdimax
   !print*, "mu_mark",mu_mark
   v_dim=dxl**mu_mark

   deallocate(fluxtamul)
   allocate(fluxtamul(0:verdeg,0:verdeg,0:v_dim-1,0:v_dim-1,2))

   !print*, "fluxmul"
   do typ=1,1
      do cur0=0,verdeg
         do cur1=0,verdeg
            !print*,"cur",cur0,cur1
            if (weightable(cur0,cur1,typ)==0d0) cycle
            do i=0,mxl-1
               state(i,0)=(mod(int(cur0/(2**(i))),2))*2-1
               state(i+mxl,0)=(mod(int(cur1/(2**(i))),2))*2-1
            enddo
            
            do leg_in_idx=0,v_dim-1
               !print*, "leg_in_idx",leg_in_idx
               state(:,1)=state(:,0)

               leg_in_0=leg_in_idx
               do j=1,mu_mark
                  dim_dxl=dxl**(j-1)
                  leg_in(j-1)=mod(int(leg_in_0/dim_dxl),dxl)
                  state(leg_in(j-1),1)=-state(leg_in(j-1),1)
               enddo
               !print*, "leg_in",leg_in_idx,leg_in(:)
               delta(:,:)=-1d0
               totalweight=0d0

               do leg_out_idx=0,v_dim-1
                  leg_out_0=leg_out_idx
                  do j=1,mu_mark
                     dim_dxl=dxl**(j-1)
                     leg_out(j-1)=mod(int(leg_out_0/dim_dxl),dxl)
                     state(leg_out(j-1),1)=-state(leg_out(j-1),1)
                  enddo
                  !print*, "leg_out",leg_out_idx,leg_out(:)
                  
                  cur2=0d0
                  cur3=0d0
                  do i=0,mxl-1
                     cur2=cur2+int((state(i,1)+1)*0.5d0)*2**(i)
                     cur3=cur3+int((state(i+mxl,1)+1)*0.5d0)*2**(i)
                  enddo
                  weight_tmp=weightable(cur2,cur3,typ)
                  leg_tmp=leg_out_idx

                  if (fluxbuild_typ==0) then
                     do i=0,v_dim-1
                        if (delta(i,1)==-1d0) then
                           delta(i,1)=weight_tmp
                           delta(i,0)=leg_tmp
                           exit
                        else
                           if (weight_tmp>delta(i,1)) then
                              weight_tmp1=delta(i,1)
                              leg_tmp1=delta(i,0)
                              delta(i,1)=weight_tmp
                              delta(i,0)=leg_tmp
                              weight_tmp=weight_tmp1
                              leg_tmp=leg_tmp1
                           else
                           endif
                        endif
                     enddo
                  elseif (fluxbuild_typ==1) then
                     delta(leg_out_idx,1)=weight_tmp
                     delta(leg_out_idx,0)=leg_tmp
                     totalweight=totalweight+weight_tmp
                  endif
                  
                  do j=1,mu_mark
                     state(leg_out(j-1),1)=-state(leg_out(j-1),1)
                  enddo
               enddo

               !print*, "---------------------------------"
               !print*, delta(:,1)
               notzero=0d0
               do i=0,v_dim-1
                  if (delta(i,1)/=0d0) then
                     notzero=notzero+1
                     delta_tmp(i,:)=delta(i,:)
                  else
                     exit
                  endif
               enddo
               do i=1,notzero-1
                  delta(i,:)=delta_tmp(notzero-i,:)
               enddo
               !print*, delta(:,1)

               if (fluxbuild_typ==0) then
                  !print*, leg_in_idx,leg_out_idx,cur0,cur1
                  !print*, delta(:,0)
                  !print*, delta(:,1)
                  !pause
                  delta(0,2)=delta(0,1)
                  do i=0,v_dim-1
                     idx(int(delta(i,0)))=i
                     delta(i,2)=delta(i-1,2)+delta(i,1)
                  enddo
                  !print*, idx(:)
                  !print*, delta(:,0)
                  !print*, "---------------------------------"
                  
                  idx_in=idx(leg_in_idx)
                  loadnum(verdeg+1)=0
                  !print*, weightable(cur0,cur1,typ),delta(idx_in,1)
                  do i=0,v_dim-1
                     leg_out_idx=int(delta(i,0))
                     idx_out=idx(leg_out_idx)

                     dd=delta(idx_in,2)-delta(mod(idx_out-1+v_dim,v_dim),2)+delta(0,1)
                     w0=dd
                     !print*,"0",w0,dd
                     w0=min(w0,delta(idx_in,1)+delta(idx_out,1)-dd)
                     !print*,"1",w0,delta(idx_in,1)+delta(idx_out,1)-dd
                     w0=min(w0,delta(idx_in,1))
                     !print*,"2", w0,delta(idx_in,1)
                     w0=min(w0,delta(idx_out,1))
                     !print*,"3", w0,delta(idx_out,1)
                     w0=max(w0,0d0)
                     fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,1)=w0
                     
                     flux_idx=loadnum(verdeg+1)-1
                     if (w0/=0d0) then
                        !print*, "w0",w0,loadnum(verdeg+1)
                        if (flux_idx==-1) then
                           loadnum(verdeg+1)=loadnum(verdeg+1)+1
                           flux_idx=loadnum(verdeg+1)-1
                           loadtab(flux_idx)=w0
                           loadnum(flux_idx)=1
                           max_cage=max(max_cage,loadnum(flux_idx))
                        else
                           flux_sign=0
                           do j=0,flux_idx
                              !print*, "loadtab",j,loadtab(j),w0,loadtab(j)==w0
                              if (loadtab(j)==w0) then
                                 flux_sign=1
                                 flux_idx=j
                                 loadnum(flux_idx)=loadnum(flux_idx)+1
                                 max_cage=max(max_cage,loadnum(flux_idx))
                                 exit
                              endif
                           enddo
                           if (flux_sign==0) then
                              loadnum(verdeg+1)=loadnum(verdeg+1)+1
                              flux_idx=loadnum(verdeg+1)-1
                              loadtab(flux_idx)=w0
                              loadnum(flux_idx)=1
                              max_cage=max(max_cage,loadnum(flux_idx))
                           endif
                        endif
                        max_type=max(max_type,loadnum(verdeg+1))
                     endif
                  enddo
                  !print*, "flux_idx",cur0,cur1
                  !print*, "flux_idx",loadnum(verdeg+1)!,loadtab(0:loadnum(verdeg+1)-1),loadnum(0:loadnum(verdeg+1)-1)
                  !print*, "flux_idx",max_type,max_cage
                  !print*,"---------------------------------"
                  if (weightable(cur0,cur1,typ)-sum(fluxtamul(cur0,cur1,leg_in_idx,:,1))>=0.00001d0) then
                     print*, "NBC error 0",weightable(cur0,cur1,typ),sum(fluxtamul(cur0,cur1,leg_in_idx,:,1))
                     print*,"----------------------------------------------"
                     pause
                  endif
               elseif (fluxbuild_typ==1) then
                  loadnum(verdeg+1)=-1
                  do i=0,v_dim-1
                     leg_out_idx=int(delta(i,0))
                     idx_out=idx(leg_out_idx)
                     fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,1)=&
                     &dble(delta(leg_out_idx,1)*delta(leg_in_idx,1))/dble(totalweight)
                     !fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,1)=$
                     !$dble(delta(leg_out_idx,1))/dble(totalweight)

                     flux_idx=loadnum(verdeg+1)
                     if (w0/=0d0) then
                        !print*, "w0",w0
                        if (flux_idx==-1) then
                           loadnum(verdeg+1)=loadnum(verdeg+1)+1
                           flux_idx=loadnum(verdeg+1)
                           loadtab(flux_idx)=w0
                           loadnum(flux_idx)=1
                           max_cage=max(max_cage,loadnum(flux_idx))
                        else
                           flux_sign=0
                           do j=0,flux_idx
                              !print*, "loadtab",j,loadtab(j),w0,loadtab(j)==w0
                              if (loadtab(j)==w0) then
                                 flux_sign=1
                                 flux_idx=j
                                 loadnum(flux_idx)=loadnum(flux_idx)+1
                                 max_cage=max(max_cage,loadnum(flux_idx))
                                 exit
                              endif
                           enddo
                           if (flux_sign==0) then
                              loadnum(verdeg+1)=loadnum(verdeg+1)+1
                              flux_idx=loadnum(verdeg+1)
                              loadtab(flux_idx)=w0
                              loadnum(flux_idx)=1
                              max_cage=max(max_cage,loadnum(flux_idx))
                           endif
                        endif
                        max_type=max(max_type,loadnum(verdeg+1))
                     endif
                  enddo
               endif
            enddo
         enddo
      enddo
   enddo
 enddo
 print*, "fluxmul middle",max_type,max_cage

 allocate(fluxsut(0:verdeg,0:verdeg,0:vertexdim-1,max_type,lpdimax,2))
 allocate(fluxnum(0:verdeg,0:verdeg,0:vertexdim-1,0:max_type,0:max_cage,lpdimax))
 !pause
 
 do mu_mark=1,lpdimax
   if (rank==0d0) then
      fluxname='flbi000.log'
      fluxname(7:7)=achar(48+mu_mark-1)
      open(10,file=fluxname,status='replace')
   endif
   v_dim=dxl**mu_mark
   deallocate(fluxtamul)
   allocate(fluxtamul(0:verdeg,0:verdeg,0:v_dim-1,0:v_dim-1,2))
   do typ=1,1
      do cur0=0,verdeg
         do cur1=0,verdeg
            if (weightable(cur0,cur1,typ)==0d0) cycle
            do i=0,mxl-1
               state(i,0)=(mod(int(cur0/(2**(i))),2))*2-1
               state(i+mxl,0)=(mod(int(cur1/(2**(i))),2))*2-1
            enddo
            
            do leg_in_idx=0,v_dim-1
               !print*, "leg_in_idx",leg_in_idx
               state(:,1)=state(:,0)

               leg_in_0=leg_in_idx
               do j=1,mu_mark
                  dim_dxl=dxl**(j-1)
                  leg_in(j-1)=mod(int(leg_in_0/dim_dxl),dxl)
                  state(leg_in(j-1),1)=-state(leg_in(j-1),1)
               enddo
               !print*, "leg_in",leg_in_idx,leg_in(:)
               delta(:,:)=-1d0
               totalweight=0d0

               do leg_out_idx=0,v_dim-1
                  leg_out_0=leg_out_idx
                  do j=1,mu_mark
                     dim_dxl=dxl**(j-1)
                     leg_out(j-1)=mod(int(leg_out_0/dim_dxl),dxl)
                     state(leg_out(j-1),1)=-state(leg_out(j-1),1)
                  enddo
                  !print*, "leg_out",leg_out_idx,leg_out(:)
                  
                  cur2=0d0
                  cur3=0d0
                  do i=0,mxl-1
                     cur2=cur2+int((state(i,1)+1)*0.5d0)*2**(i)
                     cur3=cur3+int((state(i+mxl,1)+1)*0.5d0)*2**(i)
                  enddo
                  weight_tmp=weightable(cur2,cur3,typ)
                  leg_tmp=leg_out_idx

                  if (fluxbuild_typ==0) then
                     do i=0,v_dim-1
                        if (delta(i,1)==-1d0) then
                           delta(i,1)=weight_tmp
                           delta(i,0)=leg_tmp
                           exit
                        else
                           if (weight_tmp>delta(i,1)) then
                              weight_tmp1=delta(i,1)
                              leg_tmp1=delta(i,0)
                              delta(i,1)=weight_tmp
                              delta(i,0)=leg_tmp
                              weight_tmp=weight_tmp1
                              leg_tmp=leg_tmp1
                           else
                           endif
                        endif
                     enddo
                  elseif (fluxbuild_typ==1) then
                     delta(leg_out_idx,1)=weight_tmp
                     delta(leg_out_idx,0)=leg_tmp
                     totalweight=totalweight+weight_tmp
                  endif
                  
                  do j=1,mu_mark
                     state(leg_out(j-1),1)=-state(leg_out(j-1),1)
                  enddo
               enddo

               !print*, "---------------------------------"
               !print*, delta(:,1)
               notzero=0d0
               do i=0,v_dim-1
                  if (delta(i,1)/=0d0) then
                     notzero=notzero+1
                     delta_tmp(i,:)=delta(i,:)
                  else
                     exit
                  endif
               enddo
               do i=1,notzero-1
                  delta(i,:)=delta_tmp(notzero-i,:)
               enddo
               !print*, delta(:,1)

               if (fluxbuild_typ==0) then
                  !print*, leg_in_idx,leg_out_idx,cur0,cur1
                  !print*, delta(:,0)
                  !print*, delta(:,1)
                  !pause
                  delta(0,2)=delta(0,1)
                  do i=0,v_dim-1
                     idx(int(delta(i,0)))=i
                     delta(i,2)=delta(i-1,2)+delta(i,1)
                  enddo
                  !print*, idx(:)
                  !print*, delta(:,0)
                  !print*, "---------------------------------"
                  
                  idx_in=idx(leg_in_idx)
                  loadnum(verdeg+1)=0
                  !print*, weightable(cur0,cur1,typ),delta(idx_in,1)
                  do i=0,v_dim-1
                     leg_out_idx=int(delta(i,0))
                     idx_out=idx(leg_out_idx)

                     dd=delta(idx_in,2)-delta(mod(idx_out-1+v_dim,v_dim),2)+delta(0,1)
                     w0=dd
                     !print*,"0",w0,dd
                     w0=min(w0,delta(idx_in,1)+delta(idx_out,1)-dd)
                     !print*,"1",w0,delta(idx_in,1)+delta(idx_out,1)-dd
                     w0=min(w0,delta(idx_in,1))
                     !print*,"2", w0,delta(idx_in,1)
                     w0=min(w0,delta(idx_out,1))
                     !print*,"3", w0,delta(idx_out,1)
                     w0=max(w0,0d0)
                     fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,1)=w0
                     
                     flux_idx=loadnum(verdeg+1)-1
                     if (w0/=0d0) then
                        !print*, "w0",w0,loadnum(verdeg+1)
                        if (flux_idx==-1) then
                           loadnum(verdeg+1)=loadnum(verdeg+1)+1
                           flux_idx=loadnum(verdeg+1)-1
                           loadtab(flux_idx)=w0
                           loadnum(flux_idx)=1
                           max_cage=max(max_cage,loadnum(flux_idx))
                        else
                           flux_sign=0
                           do j=0,flux_idx
                              !print*, "loadtab",j,loadtab(j),w0,loadtab(j)==w0
                              if (loadtab(j)==w0) then
                                 flux_sign=1
                                 flux_idx=j
                                 loadnum(flux_idx)=loadnum(flux_idx)+1
                                 max_cage=max(max_cage,loadnum(flux_idx))
                                 exit
                              endif
                           enddo
                           if (flux_sign==0) then
                              loadnum(verdeg+1)=loadnum(verdeg+1)+1
                              flux_idx=loadnum(verdeg+1)-1
                              loadtab(flux_idx)=w0
                              loadnum(flux_idx)=1
                              max_cage=max(max_cage,loadnum(flux_idx))
                           endif
                        endif
                        max_type=max(max_type,loadnum(verdeg+1))
                     endif
                  enddo
                  !print*, "flux_idx",cur0,cur1
                  !print*, "flux_idx",loadnum(verdeg+1)!,loadtab(0:loadnum(verdeg+1)-1),loadnum(0:loadnum(verdeg+1)-1)
                  !print*, "flux_idx",max_type,max_cage
                  !print*,"---------------------------------"
                  if (weightable(cur0,cur1,typ)-sum(fluxtamul(cur0,cur1,leg_in_idx,:,1))>=0.00001d0) then
                     print*, "NBC error 0",weightable(cur0,cur1,typ),sum(fluxtamul(cur0,cur1,leg_in_idx,:,1))
                     print*,"----------------------------------------------"
                     pause
                  endif
               elseif (fluxbuild_typ==1) then
                  loadnum(verdeg+1)=-1
                  do i=0,v_dim-1
                     leg_out_idx=int(delta(i,0))
                     idx_out=idx(leg_out_idx)
                     fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,1)=&
                     &dble(delta(leg_out_idx,1)*delta(leg_in_idx,1))/dble(totalweight)
                     !fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,1)=$
                     !$dble(delta(leg_out_idx,1))/dble(totalweight)

                     flux_idx=loadnum(verdeg+1)
                     if (w0/=0d0) then
                        !print*, "w0",w0
                        if (flux_idx==-1) then
                           loadnum(verdeg+1)=loadnum(verdeg+1)+1
                           flux_idx=loadnum(verdeg+1)
                           loadtab(flux_idx)=w0
                           loadnum(flux_idx)=1
                           max_cage=max(max_cage,loadnum(flux_idx))
                        else
                           flux_sign=0
                           do j=0,flux_idx
                              !print*, "loadtab",j,loadtab(j),w0,loadtab(j)==w0
                              if (loadtab(j)==w0) then
                                 flux_sign=1
                                 flux_idx=j
                                 loadnum(flux_idx)=loadnum(flux_idx)+1
                                 max_cage=max(max_cage,loadnum(flux_idx))
                                 exit
                              endif
                           enddo
                           if (flux_sign==0) then
                              loadnum(verdeg+1)=loadnum(verdeg+1)+1
                              flux_idx=loadnum(verdeg+1)
                              loadtab(flux_idx)=w0
                              loadnum(flux_idx)=1
                              max_cage=max(max_cage,loadnum(flux_idx))
                           endif
                        endif
                        max_type=max(max_type,loadnum(verdeg+1))
                     endif
                  enddo
               endif
            enddo

            do leg_in_idx=0,v_dim-1
               state(:,1)=state(:,0)   
               fluxnum(cur0,cur1,leg_in_idx,:,:,mu_mark)=0

               !print*, "==========================",leg_in_idx,mu_mark
               do leg_out_idx=0,v_dim-1
                  w0=fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,1)
                  !print*, "w0=",w0,flux_idx
                  flux_sign=0d0
                  if (w0==0d0) cycle
                  flux_idx=fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)
                  !print*, "w0=",w0,flux_idx
                  if (flux_idx==0) then
                     fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)=&
                     &fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)+1
                     flux_idx=fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)

                     fluxsut(cur0,cur1,leg_in_idx,flux_idx,mu_mark,1:2)=w0
                     fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark)=&
                     &fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark)+1
                     flux_cage=fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark)
                     fluxnum(cur0,cur1,leg_in_idx,flux_idx,flux_cage,mu_mark)=leg_out_idx
                     flux_sign=1
                  else
                     do i=1,flux_idx
                        weight_tmp=fluxsut(cur0,cur1,leg_in_idx,i,mu_mark,1)
                        if (w0==weight_tmp) then
                           fluxnum(cur0,cur1,leg_in_idx,i,0,mu_mark)=&
                           &fluxnum(cur0,cur1,leg_in_idx,i,0,mu_mark)+1
                           fluxsut(cur0,cur1,leg_in_idx,i,mu_mark,2)=&
                           &fluxsut(cur0,cur1,leg_in_idx,i,mu_mark,2)+w0
                           flux_cage=fluxnum(cur0,cur1,leg_in_idx,i,0,mu_mark)
                           fluxnum(cur0,cur1,leg_in_idx,i,flux_cage,mu_mark)=leg_out_idx
                           flux_sign=1
                           exit
                        endif
                     enddo
                     if (flux_sign==0) then
                        fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)=&
                        &fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)+1
                        flux_idx=fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)

                        fluxsut(cur0,cur1,leg_in_idx,flux_idx,mu_mark,1:2)=w0
                        fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark)=&
                        &fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark)+1
                        flux_cage=fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark)
                        fluxnum(cur0,cur1,leg_in_idx,flux_idx,flux_cage,mu_mark)=leg_out_idx
                        flux_sign=1
                     endif
                  endif

                  if (abs(fluxsut(cur0,cur1,leg_in_idx,flux_idx,mu_mark,1)&
                  &*fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark)&
                  &-fluxsut(cur0,cur1,leg_in_idx,flux_idx,mu_mark,2))>0.00001d0) then
                     print*, "mis count", fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark),&
                     &fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark),&
                     &fluxsut(cur0,cur1,leg_in_idx,flux_idx,mu_mark,1),&
                     &fluxsut(cur0,cur1,leg_in_idx,flux_idx,mu_mark,1)&
                     &*fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark),&
                     &fluxsut(cur0,cur1,leg_in_idx,flux_idx,mu_mark,2)
                     pause
                  endif

               enddo

               flux_idx=fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)
               if (weightable(cur0,cur1,typ)-&
               &sum(fluxsut(cur0,cur1,leg_in_idx,1:flux_idx,mu_mark,2))>=0.00001d0) then
                  print*, "NBC error",weightable(cur0,cur1,typ),&
                  &sum(fluxsut(cur0,cur1,leg_in_idx,1:flux_idx,mu_mark,2))
                  print*,"----------------------------------------------"
                  print*, "NBC error",flux_idx,fluxsut(cur0,cur1,leg_in_idx,1:flux_idx,mu_mark,2)
                  print*,"----------------------------------------------"
                  print*, "NBC error",sum(fluxtamul(cur0,cur1,leg_in_idx,:,1))
                  pause
               endif

               flux_idx=fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)
               do i=1, flux_idx
                  flux_cage=fluxnum(cur0,cur1,leg_in_idx,i,0,mu_mark)
                  weight_tmp=fluxsut(cur0,cur1,leg_in_idx,i,mu_mark,1)
                  do j=1, flux_cage
                     leg_out_idx=fluxnum(cur0,cur1,leg_in_idx,i,j,mu_mark)
                     w0=fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,1)
                     if (w0==weight_tmp) then
                     else
                        print*, "fluxmul error",w0,weight_tmp,fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)
                        pause
                     endif
                  enddo
               enddo

               if (rank==0d0) then
                  write(10,*)"----------------------------------------------"
                  write(10,*)"state 1",cur1,state(mxl:dxl-1,0)
                  write(10,*)"state 0",cur0,state(0:mxl-1,0)
                  write(10,*)"option",option
                  write(10,*)"+++++++++++++++++++++++++++++++++++++++++++++++"
                  write(10,*)"leg in=",leg_in_idx,mod(leg_in_idx,dxl),int(leg_in_idx/dxl),"w=",weightable(cur0,cur1,typ)
                  do leg_out_idx=0,v_dim-1
                     write(10,*)"----------------------------------------------"
                     write(10,*)"state 1",cur1,state(mxl:dxl-1,0)
                     write(10,*)"state 0",cur0,state(0:mxl-1,0)
                     write(10,*)"leg in=",leg_in_idx,mod(leg_in_idx,dxl),int(leg_in_idx/dxl),"w=",weightable(cur0,cur1,typ)
                     write(10,*)"leg out=",leg_out_idx,mod(leg_out_idx,dxl),int(leg_out_idx/dxl)
                     write(10,*)"leg out 0",fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,1)
                     write(10,*)"leg out 1",fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,2)
                     write(10,*)"=============================================="
                  enddo
               endif

            enddo
         enddo
      enddo
   enddo
   if (rank==0d0) then
      close(10)
   endif
 enddo
 print*, "BC Mul done",max_cage,max_type
 call writfluxmul(max_cage,max_type)
 !pause
 end subroutine initfluxmul
!----------------------!
subroutine writfluxmul(max_cage,max_type)
 use configuration
 use vertexupdate
 implicit none

 integer :: signal,typ,cur0,cur1,rank,option,mu_mark,notzero
 integer :: leg_in_0,leg_in_1,leg_out_0,leg_out_1,leg_out_idx,leg_in_idx
 integer :: i,j,k,l,cur2,cur3,leg_tmp,leg_tmp1,idx_in,idx_out,fluxbuild_typ
 integer :: v_dim,dim_dxl,flux_idx,flux_cage,flux_sign,max_cage,max_type
 real(8) :: w0,w2,w1,jptmp,w3,weight_tmp,weight_tmp1,dd,totalweight
 integer, allocatable :: state(:,:)
 integer, allocatable :: idx(:)
 integer, allocatable :: visit(:)
 real(8), allocatable :: delta(:,:)
 real(8), allocatable :: delta_tmp(:,:)
 integer, allocatable :: leg_in(:)
 integer, allocatable :: leg_out(:)
 real(8), allocatable :: loadtab(:)
 integer, allocatable :: loadnum(:)
 real(8), allocatable  :: fluxtamul(:,:,:,:,:,:)
 character(11) :: fluxvl
 character(11) :: fluxnm
 
 lpdim=3
 lpdimax=min(lpdim,3)
 !lpdimax>=4 no enough memory
 print*,"loging",max_cage,max_type
 
 open(10,file="cage.log",status='replace')
 write(10,*)max_cage,max_type,lpdim,lpdimax
 close(10)
 do mu_mark=1,lpdimax
   v_dim=dxl**mu_mark
   fluxnm='flnm000.log'
   fluxnm(7:7)=achar(48+mu_mark-1)
   fluxvl='flva000.log'
   fluxvl(7:7)=achar(48+mu_mark-1)
   open(10,file=fluxnm,status='replace')
   open(20,file=fluxvl,status='replace')
   do typ=1,1
      do cur0=0,verdeg
         do cur1=0,verdeg
            do leg_in_idx=0,v_dim-1
               do i=0,max_type
                  if (i==0) then
                     do j=0,max_cage
                        !print*,fluxnum(cur0,cur1,leg_in_idx,i,j,mu_mark)
                        write(10,*)fluxnum(cur0,cur1,leg_in_idx,i,j,mu_mark)
                     enddo
                  else
                     do j=0,max_cage
                        write(10,*)fluxnum(cur0,cur1,leg_in_idx,i,j,mu_mark)
                     enddo
                     write(20,*)fluxsut(cur0,cur1,leg_in_idx,i,mu_mark,1),&
                     &fluxsut(cur0,cur1,leg_in_idx,i,mu_mark,2)
                  endif
               enddo
            enddo
         enddo
      enddo
   enddo
   close(10)
   close(20)
 enddo

end subroutine writfluxmul
!----------------------!

subroutine timemeasure(i)
   use configuration
   integer :: i

   call cpu_time(time1)

   if (i==0) then
      time0=time1
   elseif (i==1) then
      print*, "time=", time1-time0
      open(10, file="time.log", position='append')
      write(10,*) time1-time0
      close(10)
   elseif (i==2) then
      open(10, file="time.log", status='replace')
      close(10)
   endif

end subroutine timemeasure