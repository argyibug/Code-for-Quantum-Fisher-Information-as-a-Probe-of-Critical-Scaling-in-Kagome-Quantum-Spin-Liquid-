module configuration
!----------------------------------------------!
! Most important parameters and data structures
!----------------------------------------------!
 save

 integer :: lx0
 integer :: ly0
 integer :: lx
 integer :: ly
 integer :: nn0    ! number of sites
 integer :: nn    ! number of sites
 integer :: nb    ! number of bonds
 integer :: mm    ! total string length (mm=ns*ms)
 integer :: ns    ! number of substrings (time slices)
 integer :: mxl
 integer :: dxl
 !integer :: ms    ! maximum sub-string length
 integer :: tstp
 integer :: bincounter
 integer :: basis
 integer :: ntau
 integer :: nbs
 integer :: ofcc
 integer :: bb0
 integer :: bb1
 integer :: bb2

 integer :: clb_cur
 integer :: clb_nxt

 integer :: nms0
 integer :: bcty
 real(8) :: nhe1
 real(8) :: nhe2
 real(8) :: mag1
 real(8) :: mag2
 real(8) :: auen
 real(8) :: culg
 real(8) :: addele

 integer :: nms1=0
 integer :: nms2=0
 integer :: nms3=0

 real(8) :: beta  ! inverse temperature
 real(8) :: bet0  ! inverse temperature
 real(8) :: prob ! part of the acceptance probability for adding (removing) operator
 real(8) :: pbAc
 real(8) :: pbBs
 real(8) :: pbjp
 real(8) :: pbCn
 real(8) :: Ac0
 real(8) :: Bs0
 real(8) :: jp0
 real(8) :: jzz0
 real(8) :: hz0
 real(8) :: temp0
 real(8) :: temp1
 real(8) :: ntem
 real(8) :: dtem
 real(8) :: qastep
 real(8) :: lgstep
 real(8) :: Ac1
 real(8) :: Bs1
 real(8) :: jp1
 real(8) :: jzz1
 real(8) :: hz1
 real(8) :: Ac
 real(8) :: Bs
 real(8) :: jp
 real(8) :: jzz
 real(8) :: hz
 real(8) :: dtau
 real(8) :: slpb
 real(8) :: slprob
 real(8) :: clustersize
 real(8) :: expb
 integer :: updtyp
 integer :: sitnum
 integer :: nnn
 integer :: bondmaker
 integer :: clustersignal
 integer, allocatable :: legn(:,:)
 integer :: nq
 integer :: nq_all
 integer :: verdeg
 integer :: bonddeg
 integer :: grpbondnum
 integer :: btn
 integer :: grpbondepth
 real(8) :: time0
 real(8) :: time1
 
 real(8), allocatable :: cerlog(:)
 integer, allocatable :: bondtab(:,:,:)
 integer, allocatable :: bondgrp(:,:,:)
 integer, allocatable :: vexgrptab(:,:,:,:,:)
 integer, allocatable :: vextag(:,:,:,:,:)
 integer, allocatable :: spingrpidx(:,:,:,:,:,:,:)
 integer, allocatable :: spingrploc(:,:)
 integer, allocatable :: spacevisit(:)
 integer, allocatable :: spingrptab(:,:,:,:,:,:,:)
 integer, allocatable :: spingrp(:,:,:)
 integer, allocatable :: loopgrploc(:)
 integer, allocatable :: bondchain(:,:)

 integer, allocatable :: parbok(:)
 real(8), allocatable :: parset(:,:)

 integer, allocatable :: ratab(:)
 integer, allocatable :: clusterflog(:,:)
 integer :: clusterbtm
 integer :: clusterdim
 integer :: clusterdimax

 real(8), allocatable :: weightable(:,:,:)

 integer, allocatable :: opstfp(:,:)
 integer, allocatable :: betable(:)
 integer, allocatable :: clustervislog(:,:)

 integer :: nh
 integer :: nh1
 integer :: nh2
 integer :: nh3
 integer :: nh4

 integer :: legcon
 integer :: legtot

 real(8) :: aclpre
 real(8) :: aclcrr

 !integer, allocatable :: nhpm(:,:)
 !integer, allocatable :: nhtp(:)

 integer, allocatable :: spin(:)
 integer, allocatable :: bsites(:,:)
 integer, allocatable :: sambon(:)
 integer, allocatable :: bontab(:)
 integer, allocatable :: opstring(:)
 integer, allocatable :: oporder(:)
 integer, allocatable :: tauscale(:)
 integer, allocatable :: vertexspin(:,:)
 integer, allocatable :: bondidx(:,:)
 !integer, allocatable :: opcluster(:,:)

 integer, allocatable :: frstspinop(:)
 integer, allocatable :: lastspinop(:)
 integer, allocatable :: vertexlist(:,:)
 integer, allocatable :: vertexlist_map(:)
 integer, allocatable :: opertyp(:)
 integer, allocatable :: dealtyp(:)
 integer, allocatable :: offoporder(:)
 integer, allocatable :: digoporder(:)
 real(8), allocatable :: rantau(:)
 integer, allocatable :: recorder(:,:)
 
 integer :: loop_eff_count
 integer :: loop_tot_count

 character(11) :: culgname
 character(11) :: loopname
 character(11) :: heauname

 real(8), parameter :: pi=3.14159265358979323d0
 real(8), parameter :: ex=2.71828182845904523d0

end module configuration

module measurementdata
 !--------------------------------------------!
 !Data we measured
 !--------------------------------------------!
 save

 real(8) :: enrg1=0.d0
 real(8) :: enrg2=0.d0
 real(8) :: amag1=0.d0
 real(8) :: amag2=0.d0

 real(8), allocatable :: crr(:,:,:,:)      !correlation function in real space

 integer, allocatable :: qpts(:)    !list of q-points

 real(8), allocatable :: tcor(:,:)    !correlation function in momentum space
 real(8), allocatable :: tc(:) 
 real(8), allocatable :: ref(:,:)     ! real part of fourier transform of spins
 real(8), allocatable :: imf(:,:)      ! imaginary part of fourier transform of spins
 real(8), allocatable :: phi(:,:,:)   ! phase factors for fourier transforms

 integer, allocatable :: tgrd(:)    !grid of time points
 
 integer :: nc
 integer :: ncd
 integer :: nf

 character(10) :: resname
 character(10) :: crrname
 character(11) :: backname
 character(11) :: cubename
 character(11) :: tcorname
 character(11) :: recrname

 real(8), allocatable :: tgrid(:)   ! phase factors for fourier transforms 
 real(8), allocatable :: tcor_real(:,:,:)   ! phase factors for fourier transforms 
 real(8), allocatable :: tcor_demo(:,:,:)   ! phase factors for fourier transforms 
 real(8), allocatable :: tcordeali1(:,:,:,:,:)   ! phase factors for fourier transforms 
 real(8), allocatable :: tcordeali2(:,:,:,:,:)   ! phase factors for fourier transforms 

end module measurementdata

!==========================!
!main part of the programme!
!==========================!
! nn     =  number of spins
! beta   =  inverse backerature
! dtau   =  time-slize widt
! nbin   =  number of bins
! mstps  =  steps per bin for measurements
! istps  =  initial (equlibration) steps
! gtype  =  time-grid type (1,2,3)
! tmax   =  maximum delta-time for correlation functions
! nqx(y) =  number of q-points for time correlations
! tstp   =  time-step when computing time averages of correlations  
! tmsr   =  measure time correlations after every tmsr MC sweep
! qpts   =  q-values to do (among values 0,....,nn/2, actual q is this times 2*pi/nn)

program data_sse

	use configuration
	use measurementdata
	implicit none

   integer :: a1,a2,a3
   integer :: cu1,cu2,cu3
   integer :: njp,nhz
   real(8) :: dhz,djp,djzz,totback
   integer :: j,i,bins,q,i1,i2,i3,rank_max,ios,n,k,l,Num_P,m,alp,gam,nme
   integer :: nbins,msteps,isteps,tmsr,gtype,tmax,strng,xbins,bsteps
   integer :: rx,ry,rz
   real(8) :: bt,ba
   real(8) :: ht,ha
   real(8) :: jt,ja
   real(8), allocatable :: avcrr(:,:,:,:,:)
   real(8), allocatable :: back_error(:)
   real(8), allocatable :: cops(:)
   real(8), allocatable :: rlsp(:,:)
   real(8), allocatable :: back(:)
   !real(8), allocatable :: bt(:)
   !real(8), allocatable :: ht(:)
   !real(8), allocatable :: jt(:)
   real(8), allocatable :: cy(:)
   real(8), allocatable :: a(:)
   real(8), allocatable :: av(:,:)
   real(8), allocatable :: tcdm_demo(:,:,:)
   real(8), allocatable :: tcor_real_demo(:,:,:,:)
   real(8), allocatable :: tgrid_demo(:)
   character(len=2) :: ind
   character(4) :: filehead
   character(4) :: filqhead
   real(8) :: copy


   open(unit=10, file='read.in', status="old")
   read(10,*)lx,ly,bcty
   read(10,*)Ac0,Bs0
   read(10,*)basis
   read(10,*)Ac1,Bs1
   read(10,*)qastep
   read(10,*)nbins,msteps,isteps
   read(10,*)xbins,bsteps
   read(10,*)dtau
   read(10,*)gtype,tmax
   read(10,*)tstp,tmsr
   close(unit=10)

   sitnum=lx*ly

   open(unit=10, file='q_resolution.in', status="old")
   read(10,*)nq
   close(unit=10)
   nq_all=2*nq+1
   
   open(unit=10, file='temp_an.in', status="old")
   read(10,*)temp0
   read(10,*)temp1
   read(10,*)ntem
   close(unit=10)
   dtem=(temp1-temp0)/dble(ntem)
   beta=temp1
   if (temp0==temp1) then
      beta=bet0
      ntem=0d0
   endif

   open(unit=10, file='jp.in', status="old")
   read(10,*)jp0
   read(10,*)jp1
   read(10,*)djp
   close(unit=10)
   njp=int((jp1-jp0)/dble(djp))
   if (jp0==jp1) then
      jp=jp0
   endif

   open(unit=10, file='hz.in', status="old")
   read(10,*)hz0
   read(10,*)hz1
   read(10,*)dhz
   close(unit=10)
   nhz=int((hz1-hz0)/dble(dhz))
   if (hz0==hz1) then
      hz=hz0
   endif
   
   open(unit=10, file='jzz.in', status="old")
   read(10,*)jzz0
   read(10,*)jzz1
   read(10,*)djzz
   close(unit=10)
   njzz=int((jzz1-jzz0)/dble(djzz))
   if (jzz0==jzz1) then
      jzz=jzz0
      njzz=0d0
   endif

   allocate(cy(5))
   allocate(a(5))
   allocate(av(2,5))
   allocate(back(0:3))

   cy=0d0
   a=0d0
   av=0d0

	open(unit=10, file='NumberOfP.in', status="old")
	read(10,*)Num_P
	close(unit=10)
	Num_P=Num_P-1
    !Num_P=9

    resname='res000.dat'
    crrname='crr000.dat'
    tcorname='tcor000.dat'

    open(10,file='e.dat',status='replace')
    close(10)

    open(10,file='m.dat',status='replace')
    close(10)

    open(10,file='t.dat',status='replace')
    close(10)

    open(10,file='stiff.dat',status='replace')
    close(10)

    open(10,file='crr.dat',status='replace')
    close(10)
    open(10,file='back.dat',status='replace')
    close(10)
    allocate(avcrr(0:lx-1,0:ly-1,3,2))

    do a1=0, int(njp)
    do a2=0, int(nhz)
    do a3=0, int(ntem)

    bins=0
    av=0.d0
    strng=0d0

 	do i=0,Num_P
 		resname='res000.dat'
 		i3=i/100
    	i2=mod(i,100)/10
    	i1=mod(i,10)
    	resname(6:6)=achar(48+i1)
    	resname(5:5)=achar(48+i2)
    	resname(4:4)=achar(48+i3)
 		open(unit=10, file=resname, status='old', action='read')
        do cu1=0, int(njp)
        do cu2=0, int(nhz)
        do cu3=0, int(ntem)
 		    read(10,*)bt,ht,jt,a(:)
            if (cu1==a1 .and. cu2==a2 .and. cu3==a3) then
 		        av(1,:)=av(1,:)+a(:)
 		        av(2,:)=av(2,:)+a(:)**2
                ba=bt
                ha=ht
                ja=jt
                print*,"check",a1,a2,a3,cu1,cu2,cu3
                exit
            endif
        enddo
        enddo
        enddo
 		close(unit=10)
        bins=bins+1
 	enddo
 	av=av/bins
 	av(2,:)=sqrt((av(2,:)-av(1,:)**2)/(bins-1))

 	open(10,file='e.dat',position='append')
 	write(unit=10, fmt="(11f15.8)")ba,ha,ja,av(:,1:2)
 	close(10)

 	open(10,file='m.dat',position='append')
    write(unit=10, fmt="(11f15.8)")ba,ha,ja,av(:,3:4)
 	close(10)

    open(10,file='t.dat',position='append')
    write(unit=10, fmt="(11f15.8)")ba,ha,ja,av(:,5)
    close(10)

    bins=0
    av=0.d0
    strng=0d0

    do i=0,Num_P
        resname='sff000.dat'
        i3=i/100
        i2=mod(i,100)/10
        i1=mod(i,10)
        resname(6:6)=achar(48+i1)
        resname(5:5)=achar(48+i2)
        resname(4:4)=achar(48+i3)
        !print*,resname
        open(unit=10, file=resname, status='old', action='read')
        do cu1=0, int(njp)
        do cu2=0, int(nhz)
        do cu3=0, int(ntem)
            read(10,*)bt,ht,jt,a(1:4)
            !print*,a3,a2,a1
            !print*,bt,ht,jt,a(1:4)
            if (cu1==a1 .and. cu2==a2 .and. cu3==a3) then
                av(1,1:4)=av(1,1:4)+a(1:4)
                av(2,1:4)=av(2,1:4)+a(1:4)**2
                ba=bt
                ha=ht
                ja=jt
                exit
            endif
        end do
        end do
        end do
        close(unit=10)
        bins=bins+1
    enddo
    av=av/bins
    av(2,:)=sqrt((av(2,:)-av(1,:)**2)/(bins-1))

    open(10,file='stiff.dat',position='append')
    write(unit=10, fmt="(11f15.8)")ba,ha,ja,av(:,1:4)
    close(10)

    do i=0,Num_P
        backname='back000.dat'
        i3=i/100
        i2=mod(i,100)/10
        i1=mod(i,10)
        resname(7:7)=achar(48+i1)
        resname(6:6)=achar(48+i2)
        resname(5:5)=achar(48+i3)
        !print*,resname
        open(unit=10, file=backname, status='old', action='read')
        do cu1=0, int(njp)
        do cu2=0, int(nhz)
        do cu3=0, int(ntem)
            read(10,*)bt,ht,jt,a(1:4)
            !print*,a3,a2,a1
            !print*,bt,ht,jt,a(1:4)
            if (cu1==a1 .and. cu2==a2 .and. cu3==a3) then
                av(1,1:4)=av(1,1:4)+a(1:4)
                av(2,1:4)=av(2,1:4)+a(1:4)**2
                ba=bt
                ha=ht
                ja=jt
                exit
            endif
        end do
        end do
        end do
        close(unit=10)
        bins=bins+1
    enddo
    av=av/bins
    av(2,:)=sqrt((av(2,:)-av(1,:)**2)/(bins-1))

    open(10,file='back.dat',position='append')
    write(unit=10, fmt="(11f15.8)")ba,ha,ja,av(:,1:4)
    close(10)
    totback=0d0
    do i=0,3
        back(i)=av(1,i+1)**2
        totback=totback+back(i)
    enddo

    do i=0,Num_P
        resname='sff000.dat'
        i3=i/100
        i2=mod(i,100)/10
        i1=mod(i,10)
        resname(6:6)=achar(48+i1)
        resname(5:5)=achar(48+i2)
        resname(4:4)=achar(48+i3)
        !print*,resname
        open(unit=10, file=resname, status='old', action='read')
        do cu1=0, int(njp)
        do cu2=0, int(nhz)
        do cu3=0, int(ntem)
            read(10,*)bt,ht,jt,a(1:4)
            !print*,a3,a2,a1
            !print*,bt,ht,jt,a(1:4)
            if (cu1==a1 .and. cu2==a2 .and. cu3==a3) then
                av(1,1:4)=av(1,1:4)+a(1:4)
                av(2,1:4)=av(2,1:4)+a(1:4)**2
                ba=bt
                ha=ht
                ja=jt
                exit
            endif
        end do
        end do
        end do
        close(unit=10)
        bins=bins+1
    enddo
    av=av/bins
    av(2,:)=sqrt((av(2,:)-av(1,:)**2)/(bins-1))

    open(10,file='stiff.dat',position='append')
    write(unit=10, fmt="(11f15.8)")ba,ha,ja,av(:,1:4)
    close(10)

    avcrr(:,:,:,:)=0d0
    cy=0d0
    do i=0,Num_P
        crrname='crr000.dat'
        i3=i/100
        i2=mod(i,100)/10
        i1=mod(i,10)
        crrname(6:6)=achar(48+i1)
        crrname(5:5)=achar(48+i2)
        crrname(4:4)=achar(48+i3)
        open(unit=10, file=crrname, iostat=ios, status="old", action="read")
        if ( ios /= 0 ) exit
        n=bins/Num_P
        !print*, crrname
        do cu1=0, int(njp)
        do cu2=0, int(nhz)
        do cu3=0, int(ntem)
            do j=0, lx-1
                do k=0,ly-1
                    !read(10,*)rx,ry,cy(1),cy(2),cy(3)
                    read(10,*)rx,ry,bt,ht,jt,cy(1),cy(2),cy(3)
                    if (cu1==a1 .and. cu2==a2 .and. cu3==a3) then
                        do m=1,3
                            !if (m==3) print*,cy(m)
                            avcrr(rx,ry,m,1)=avcrr(rx,ry,m,1)+cy(m)
                            avcrr(rx,ry,m,2)=avcrr(rx,ry,m,2)+cy(m)**2
                            cy(m)=0d0
                        enddo
                    endif
                enddo
            enddo
            if (cu1==a1 .and. cu2==a2 .and. cu3==a3) then
                ba=bt
                ha=ht
                ja=jt
                exit
            endif
        enddo
        enddo
        enddo
        close(unit=10)
    enddo
    avcrr=avcrr/bins
    avcrr(:,:,:,:,2)=sqrt((avcrr(:,:,:,:,2)-avcrr(:,:,:,:,1)**2)/(bins-1))
    open(10,file='crr.dat',position='append')
    do j=0,lx-1
        do k=0,ly-1
            do l=0,lz-1
                !write(10,*)j,k,l,avcrr(j,k,l,1,:),avcrr(j,k,l,2,:),avcrr(j,k,l,3,:)
                write(10,*)ba,ha,ja,j,k,l,avcrr(j,k,l,1,:),avcrr(j,k,l,2,:),&
                &avcrr(j,k,l,3,:),avcrr(j,k,l,4,:)
            enddo
        enddo
    enddo
    close(10)
    !deallocate(avcrr)

    end do
    end do
    end do
    
    print*,"done"

end program data_sse

!==================================================!