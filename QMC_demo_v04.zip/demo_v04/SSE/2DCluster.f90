module configuration
!----------------------------------------------!
! Most important parameters and data structures
!----------------------------------------------!
 save

 integer :: lx0       
 integer :: ly0       
 integer :: lz0 
 integer :: lx       
 integer :: ly       
 integer :: lz       
 integer :: nn0    ! number of sites 
 integer :: nn    ! number of sites   
 integer :: nb    ! number of bonds     
 integer :: nbs    ! number of bonds          
 integer :: mm    ! total string length (mm=ns*ms)
 integer :: nq
 integer :: nq_all
 integer :: ns    ! number of substrings (time slices)
 integer :: mxl
 integer :: dxl
 !integer :: ms    ! maximum sub-string length
 integer :: tstp  
 integer :: bincounter
 integer :: basis
 integer :: ntau 

 integer :: nms0
 integer :: bcty
 real(8) :: nhe1 
 real(8) :: nhe2 
 real(8) :: mag1
 real(8) :: mag2
 real(8) :: auen
 real(8) :: culg

 integer :: nms1=0
 integer :: nms2=0 

 real(8) :: beta  ! inverse temperature
 real(8) :: bet0  ! inverse temperature
 real(8) :: prob ! part of the acceptance probability for adding (removing) operator  
 real(8) :: pbAc 
 real(8) :: pbBs 
 real(8) :: pbhx 
 real(8) :: pbhz
 real(8) :: Ac0
 real(8) :: Bs0
 real(8) :: hx0
 real(8) :: hz0
 real(8) :: qastep
 real(8) :: lgstep
 real(8) :: Ac1
 real(8) :: Bs1
 real(8) :: hx1
 real(8) :: hz1
 real(8) :: Ac
 real(8) :: Bs
 real(8) :: hx
 real(8) :: hz
 real(8) :: dtau
 real(8) :: slpb 
 real(8) :: slprob  
 integer :: updtyp
 integer :: sitnum

 integer, allocatable :: parbok(:)
 real(8), allocatable :: parset(:,:)

 integer, allocatable :: ratab(:)
 integer, allocatable :: opvlog(:)
 integer, allocatable :: opvtab(:)
 integer, allocatable :: opflog(:)
 integer, allocatable :: opftab(:)

 integer, allocatable :: logtab(:) 
 integer, allocatable :: protab(:) 
 integer, allocatable :: weightab(:,:) 
 real(8), allocatable :: cweightable(:,:) 
 real(8), allocatable :: sweightable(:,:) 

 integer :: nh
 integer :: nh1
 integer :: nh2
 integer :: nh3
 integer :: nh4

 integer :: nhk0
 integer :: nhk1
 integer :: legcon
 integer :: legtot

 real(8) :: aclpre
 real(8) :: aclcrr

 !integer, allocatable :: nhpm(:,:)
 !integer, allocatable :: nhtp(:)

 integer, allocatable :: legtyp(:)
 integer, allocatable :: opflip(:)
 integer, allocatable :: spin(:)      
 integer, allocatable :: bsites(:,:)  
 integer, allocatable :: sambon(:) 
 integer, allocatable :: bontab(:)  
 integer, allocatable :: opstring(:)  
 integer, allocatable :: oporder(:)  
 integer, allocatable :: tauscale(:)
 integer, allocatable :: vertexspin(:,:)
 !integer, allocatable :: opcluster(:,:)

 integer, allocatable :: frstspinop(:) 
 integer, allocatable :: lastspinop(:) 
 integer, allocatable :: vertexlist(:,:) 
 integer, allocatable :: vertexlist_map(:) 
 integer, allocatable :: opertyp(:)
 integer, allocatable :: dealtyp(:)
 integer, allocatable :: ofoporder(:)
 real(8), allocatable :: rantau(:)

 character(11) :: culgname

 real(8), parameter :: pi=3.14159265358979323d0
 real(8), parameter :: ex=2.71828182845904523d0

end module configuration

module measurementdata
 !--------------------------------------------!
 !Data we measured
 !--------------------------------------------!
 save

 real(8) :: enrg1=0.d0
 real(8) :: enrg2=0.d0
 real(8) :: amag1=0.d0
 real(8) :: amag2=0.d0

 real(8), allocatable :: crr(:,:,:,:)      !correlation function in real space
 real(8), allocatable :: topa(:)      !correlation function in real space

 integer, allocatable :: qpts(:)    !list of q-points

 real(8), allocatable :: tcAc(:,:)    !correlation function in momentum space
 real(8), allocatable :: tc(:) 
 real(8), allocatable :: ref(:,:)     ! real part of fourier transform of spins
 real(8), allocatable :: imf(:,:)      ! imaginary part of fourier transform of spins
 real(8), allocatable :: phi(:,:,:)   ! phase factors for fourier transforms
 real(8), allocatable :: cbbkgd(:)
 real(8), allocatable  :: ssbkgd(:)


 integer, allocatable :: tgrd(:)    !grid of time points
 
 integer :: nc
 integer :: nf

 character(10) :: resname
 character(10) :: crrname
 character(11) :: topaname
 character(11) :: backname
 character(11) :: tcAcname
 character(11) :: tAxxname
 character(11) :: tAyyname
 character(11) :: tAzzname
 character(11) :: tAxyname
 character(11) :: tAyzname
 character(11) :: tAzxname
 character(11) :: tBxxname
 character(11) :: tByyname
 character(11) :: tBzzname
 character(11) :: tBxyname
 character(11) :: tByzname
 character(11) :: tBzxname
 character(11) :: autoname
 character(11) :: heauname
 character(11) :: etlgname

end module measurementdata

!==========================!
!main part of the programme!
!==========================!
! nn     =  number of spins
! beta   =  inverse temperature
! nbin   =  number of bins
! mstps  =  steps per bin for measurements
! istps  =  initial (equlibration) steps 

module vertexupdate
   save
   integer :: v0
   integer :: v1
   integer :: v2

   integer :: vt
   integer :: mmt
   integer :: bt
   integer :: opt
   integer :: udt
   integer :: typt
   integer :: sigt
   integer :: dltypt

   integer :: mm0
   integer :: b0
   integer :: op0
   integer :: ud0
   integer :: typ0
   integer :: sig0
   integer :: dltyp0

   integer :: length
   integer :: clustermark
   integer :: mrk0
   integer :: mrk1
   integer :: selfcest
   integer, allocatable :: cmplsg(:)
   integer :: update_counter
   !integer :: loop_counter
   integer :: counter
   integer :: dcounter
   integer :: ocounter
   integer :: probnum

   real(8) :: tau0
   real(8) :: delta_tau
   real(8) :: wgtaft
   real(8) :: wgtbfr

end module vertexupdate

program basic_heisenberg_sse

   use configuration
   use measurementdata
   implicit none
   include 'mpif.h'
   integer :: ierr,nprocs,i1,i2,i3
   integer :: rank,btidx,comm,st(mpi_status_size)
   integer :: i,j,k,r,l,nbins,msteps,isteps,tmsr,gtype,bsteps,dstep,xbins,cur_step
   integer :: pidx1,pidx2,nhtmp1,nhtmp2,idx1,idx2,aimproc,xsign,total_step,crr_step
   integer :: nhp1p1,nhn1p1,nhp2p1,nhn2p1,nhp1p2,nhn1p2,nhp2p2,nhn2p2,lt
   integer, allocatable :: extendhappen(:)
   real(8) :: jojo,beta_pev,beta_crr,en_crr,Ac_min,en_per,mg_crr,mg_per,m2_crr,m2_per
   real(8) :: tmax
   real(8), external :: ran

   open(unit=10, file='read.in', status="old")
   read(10,*)lx0,ly0,lz0,bet0,bcty
   read(10,*)Ac0,Bs0,hx0,hz0
   read(10,*)basis,slprob
   read(10,*)Ac1,Bs1,hx1,hz1
   read(10,*)qastep,lgstep
   read(10,*)nbins,msteps,isteps
   read(10,*)xbins,bsteps
   read(10,*)dtau
   read(10,*)gtype,tmax              
   read(10,*)tstp,tmsr
   close(unit=10)

   lx=lx0
   ly=ly0
   lz=lz0
   nn0=2*lx0*ly0*lz0
   beta=bet0

   !call initratiotable()
   !lx=ratab(1)
   !ly=ratab(1)
   !lz=ratab(1)

   !allocate(extendhappen(ratab(0)-1))
   !extendhappen(1)=1d0
   !extendhappen(2)=2d0
   !extendhappen(3)=4d0

   !lt=ratab(1)

   Ac=Ac0
   Bs=Bs0
   hx=hx0
   hz=hz0

   nq=lx0/2
   open(unit=10, file='q_resolution.in', status="replace")
   close(unit=10)
   open(unit=10, file='q_resolution.in', status="old")
   write(10,*)nq
   close(unit=10)
   nq_all=7*nq
   !xbins=2*xbins-1

   !rank=0
   dstep=100
   !dstep=dstep*xbins
   total_step=(xbins*bsteps)-dstep

   call MPI_init(ierr)
   call MPI_Comm_size(MPI_COMM_WORLD,nprocs,ierr)
   call MPI_Comm_rank(MPI_COMM_WORLD,rank,ierr)

   call initran(1,rank)
   call makelattice()
   call initconfig(rank,nprocs)
   call taugrid(gtype,tmax)
   call qarrays()

   beta=bet0
   print*,"step 0",nprocs

   btidx=rank
   r=1
   l=1
   !beta_pev=bet0
   !beta_crr=bet0

   autoname='auto000.dat'
   heauname='heau000.dat'
   culgname='culg000.dat'
   i3=rank/100
   i2=mod(rank,100)/10
   i1=mod(rank,10)

   heauname(7:7)=achar(48+i1)
   heauname(6:6)=achar(48+i2)
   heauname(5:5)=achar(48+i3)

   autoname(7:7)=achar(48+i1)
   autoname(6:6)=achar(48+i2)
   autoname(5:5)=achar(48+i3)

   culgname(7:7)=achar(48+i1)
   culgname(6:6)=achar(48+i2)
   culgname(5:5)=achar(48+i3)

   open(10,file=heauname,status='replace')
   close(10)
   open(10,file=autoname,status='replace')
   close(10)
   open(10,file=culgname,status='replace')
   close(10)

   !Ac_min=10**(-bet0)
   !Ac=Ac_min
   !call initweight(0,1,0,nprocs)

!==================================================================!
   !Do isteps equilibration sweeps, find the necessary sweep
   do j=0,xbins
      !print*,j,lx,beta
      !call measurechain(0)
      do i=1,bsteps
         !if (j/=0) then
         !   cur_step=int(i/(dstep*1d0))*(dstep*1d0)+(j-1)*bsteps
         !else
         !   cur_step=0d0
         !endif
         !Ac=Ac_min+(Ac0-Ac_min)/(total_step*1d0)*cur_step
         !call initweight(0,1,0,nprocs)
         !beta=parset(btidx,0)
         !print*,beta,rank

         !beta=2*lx
         !beta=bet0
         !crr_step=i
         !beta=beta_pev+(beta_crr-beta_pev)/(total_step)*crr_step

         call diagonalupdate(btidx)
         !print*,"a",i
         call linkvertices(0)
         !print*,"b",i
         call clusterupdate(btidx,int(lx*beta),0)
         !print*,"c",i
         call adjustcutoff(i)
         !print*,"d",i

         !if (btidx==1 .or. btidx==0) then
            !print*,"protab",protab(btidx)
            !print*,"nh+",nhpm(protab(btidx),1),"nh-",nhpm(protab(btidx),0),nhpm(protab(btidx),1)-nhpm(protab(btidx),0)
         !endif

!++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++!
         !if (mod(i,dstep)==0 .and. j/=0 .and. i/=bsteps) then 
         !   call MPI_Barrier(MPI_COMM_WORLD,ierr)
         !   do k=0,nprocs
         !   !do k=0,5*nprocs
         !      pidx1=-1
         !      pidx2=-1
         !      if (rank==0d0) then
         !         idx1=int(ran()*(nprocs-1))
         !         !idx2=mod(idx1+1,nprocs)
         !         do
         !            idx2=int(ran()*nprocs)
         !            if (idx1/=idx2) exit
         !         enddo
         !      endif
         !      call MPI_BCAST(idx1,1,MPI_INTEGER,0,MPI_COMM_WORLD,ierr)
         !      call MPI_BCAST(idx2,1,MPI_INTEGER,0,MPI_COMM_WORLD,ierr)
         !      pidx1=parbok(idx1)
         !      pidx2=parbok(idx2)
         !      call MPI_Barrier(MPI_COMM_WORLD,ierr)
         !      !print*,k,1
         !
         !      jojo=-1d0
         !     xsign=-1d0
         !
         !      if (rank==pidx2) then
         !         aimproc=pidx1  
         !         nhtmp2=nh 
         !         if (protab(pidx1)/=-1) then
         !            nhp1p2=nhpm(protab(pidx1),1)
         !            nhn1p2=nhpm(protab(pidx1),0)
         !         else
         !            nhp1p2=0
         !            nhn1p2=0
         !         endif
         !         if (protab(pidx2)/=-1) then
         !            nhp2p2=nhpm(protab(pidx2),1)
         !            nhn2p2=nhpm(protab(pidx2),0)
         !         else
         !           nhp2p2=0
         !            nhn2p2=0
         !         endif
         !
         !         call MPI_SSEND(nhtmp2,1,MPI_INTEGER,aimproc,998,MPI_COMM_WORLD,ierr) 
         !         call MPI_SSEND(nhp1p2,1,MPI_INTEGER,aimproc,997,MPI_COMM_WORLD,ierr) 
         !         call MPI_SSEND(nhn1p2,1,MPI_INTEGER,aimproc,996,MPI_COMM_WORLD,ierr) 
         !         call MPI_SSEND(nhp2p2,1,MPI_INTEGER,aimproc,995,MPI_COMM_WORLD,ierr) 
         !         call MPI_SSEND(nhn2p2,1,MPI_INTEGER,aimproc,994,MPI_COMM_WORLD,ierr)
         !
         !         call MPI_RECV(nhtmp1,1,MPI_INTEGER,aimproc,993,MPI_COMM_WORLD,st,ierr) 
         !         call MPI_RECV(nhp1p1,1,MPI_INTEGER,aimproc,992,MPI_COMM_WORLD,st,ierr) 
         !         call MPI_RECV(nhn1p1,1,MPI_INTEGER,aimproc,991,MPI_COMM_WORLD,st,ierr)
         !         call MPI_RECV(nhp2p1,1,MPI_INTEGER,aimproc,990,MPI_COMM_WORLD,st,ierr) 
         !         call MPI_RECV(nhn2p1,1,MPI_INTEGER,aimproc,989,MPI_COMM_WORLD,st,ierr)
         !
         !         !jojo=(parset(idx1,0)/parset(idx2,0))**(-(nhtmp1-nhtmp2)) 
         !
         !      endif 
         !
         !      if (rank==pidx1) then
         !         aimproc=pidx2
         !         nhtmp1=nh
         !         if (protab(pidx1)/=-1) then
         !            nhp1p1=nhpm(protab(pidx1),1)
         !            nhn1p1=nhpm(protab(pidx1),0)
         !         else
         !            nhp1p1=0
         !            nhn1p1=0
         !         endif
         !         if (protab(pidx2)/=-1) then
         !            nhp2p1=nhpm(protab(pidx2),1)
         !            nhn2p1=nhpm(protab(pidx2),0)
         !         else
         !            nhp2p1=0
         !            nhn2p1=0
         !         endif
         !
         !         call MPI_RECV(nhtmp2,1,MPI_INTEGER,aimproc,998,MPI_COMM_WORLD,st,ierr)
         !         call MPI_RECV(nhp1p2,1,MPI_INTEGER,aimproc,997,MPI_COMM_WORLD,st,ierr)
         !         call MPI_RECV(nhn1p2,1,MPI_INTEGER,aimproc,996,MPI_COMM_WORLD,st,ierr)
         !         call MPI_RECV(nhp2p2,1,MPI_INTEGER,aimproc,995,MPI_COMM_WORLD,st,ierr)
         !         call MPI_RECV(nhn2p2,1,MPI_INTEGER,aimproc,994,MPI_COMM_WORLD,st,ierr)
         !
         !         call MPI_SSEND(nhtmp1,1,MPI_INTEGER,aimproc,993,MPI_COMM_WORLD,ierr) 
         !         call MPI_SSEND(nhp1p1,1,MPI_INTEGER,aimproc,992,MPI_COMM_WORLD,ierr) 
         !         call MPI_SSEND(nhn1p1,1,MPI_INTEGER,aimproc,991,MPI_COMM_WORLD,ierr) 
         !         call MPI_SSEND(nhp2p1,1,MPI_INTEGER,aimproc,990,MPI_COMM_WORLD,ierr) 
         !         call MPI_SSEND(nhn2p1,1,MPI_INTEGER,aimproc,989,MPI_COMM_WORLD,ierr) 
         !
         !         !jojo=(parset(idx1,0)/parset(idx2,0))**(-(nhtmp1-nhtmp2)) 
         !
         !         !print*,pidx1,nhp1p1,nhn1p1,nhp2p1,nhn2p1,logtab(pidx1)
         !         !print*,pidx2,nhp1p2,nhn1p2,nhp2p2,nhn2p2,logtab(pidx2)
         !         !print*,"pidx1,pidx2",pidx1,pidx2,(nhp1p1-nhn1p1)-(nhp2p1-nhn2p1)+(nhp2p2-nhn2p2)-(nhp1p2-nhn1p2)
         !         !print*,"pidx1,pidx2",2d0**((nhp1p1-nhn1p1)-(nhp2p1-nhn2p1)+(nhp2p2-nhn2p2)-(nhp1p2-nhn1p2)),ran()
         !         !print*,"pidx1,pidx2",(nhp1p1-nhn1p1)-(nhp2p1-nhn2p1),(nhp2p2-nhn2p2)-(nhp1p2-nhn1p2)
         !        
         !         jojo=1d0
         !         jojo=2d0**((nhp1p1-nhn1p1)-(nhp2p1-nhn2p1)+(nhp2p2-nhn2p2)-(nhp1p2-nhn1p2))   
         !         !jojo=2d0**((nhp1p1-nhn1p1)-(nhp1p2-nhn1p2))         
         !
         !         if (ran()<jojo) then
         !            print*,"swap",jojo,idx1,idx2,i,j
         !         !if (ran()<0.5d0) then
         !            xsign=1d0
         !         else
         !            print*,"fall",jojo,idx1,idx2,i,j
         !            xsign=0d0
         !         endif
         !
         !      endif 
         !      call MPI_BCAST(xsign,1,MPI_INTEGER,pidx1,MPI_COMM_WORLD,ierr)
         ! 
         !
         !      if (xsign==1) then
         !         if (rank==pidx1) then
         !            btidx=idx2
         !         endif
         !        if (rank==pidx2) then
         !            btidx=idx1
         !         endif
         !
         !         parbok(idx1)=pidx2
         !         parbok(idx2)=pidx1
         ! 
         !      endif
         
               !print*,k,2
               
         
         !      beta=parset(btidx,0)
         !      Ac=parset(btidx,1)
         !      Bs=parset(btidx,2)
         !      hx=parset(btidx,3)
         !      hz=parset(btidx,4)
         !      call initweight(0,0,0,nprocs)
         !
         !      call MPI_Barrier(MPI_COMM_WORLD,ierr)
         !      !print*,rank,k
         !      if (rank==parbok(nprocs-1)) then
         !         !print*,k,rank,btidx,parbok(btidx),pidx2,pidx1,parbok(idx2),parbok(idx1),idx2,idx1
         !         !print*,k,rank,btidx,"par",parset(btidx,1),parset(btidx,2)
         !         !print*,parbok
         !         !pause
         !      endif
         !
         !      !print*,k,3
         !
         !      !call MPI_Barrier(MPI_COMM_WORLD,ierr)
         !   enddo
         !   !print*,rank,parbok,int(i/(100*1d0)),"replica exchange"
         !endif
!++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++!

         !if (mod(i,100)==0) then
            if (mod(i,1000)==0 .and. j/=0) then 
               print*,rank,int(i/(100*1d0)),"prheating",j,lx
            endif
         !
         !   call measurechain(3)
         !   if (i>=bsteps-500 .or. i<=500) then
         !      open(10,file=etlgname,position='append')
         !         write(10,*)j,i,"culg=",culg
         !      close(10)
         !   endif
         !   call measurechain(0)
         !endif

         !ncd=int(nn/3d0)
         !if ( mod(i,1)==0 .and. rank<10 ) then
         !   call measurechain(1)
         !   open(10,file=heauname,position='append')
         !      write(10,*)i+j*bsteps,auen,mag1,mag2
         !   close(10)
         !endif

         !call measurechain(2)

      enddo

      !en_per=-(nh/(beta*dble(nn)))+((Ac/3d0+(1d0+hx+hz))+2d0*(Ac/3d0+hx))
      !print*,"bef",j,lx,en_crr,nh,beta_pev,nn
      !if (j==extendhappen(min(ratab(0)-1,r))) then
      !   r=r+1
      !   l=1
      !else
      !   l=0
      !endif
      !if (r<=ratab(0) .and. l==1) then
      !   if (ratab(r)>1) then
      !      pidx2=0d0
      !      nhtmp2=0d0
            !open(10,file=etlgname,position='append')
               !do k=0,nprocs-1
               !   pidx1=k
               !   nhtmp1=nh
               !   call MPI_BCAST(nhtmp1,1,MPI_INTEGER,pidx1,MPI_COMM_WORLD,ierr)
               !   if (nhtmp1>nhtmp2) then
               !      nhtmp2=nhtmp1
               !      pidx2=k
               !   endif
               !   write(10,*)"op number log",r,pidx1,nhtmp1,pidx2,nhtmp2
               !   call MPI_Barrier(MPI_COMM_WORLD,ierr)
               !enddo
            !close(10)

            !call writeconfig(rank)
            !call MPI_Barrier(MPI_COMM_WORLD,ierr)
            !call clearconfig()
            !call readconfig(rank)

            !print*,"spaceship",nh,mm,nh1,nh2,nh3,nh4

      !      call measurechain(1)
      !      mg_per=mag1
      !      m2_per=mag2
      !      en_per=auen
      !      call extendconfig(ratab(r),nprocs,rank)
            !lt=lt*ratab(r)
            !print*,j,r,ratab(r),extendhappen(min(ratab(0)-1,r)),ratab(0)-1,lt
            !call extendconfig(1,nprocs,rank)
      !      call measurechain(1)
      !      mg_crr=mag1
      !      m2_crr=mag2
      !      en_crr=auen
      !      open(10,file=etlgname,position='append')
      !         write(10,*)"extend config================="
      !         write(10,*)j,ratab(r),lx
      !         write(10,*)"eng config",en_crr,en_per
      !         write(10,*)"mag config",mg_crr,mg_per
      !         write(10,*)"mag config",m2_crr,m2_per
      !         write(10,*)"extend config================="
      !      close(10)
      !   endif
      !endif
      !beta_crr=2*lx
      !en_crr=-(nh/(beta*dble(nn)))+((Ac/3d0+(1d0+hx+hz))+2d0*(Ac/3d0+hx))
      !open(10,file=heauname,position='append')
      !   write(10,*)i+j*bsteps,auen
      !close(10)

      !print*,"aft",j,lx,en_crr,nh,beta_crr,nn

   enddo

   call writeconfig(rank)
   !call MPI_Barrier(MPI_COMM_WORLD,ierr)
   !call clearconfig()
   !call readconfig(parbok(nprocs-1))

!==================================================================!

   print*,"step 1"

   open(10,file=culgname,status='replace')
   close(10)
   !slprob=0.01d0
   aclcrr=0d0
   aclpre=-1d0
   
   lx=lx0
   ly=ly0
   lz=lz0
   beta=bet0
   Ac=Ac0
   Bs=Bs0
   hx=hx0
   hz=hz0
   btidx=nprocs-1
!==================================================================!
   !Do isteps equilibration sweeps, find the necessary sweep
   do i=1,isteps
      call diagonalupdate(rank)
      !print*,"a",i
      call linkvertices(2)
      !print*,"b",i
      call clusterupdate(rank,int(lx*beta),1)
      !print*,"c",i
      call adjustcutoff(i)
      !print*,"d",i
      if (mod(i,1000)==0) then
         print*,rank,int(i/(100*1d0)),"heating"
         !print*,rank,nh1,nh2,nh1*1d0/nh*1d0,nh2*1d0/nh*1d0
      endif
      !print*,rank,i,nh1,nh2,nh1*1d0/nh*1d0,nh2*1d0/nh*1d0

      if ( mod(i,1)==0 .and. rank<10 ) then
         call measurechain(1)
         open(10,file=heauname,position='append')
            write(10,*)i+(xbins+1)*bsteps,auen,mag1,mag2
         close(10)
      endif
   enddo
!==================================================================!

   print*,"step 2",rank


   call writeconfig(rank)
   bincounter=0

   print*,"step 3",rank

   ! Do nbins bins with msteps MC sweeps in each, measure after each
   do j=1,nbins
      !bincounter=bincounter+1
      do i=1,msteps
         call diagonalupdate(rank)
         !print*,"a",i
         call linkvertices(2)
         !print*,"b",i
         call clusterupdate(rank,int(lx*beta),1)
         !print*,"c.1",i
         call measure(rank)
         !print*,"c.2",i
         call measure2()
         !print*,"d",i
         if ( mod(i,1000)==0 ) print*,rank,i/(msteps*1d-2)

         if ( mod(i,1)==0 .and. rank<10 ) then
            call measurechain(1)
            open(10,file=autoname,position='append')
               write(10,*)i,auen,mag1,mag2
            close(10)
         endif
      enddo
      !write bin averages to 'res.dat'!
      print*,bincounter
      call writeresult(0,rank)
      call writeconfig(rank)
      !rank=rank+1
   enddo
   print*,"step 4",rank

   call MPI_Barrier(MPI_COMM_WORLD,ierr)
   call MPI_Finalize(ierr) 

   bincounter=0
   call deallocateall()

end program basic_heisenberg_sse

!==================================================!

!==================================================!

subroutine initconfig(rank,nprocs)
   use configuration
   use measurementdata
   implicit none

   integer :: i,j,s,x
   integer :: rank,nprocs
   real(8) :: rate,bmin,Acmin,Bsmin,hxmin,hzmin
   real(8), external :: ran

   allocate(parset(0:nprocs-1,0:4))
   allocate(parbok(0:nprocs-1))
   
   x=20
   !bmin=(bet0/2d0)*1d0
   bmin=1d0
   !rate=bet0*1d0/(bmin)
   !rate=(rate*((nprocs)**(-(1d0/x))))**(1/((nprocs-1d0)*1d0))
   !print*,rate
   !bmin=1d0*bet0/((nprocs*1d0)**(1d0/x))
   Acmin=0.8d0*Ac0
   Bsmin=1.2d0*Bs0
   hxmin=hx0
   hzmin=hz0
   do i=1,nprocs
      parbok(i-1)=i-1

      !parset(i-1,0)=bmin
      parset(i-1,0)=bet0
      !bmin=bmin*(((i+1d0)/i*1d0)**(1d0/x))
      !bmin=bmin*rate*(((i+1d0)/i*1d0)**(1d0/x))
      !bmin=bmin+(bet0-1d0)/((nprocs-1)*1d0)

      parset(i-1,1)=Ac0
      !Acmin=Acmin+(1d0-0.8d0)*Ac0/((nprocs-1)*1d0)
      !Acmin=Acmin-(1.1d0-1d0)*Ac0/((nprocs-1)*1d0)


      parset(i-1,2)=Bs0
      !Bsmin=Bsmin+(1d0-0.9d0)*Bs0/((nprocs-1)*1d0)
      !Bsmin=Bsmin-(1.2d0-1d0)*Bs0/((nprocs-1)*1d0)

      parset(i-1,3)=hx0

      parset(i-1,4)=hz0

   enddo
   !print*,parset(:,0),"0"
   !print*,parset(:,1),"1"
   !print*,parset(:,2),"2"
   !print*,parset(:,3),"3"
   !print*,parset(:,4),"4"
   parset(nprocs-1,0)=bet0
   parset(nprocs-1,1)=Ac0
   parset(nprocs-1,2)=Bs0
   parset(nprocs-1,3)=hx0
   parset(nprocs-1,4)=hz0
   parbok(nprocs-1)=nprocs-1

   !print*,nn
   allocate(spin(nn))
   do i=1,sitnum
      !spin(i)=2*int(2.*ran())-1
      !spin(i)=2*int(2.*ran())-1
      spin(i)=1
      spin(i+sitnum)=1
   enddo

   mm=nn
   ns=int(beta/dtau+0.1d0)

   allocate(opflip(nn0))
   opflip(:)=0d0
   nh=0                               
   nh1=0                              
   nh2=0                              
   nh3=0                              
   nh4=0                              
!=============================================================================!
   allocate(opstring(0:mm-1))            !according to whether it is a sub-programme
   opstring(:)=0                         !according to whether it is a sub-programme
   allocate(tauscale(0:mm-1))            !according to whether it is a sub-programme
   tauscale(:)=0                         !according to whether it is a sub-programme
   allocate(vertexlist(0:dxl*mm-1,0:1))        !according to whether it is a sub-programme
   allocate(vertexlist_map(0:dxl*mm-1))    !according to whether it is a sub-programme
   allocate(vertexspin(0:mxl-1,0:mm-1))      !according to whether it is a sub-programme
   allocate(rantau(nh))                  !according to whether it is a sub-programme
  
!=============================================================================!
!=============================================================================!
   !call readconfig(rank)          !according to whether it is a sub-programme
!=============================================================================!
   allocate(opvlog(nn0))
   allocate(opvtab(nn0))
   allocate(opflog(nn0))
   allocate(opftab(nn0))
   allocate(oporder(nn0))
   allocate(opertyp(nn0))
   allocate(dealtyp(nn0))
   allocate(ofoporder(nn0))
   allocate(frstspinop(nn0))
   allocate(lastspinop(nn0))
   allocate(crr(0:lx0-1,0:ly0-1,0:lz0-1,3))
   crr(:,:,:,:)=0
   allocate(topa(0:lx0-1))
   topa(:)=0

   allocate(legtyp(2))
   if (basis==0) then
      legtyp(1)=1
      legtyp(2)=3

      !do i=1, sitnum
         !if (ran()<0.5d0) then
            !do j=1,mxl
               !s=bsites(j,i)
               !spin(s)=-spin(s)
            !enddo
         !endif
      !enddo

   elseif (basis==1) then
      legtyp(1)=2
      legtyp(2)=4

      !do i=1, 3*sitnum
         !if (ran()<0.5d0) then
            !do j=1,4
               !s=bsites(j,i+sitnum)
               !spin(s)=-spin(s)
            !enddo
         !endif
      !enddo

   endif

   !allocate(opcluster(nn,0:dxl-1))
   !opcluster(:,:)=0d0

   call initweight(1,1,1,nprocs)
   !call spinchecker()

end subroutine initconfig
!==================================================!

!==================================================!

subroutine initweight(signal,signal2,signal3,nprocs)
   use configuration
   implicit none
   integer :: i,j,k,l,temp,spnum,index,signal,signal2,signal3,nprocs
   integer :: dnn
   real(8) :: wgt,sptm,cf

   cf=2d0

   if (signal==1) then
      allocate(cweightable(0:1,2))
      allocate(sweightable(0:1,2))
   endif

   if (signal3==1) then
      allocate(weightab(4*lx0*ly0*lz0,0:nprocs-1))
      allocate(logtab(4*lx0*ly0*lz0))
      allocate(protab(0:nprocs-1))
      weightab(:,:)=1
      logtab(:)=-1
      protab(:)=-1
      !dnn=int(sitnum/(nprocs-1))-1
      !j=0d0
      !do i=1,sitnum
      !   !print*,i,dnn,mod(i,dnn)
      !   if (mod(i,dnn)==1) then
      !      !weightab(i,0:j)=2d0
      !      weightab(i,j)=2d0
      !      logtab(i)=j
      !      protab(j)=i
      !      !print*,"mark",i,j
      !      j=j+1
      !   endif
      !   if (j>=nprocs-1) exit
      !enddo

      !allocate(nhpm(4*lx0*ly0*lz0,0:1))
      !allocate(nhtp(4*lx0*ly0*lz0))
      !nhpm(:,:)=0d0
      !nhtp(:)=0d0
   endif

   cweightable(:,:)=0d0
   sweightable(:,:)=0d0
   
   if (basis==0) then

      cweightable(:,:)=Ac!0 for flip 1 for noflip

   elseif(basis==1) then

      cweightable(0,1)=-Ac+3d0*Ac!0 for - 1 for +
      cweightable(1,1)=Ac+3d0*Ac!0 for - 1 for +

      cweightable(0,2)=-Ac+3d0*Ac!0 for - 1 for +
      cweightable(1,2)=Ac+3d0*Ac!0 for - 1 for +

      !cweightable(0,2)=10!0 for - 1 for +
      !cweightable(1,2)=0.1!0 for - 1 for +

   endif
   
   if (basis==0) then

      sweightable(0,1)=-Bs+3d0*Bs!0 for - 1 for +
      sweightable(1,1)=Bs+3d0*Bs!0 for - 1 for +

      sweightable(0,2)=-Bs+3d0*Bs!0 for - 1 for +
      sweightable(1,2)=Bs+3d0*Bs!0 for - 1 for +

      !sweightable(0,2)=10!0 for - 1 for +
      !sweightable(1,2)=0.1!0 for - 1 for +

   elseif(basis==1) then
      
      sweightable(:,:)=Bs!0 for flip 1 for noflip

   endif
   
   !print*,nn
   if (signal2==1) then
      if (hx/=0) then
         if (lz==1) then
               pbhx=sitnum
            else
               pbhx=nn
         endif
      else
         pbhx=0d0
      endif

      if (hz/=0) then
         if (lz==1) then
            pbhz=sitnum
         else
            pbhz=nn
         endif
      else
         pbhz=0d0
      endif

      prob=pbAc+pbBs+pbhx+pbhz
   endif
   print*,prob,sitnum,nn

end subroutine initweight
!==================================================!

!==================================================!
subroutine initratiotable()
   use configuration
   implicit none
   integer :: i,j,ls
   integer, allocatable :: primnumber(:)

   allocate(primnumber(8))
   primnumber(1)=2
   primnumber(2)=3
   primnumber(3)=5
   primnumber(4)=7
   primnumber(5)=11
   primnumber(6)=13
   primnumber(7)=17
   primnumber(8)=19

   ls=lx0

   i=1
   do
      if (2**i>=ls) then
         allocate(ratab(0:i))
         ratab(:)=-1
         ratab(0)=i
         exit
      else
         i=i+1
      endif
   enddo

   j=1
   do 
      do i=1,8
         if (mod(ls,primnumber(i))==0d0) then
            ratab(j)=primnumber(i)
            ls=ls/primnumber(i)
            j=j+1
            exit
         endif
      enddo
      if (ls==1) exit
   enddo

end subroutine initratiotable
!==================================================!

!==================================================!

subroutine makelattice()
   use configuration
   implicit none
   integer :: s,x1,x2,y1,y2,z1,z2,index,i
   integer :: s1,s2,s3,s4,s5,s6,s7,s8,bt,bc
   integer :: xx1,xx2,xx3,xx4,yy1,yy2,yy3,yy4

   nn=lx*ly*lz
   print*,nn,lx,ly,lz
   bc=0d0
   pbAc=0d0
   pbBs=0d0

   if (lz==1) then
      if (ly==1) then
         nb=lx
         mxl=2
         dxl=2*mxl
         allocate(bsites(2,nb))
         allocate(sambon(nb))
         sambon(:)=-1d0
         allocate(bontab(nb))
         bontab(:)=-1d0
         bc=0d0
         do x1=0,lx-1
            s=x1+1
            x2=mod(x1+1,lx)
            bsites(1,s)=s
            bsites(2,s)=x2+1
            bc=bc+1
            sambon(bc)=s
            bontab(s)=bc
         enddo

      elseif (ly==2) then
         allocate(bsites(2,nb))
         allocate(sambon(nb))
         sambon(:)=-1d0
         allocate(bontab(nb))
         bontab(:)=-1d0
         do y1=0,ly-1
            do x1=0,lx-1
               s=1+x1+y1*lx
               x2=mod(x1+1,lx)
               y2=y1
               bsites(1,s)=s
               bsites(2,s)=1+x2+y2*lx
               bc=bc+1
               sambon(bc)=s
               bontab(s)=bc
               if (y1==0) then
                  x2=x1
                  y2=mod(y1+1,ly)
                  bsites(1,s+nn)=s
                  bsites(2,s+nn)=1+x2+y2*lx 
                  bc=bc+1
                  sambon(bc)=s+nn   
                  bontab(s+nn)=bc   
               endif
            enddo
         enddo

      else
         nb=2*nn
         !allocate(bsites(mxl,nb))
         !do y1=0,ly-1
         !   do x1=0,lx-1
         !      s=1+x1+y1*lx
         !
         !      s1=1+mod(x1,lx)+mod(y1,ly)*lx
         !      s2=1+mod(x1-1+lx,lx)+mod(y1,ly)*lx
         !      s3=1+mod(x1,lx)+mod(y1-1+ly,ly)*lx
         !
         !      bsites(1,s)=s1
         !      bsites(2,s)=s3+nn
         !      bsites(3,s)=s2
         !      bsites(4,s)=s1+nn
         !      bsites(5:mxl,s)=-1 
         !
         !      s1=1+mod(x1,lx)+mod(y1,ly)*lx
         !      s2=1+mod(x1+1,lx)+mod(y1,ly)*lx
         !      s3=1+mod(x1,lx)+mod(y1+1,ly)*lx
         !
         !      bsites(1,s+nn)=s1
         !      bsites(2,s+nn)=s1+nn
         !      bsites(3,s+nn)=s3
         !      bsites(4,s+nn)=s2+nn
         !      bsites(5:mxl,s+nn)=-1  
         !   enddo
         !enddo

         mxl=5
         dxl=2*mxl
         allocate(bsites(mxl,nb))
         allocate(sambon(nb))
         sambon(:)=-1d0
         allocate(bontab(nb))
         bontab(:)=-1d0
         do y1=0,ly-1
            do x1=0,lx-1
               s=1+x1+y1*lx

               xx1=x1
               yy1=y1
               xx2=x1+1
               yy2=y1
               xx3=x1+1
               yy3=y1+1
               xx4=x1
               yy4=y1+1

               s1=1+mod(xx1+lx,lx)+mod(yy1+ly,ly)*lx
               s2=1+mod(xx2+lx,lx)+mod(yy2+ly,ly)*lx
               s3=1+mod(xx3+lx,lx)+mod(yy3+ly,ly)*lx
               s4=1+mod(xx4+lx,lx)+mod(yy4+ly,ly)*lx
               bt=0
               
               if (bcty==0d0) then
               elseif (bcty==1d0) then
                  if (0<=xx1 .and. xx1<lx) then 
                  else
                     bt=-1
                  endif
                  if (0<=xx2 .and. xx2<lx) then 
                  else
                     bt=-1
                  endif
                  if (0<=xx3 .and. xx3<lx) then 
                  else
                     bt=-1
                  endif
                  if (0<=xx4 .and. xx4<lx) then 
                  else
                     bt=-1
                  endif
               elseif (bcty==2d0) then
                  if (0<=xx1 .and. xx1<lx .and. 0<=yy1 .and. yy1<ly) then 
                  else
                     bt=-1
                  endif
                  if (0<=xx2 .and. xx2<lx .and. 0<=yy2 .and. yy2<ly) then 
                  else
                     bt=-1
                  endif
                  if (0<=xx3 .and. xx3<lx .and. 0<=yy3 .and. yy3<ly) then 
                  else
                     bt=-1
                  endif
                  if (0<=xx4 .and. xx4<lx .and. 0<=yy4 .and. yy4<ly) then 
                  else
                     bt=-1
                  endif
               endif

               bsites(1,s)=s1
               bsites(2,s)=s2
               bsites(3,s)=s3
               bsites(4,s)=s4
               bsites(5,s)=s1+nn
               if (bt==0d0) then
                  bc=bc+1
                  sambon(bc)=s
                  bontab(s+nn)=bc
                  pbAc=pbAc+1
               endif   

               xx1=x1
               yy1=y1
               xx2=x1-1
               yy2=y1-1
               xx3=x1
               yy3=y1-1
               xx4=x1-1
               yy4=y1

               s1=1+mod(xx1+lx,lx)+mod(yy1+ly,ly)*lx
               s2=1+mod(xx2+lx,lx)+mod(yy2+ly,ly)*lx
               s3=1+mod(xx3+lx,lx)+mod(yy3+ly,ly)*lx
               s4=1+mod(xx4+lx,lx)+mod(yy4+ly,ly)*lx
               bt=0
               
               if (bcty==0d0) then
               elseif (bcty==1d0) then
                  if (0<=xx1 .and. xx1<lx) then 
                  else
                     bt=-1
                  endif
                  if (0<=xx2 .and. xx2<lx) then 
                  else
                     bt=-1
                  endif
                  if (0<=xx3 .and. xx3<lx) then 
                  else
                     bt=-1
                  endif
                  if (0<=xx4 .and. xx4<lx) then 
                  else
                     bt=-1
                  endif
               elseif (bcty==2d0) then
                  if (0<=xx1 .and. xx1<lx .and. 0<=yy1 .and. yy1<ly) then 
                  else
                     bt=-1
                  endif
                  if (0<=xx2 .and. xx2<lx .and. 0<=yy2 .and. yy2<ly) then 
                  else
                     bt=-1
                  endif
                  if (0<=xx3 .and. xx3<lx .and. 0<=yy3 .and. yy3<ly) then 
                  else
                     bt=-1
                  endif
                  if (0<=xx4 .and. xx4<lx .and. 0<=yy4 .and. yy4<ly) then 
                  else
                     bt=-1
                  endif
               endif
         
               bsites(1,s+nn)=s2+nn
               bsites(2,s+nn)=s3+nn
               bsites(3,s+nn)=s1+nn
               bsites(4,s+nn)=s4+nn
               bsites(5,s+nn)=s1
               if (bt==0d0) then
                  bc=bc+1
                  sambon(bc)=s+nn
                  bontab(s)=bc
                  pbBs=pbBs+1
               endif  
            enddo
         enddo
         sitnum=nn
         nn=2*nn
      endif
      !do i=0,ly-1
      !   s1=1+0+i*lx
      !   s2=1+lx-1+i*lx
      !   print*,bontab(s1:s2)
      !enddo
      !do i=0,ly-1
      !   s1=1+0+i*lx
      !   s2=1+lx-1+i*lx
      !   print*,bontab(s1+sitnum:s2+sitnum)
      !enddo
      !print*,sambon(:),bc
      !pause
   else
      nb=(1+3)*nn
      mxl=12
      dxl=2*mxl
      allocate(bsites(mxl,nb))
      allocate(sambon(nb))
      sambon(:)=-1d0
      allocate(bontab(nb))
      bontab(:)=-1d0
      bsites(:,:)=-1
      do x1=0,lx-1
         do y1=0,ly-1
            do z1=0,lz-1
               s=1+x1+y1*lx+z1*lx*ly

               s1=1+mod(x1,lx)+mod(y1,ly)*lx+mod(z1,lz)*lx*ly
               s2=1+mod(x1+1,lx)+mod(y1,ly)*lx+mod(z1,lz)*lx*ly
               s3=1+mod(x1+1,lx)+mod(y1+1,ly)*lx+mod(z1,lz)*lx*ly
               s4=1+mod(x1,lx)+mod(y1+1,ly)*lx+mod(z1,lz)*lx*ly
               s5=1+mod(x1,lx)+mod(y1,ly)*lx+mod(z1+1,lz)*lx*ly
               s6=1+mod(x1+1,lx)+mod(y1,ly)*lx+mod(z1+1,lz)*lx*ly
               s7=1+mod(x1+1,lx)+mod(y1+1,ly)*lx+mod(z1+1,lz)*lx*ly
               s8=1+mod(x1,lx)+mod(y1+1,ly)*lx+mod(z1+1,lz)*lx*ly

               bsites(1,s)=s1
               bsites(4,s)=s1+nn
               bsites(8,s)=s1+2*nn
               bsites(2,s)=s2+nn
               bsites(5,s)=s2+2*nn
               bsites(6,s)=s3+2*nn
               bsites(3,s)=s4
               bsites(7,s)=s4+2*nn
               bsites(9,s)=s5
               bsites(12,s)=s5+nn
               bsites(10,s)=s6+nn
               bsites(11,s)=s8

               bc=bc+1
               sambon(bc)=s
               bontab(s)=bc
               pbAc=pbAc+1

               s1=1+mod(x1,lx)+mod(y1,ly)*lx+mod(z1,lz)*lx*ly
               s2=1+mod(x1-1+lx,lx)+mod(y1,ly)*lx+mod(z1,lz)*lx*ly
               s3=1+mod(x1,lx)+mod(y1-1+ly,ly)*lx+mod(z1,lz)*lx*ly
               s4=1+mod(x1,lx)+mod(y1,ly)*lx+mod(z1-1+lz,lz)*lx*ly

               bsites(1,s+nn)=s1+nn
               bsites(2,s+nn)=s1+2*nn
               bsites(3,s+nn)=s3+nn
               bsites(4,s+nn)=s4+2*nn
               bsites(5:mxl,s+nn)=-1

               bc=bc+1
               sambon(bc)=s+nn
               bontab(s+nn)=bc
               pbBs=pbBs+1

               bsites(1,s+2*nn)=s1
               bsites(2,s+2*nn)=s4+2*nn
               bsites(3,s+2*nn)=s2
               bsites(4,s+2*nn)=s1+2*nn
               bsites(5:mxl,s+2*nn)=-1

               bc=bc+1
               sambon(bc)=s+2*nn
               bontab(s+2*nn)=bc
               pbBs=pbBs+1

               bsites(1,s+3*nn)=s1
               bsites(2,s+3*nn)=s1+nn
               bsites(3,s+3*nn)=s2
               bsites(4,s+3*nn)=s3+nn
               bsites(5:mxl,s+3*nn)=-1

               bc=bc+1
               sambon(bc)=s+3*nn
               bontab(s+3*nn)=bc
               pbBs=pbBs+1

            enddo
         enddo
      enddo
      sitnum=nn
      nn=3*nn
   endif
   nbs=bc
   print*,nbs,nb,nb-nbs

   !s2=0d0
   !s=1+x1+y1*lx+z1*lx*ly
   !do s1=1,nn/3
      !print*,int((s1-1)/(lx*ly)),s2
      !if (int((s1-1)/(lx*ly))==s2) then
         !print*,s1,s2
         !print*,bsites(9:mxl,s1)
         !print*,bsites(5:8,s1)
         !print*,bsites(1:4,s1)
         !print*,"//////////////////////"
         !print*,bsites(9:mxl,s1+nn/3)
         !print*,bsites(5:8,s1+nn/3)
         !print*,bsites(1:4,s1+nn/3)
         !print*,"++++++++++++++++++++++++"
         !print*,bsites(9:mxl,s1+2*nn/3)
         !print*,bsites(5:8,s1+2*nn/3)
         !print*,bsites(1:4,s1+2*nn/3)
         !print*,"++++++++++++++++++++++++"
         !print*,bsites(9:mxl,s1+3*nn/3)
         !print*,bsites(5:8,s1+3*nn/3)
         !print*,bsites(1:4,s1+3*nn/3)
         !print*,"//////////////////////"
      !endif
      !if (mod((s1-1),(lx*ly))==lx*ly-1) s2=s2+1
   !enddo
   

end subroutine makelattice
!==================================================!

!==================================================!

subroutine diagonalupdate(prid)
   use configuration
   use measurementdata
   implicit none

   integer :: i,j,key,s,prid,stmp,typ,b,op,nz,nv,a
   integer :: bond
   integer :: cs
   integer :: ss
   real(8) :: p1,wght
   real(8), external :: ran

   cs=1d0
   ss=1d0
   !if (hx/=0) then
      !nz=nz+nn
   !endif
   !if (hz/=0) then
      !nz=nz+nn
   !endif
   nz=prob


   do i=0,mm-1
      op=opstring(i)
      bond=0d0
      wght=0d0
      if ( op==0 ) then

         nv=int(nz*ran())+1

         !if (ran()*(pbAc+pbBs+pbhx+pbhz)<=pbAc) then
            !bond=int(sitnum*ran())+1
            !print*,"1",bond
         if (nv<=nbs .and. sambon(nv)<=sitnum) then
            bond=sambon(nv)
            !if (bsites(5,bond)==-1) print*,"WARNING1"
            !if (bsites(1,bond)==-1) print*,"WARNING1"

            cs=1d0
            do j=1,mxl
               if (bsites(j,bond)==-1) exit
               cs=cs*spin(bsites(j,bond))
            enddo
            wght=cweightable(int((cs+1)/2),weightab(bond,prid))
            if ((mm-nh)*ran()<=wght*prob*beta) then
               opstring(i)=8*bond
               nh=nh+1
               nh1=nh1+1
               !if (basis==1) nhpm(bond,int((cs+1)/2))=nhpm(bond,int((cs+1)/2))+1
            endif
         !elseif (ran()*(pbBs+pbhx+pbhz)<=pbBs) then
            !bond=int(nn*ran())+sitnum+1
         elseif (nv<=nbs .and. sambon(nv)>sitnum) then
            bond=sambon(nv)
            !if (bsites(5,bond)/=-1) print*,"WARNING2"
            !if (bsites(1,bond)==-1) print*,"WARNING2"
            !print*,"2",bond
            ss=1d0
            do j=1,mxl
               if (bsites(j,bond)==-1) exit
               ss=ss*spin(bsites(j,bond))
            enddo
            wght=sweightable(int((ss+1)/2),weightab(bond,prid)) 
            if ((mm-nh)*ran()<=wght*prob*beta) then
               opstring(i)=8*bond+2
               nh=nh+1
               nh2=nh2+1
               !if (basis==0) nhpm(bond,int((ss+1)/2))=nhpm(bond,int((ss+1)/2))+1
            endif
            !print*,"3",bond
         elseif (nv<=nbs+pbhx .and. nv>nbs .and. hx/=0) then
            bond=nv-(nbs)+sitnum
            if (basis==0d0) then
               if (spin(bond)==1) then
                  wght=hx
                  if ((mm-nh)*ran()<=wght*prob*beta) then  
                     opstring(i)=8*bond+4
                     nh=nh+1
                     nh3=nh3+1
                  endif
               elseif (spin(bond)==-1) then
                  wght=hx
                  if ((mm-nh)*ran()<=wght*prob*beta) then  
                     opstring(i)=8*bond+4
                     nh=nh+1
                     nh3=nh3+1
                  endif
               endif
            elseif (basis==1d0) then
               if (spin(bond)==1) then
                  wght=4d0*hx
                  if ((mm-nh)*ran()<=wght*prob*beta) then  
                     opstring(i)=8*bond+4
                     nh=nh+1
                     nh3=nh3+1
                  endif
               elseif (spin(bond)==-1) then
                  wght=2d0*hx
                  if ((mm-nh)*ran()<=wght*prob*beta) then  
                     opstring(i)=8*bond+4
                     nh=nh+1
                     nh3=nh3+1
                  endif
               endif
            endif
         else
            !bond=int(nn*ran())+1
            if (hx==0) then
               bond=nv-(nbs)
            else
               bond=nv-(nbs+pbhx)
            endif
            !bond=nv-(sitnum+nn+nn)
            !print*,"4",bond
            if (basis==0d0) then 
               if (spin(bond)==1) then
                  wght=4d0*hz
                  if ((mm-nh)*ran()<=wght*prob*beta) then  
                     opstring(i)=8*bond+6
                     nh=nh+1
                     nh4=nh4+1
                  endif
               elseif (spin(bond)==-1) then
                  wght=2d0*hz
                  if ((mm-nh)*ran()<=wght*prob*beta) then  
                     opstring(i)=8*bond+6
                     nh=nh+1
                     nh4=nh4+1
                  endif
               endif
            elseif (basis==1d0) then
               if (spin(bond)==1) then
                  wght=hz
                  if ((mm-nh)*ran()<=wght*prob*beta) then  
                     opstring(i)=8*bond+6
                     nh=nh+1
                     nh4=nh4+1
                  endif
               elseif (spin(bond)==-1) then
                  wght=hz
                  if ((mm-nh)*ran()<=wght*prob*beta) then  
                     opstring(i)=8*bond+6
                     nh=nh+1
                     nh4=nh4+1
                  endif
               endif
            endif
         endif
      elseif(mod(op,2)==0) then
         typ=int(mod(op,8)/2)+1
         b=int(op/8)

         cs=1d0
         if (typ==1 .or. typ==2) then
            do j=1,mxl
               if (bsites(j,b)==-1) then
                  exit
               else
                  cs=cs*spin(bsites(j,b))
               endif
            enddo
         elseif (typ==3 .or. typ==4) then
            cs=cs*spin(b)
         endif
         !if (typ==2) print*,typ,j

         if (typ==1) then
            wght=cweightable(int((cs+1)/2),weightab(b,prid))
         elseif (typ==2) then
            wght=sweightable(int((cs+1)/2),weightab(b,prid))
         elseif (typ==3) then
            if (basis==0) then
               if (cs==1) then
                  wght=hx
               elseif (cs==-1) then
                  wght=hx
               endif 
            elseif (basis==1) then
               if (cs==1) then
                  wght=4d0*hx
               elseif (cs==-1) then
                  wght=2d0*hx
               endif 
            endif
         elseif (typ==4) then
            if (basis==0) then
               if (cs==1) then
                  wght=4d0*hz
               elseif (cs==-1) then
                  wght=2d0*hz
               endif 
            elseif (basis==1) then
               if (cs==1) then
                  wght=hz
               elseif (cs==-1) then
                  wght=hz
               endif 
            endif
         endif

         if (prob*beta*wght*ran()<=(mm-nh+1)) then
            opstring(i)=0d0
            nh=nh-1
            if (typ==1) then
               nh1=nh1-1
               !if (basis==1) nhpm(b,int((cs+1)/2))=nhpm(b,int((cs+1)/2))-1
            elseif (typ==2) then
               nh2=nh2-1
               !if (basis==0) nhpm(b,int((cs+1)/2))=nhpm(b,int((cs+1)/2))-1
            elseif (typ==3) then
               nh3=nh3-1
            elseif (typ==4) then
               nh4=nh4-1
            endif
         endif   
      else
         typ=int(mod(op,8)/2)+1
         b=int(op/8)
         if (typ<=2) then
            do j=1,mxl
               stmp=bsites(j,b)
               if (stmp==-1) then
                  exit
               else
                  spin(stmp)=-spin(stmp)
               endif
            enddo
         else
            if (basis==0d0) then
               if (typ==3d0) spin(b)=-spin(b)
            elseif (basis==1d0) then
               if (typ==4d0) spin(b)=-spin(b)
            endif
         endif
      endif
   enddo

end subroutine diagonalupdate
!==================================================!

!==================================================!

subroutine linkvertices(s)
   use configuration
   implicit none

   integer :: b,op,s1,s2,v0,dv,v1,v2,i,j,k,l,typ,sig,a,s,tmp
   real(8), external :: ran

   frstspinop(:)=-1
   lastspinop(:)=-1
   vertexspin(:,:)=-2
   tmp=0d0
   legtot=0d0
   if (lx>=4) then
      if (s==2) then
         updtyp=1
         slpb=slprob
      else
         updtyp=0
         slpb=2d0
      endif
   else
      updtyp=1
      slpb=slprob
   endif 
   !slpb=1d0 

   do v0=0, dxl*mm-1, dxl
      op=opstring(int(v0/(dxl)))
      if ( op==0 ) then
         vertexlist(v0:v0+dxl-1,:)=0
         vertexlist_map(v0:v0+dxl-1)=-1
      else
         b=op/8
         typ=int(mod(op,8)/2)+1

         if (typ<=2) then
            do i=1,mxl
               s1=bsites(i,b)
               dv=i-1
               if (s1==-1) then
                  vertexlist(v0+dv,:)=0
                  vertexlist(v0+dv+mxl,:)=0
                  vertexlist_map(v0+dv)=-1
                  vertexlist_map(v0+dv+mxl)=-1
                  cycle
               endif
               v1=lastspinop(s1)
               if ( v1/=-1 ) then
                  vertexlist(v1,:)=0
                  vertexlist(v0+dv,:)=0
                  vertexlist_map(v1)=v0+dv
                  vertexlist_map(v0+dv)=v1
                  legtot=legtot+2
               else
                  frstspinop(s1)=v0+dv
               endif
               lastspinop(s1)=v0+dv+mxl  
            enddo         
         else
            s1=b
            dv=0
            v1=lastspinop(s1)
            if ( v1/=-1 ) then
               vertexlist(v1,:)=0
               vertexlist(v0+dv,:)=0
               vertexlist_map(v1)=v0+dv
               vertexlist_map(v0+dv)=v1
               legtot=legtot+2
            else
               frstspinop(s1)=v0+dv
            endif
            lastspinop(s1)=v0+dv+mxl 

            do i=2,mxl
               s1=bsites(i,b)
               dv=i-1
               vertexlist(v0+dv,:)=0
               vertexlist(v0+dv+mxl,:)=0
               vertexlist_map(v0+dv)=-1
               vertexlist_map(v0+dv+mxl)=-1
            enddo  
         endif
       endif
    enddo

   do s1=1,nn
      v1=frstspinop(s1)
      if ( v1/=-1 ) then
         v2=lastspinop(s1)
         vertexlist(v2,:)=0
         vertexlist(v1,:)=0
         vertexlist_map(v2)=v1
         vertexlist_map(v1)=v2
         legtot=legtot+2
       end if
    enddo

   call random_tau()
   !print*,"link 0",nh,size(oporder, dim=1)

   if ( size(oporder, dim=1)/=nh ) then
      deallocate(oporder)
      allocate(oporder(nh))
      deallocate(opertyp)
      allocate(opertyp(nh))
      deallocate(dealtyp)
      allocate(dealtyp(nh))
      deallocate(opflip)
      allocate(opflip(nh))
      deallocate(opvtab)
      allocate(opvtab(nh))
      deallocate(opvlog)
      allocate(opvlog(nh))
      deallocate(opflog)
      allocate(opflog(nh))
      deallocate(opftab)
      allocate(opftab(nh))
   endif
   opvtab(:)=0
   opvlog(:)=0
   opflog(:)=0
   opftab(:)=0
   oporder(:)=0
   opertyp(:)=0
   dealtyp(:)=0
   opflip(:)=0
   !if ( size(ofoporder, dim=1)/=! ) then
   !   deallocate(ofoporder)
   !   allocate(ofoporder(nh1))
   !endif
   !ofoporder(:)=0
   !print*,"link 1",nh,size(oporder, dim=1)

   do
      j=nh
      a=nh1
      l=0
      tmp=0d0
      do i=0,mm-1
         op=opstring(i)
         !print*,"link 0.0",i,op
         if (op==0) then
            tauscale(i)=j
               cycle
         endif
         b=op/8
         typ=int(mod(op,8)/2)+1
         sig=mod(op,2)
         j=mod(j,nh)+1
         oporder(j)=i
         !print*,"link 0.1",i,j,nh,mm 

         if (typ<=2) then
            do k=1,mxl
               s1=bsites(k,b)
               if (s1==-1) exit
               if (sig==1d0) then
                  spin(s1)=-spin(s1)
               endif
               !print*,k-1,i,s1,size(vertexspin, dim=1)
               vertexspin(k-1,i)=spin(s1)
            enddo   
         else
            s1=b
            !if (b>nn) print*,b
            if (sig==1d0) then
               spin(s1)=-spin(s1)
            endif
         vertexspin(0,i)=spin(s1)  
         endif 
         tauscale(i)=j


         if (basis==0) then
            if (typ==1 .or. typ==3) then
               l=l+1
               opertyp(j)=1
               !a=mod(a,nh1)+1
               !ofoporder(a)=i
               if (typ==1) then
                  !dealtyp(j)=int(2*ran())
                  if (ran()<slpb) then
                     dealtyp(j)=1
                     tmp=tmp+1
                  else
                     dealtyp(j)=0
                  endif
               elseif (typ==3d0) then
                  dealtyp(j)=1d0
                  tmp=tmp+1
               else
                  dealtyp(j)=0d0
               endif
            endif
         elseif (basis==1) then
            if (typ==2 .or. typ==4) then
               l=l+1
               opertyp(j)=1
               !a=mod(a,nh1)+1
               !ofoporder(a)=i
               if (typ==2) then
                  !dealtyp(j)=int(2*ran())
                  if (ran()<slpb) then
                     dealtyp(j)=1
                     tmp=tmp+1
                  else
                     dealtyp(j)=0
                  endif
               elseif (typ==4d0) then
                  dealtyp(j)=1d0
                  tmp=tmp+1
               else
                  dealtyp(j)=0d0
               endif
            endif
         endif 
      enddo
      if (l==0d0 .or. slpb==0d0) then
         !print*,"l,slpb",l,slpb
         exit
      endif  
      if (l/=0d0 .and. slpb/=0d0 .and. tmp/=0d0) then
         !print*,"l,slpb,tmp",l,slpb,tmp
         exit
      endif 
   enddo

   !do i=0, dxl*mm-1
      !if (vertexlist(i,0)==0 .and. vertexlist_map(i)==-1) then
         !if (mod(i,dxl)>=mxl) then
            !if (vertexspin(mod(i,dxl)-mxl,i/(dxl))/=-1) print*,"check1"
         !endif
      !elseif (vertexlist_map(i)>=0) then
         !if (mod(i,dxl)>=mxl) then
            !if (vertexspin(mod(i,dxl)-mxl,i/(dxl))/=-1 .and. vertexspin(mod(i,dxl)-mxl,i/(dxl))/=1) print*,"check2"
         !endif
      !else
         !print*,"check...."
      !endif
   !enddo

   !call spinchecker()

 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


end subroutine linkvertices
!==================================================!

!==================================================!

subroutine clusterupdate(prid,clustermax,sign)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,k,leg_in,vo,vidx,lengts,clusternum,prid,clustermax,sign,self
   real(8) :: clsiz
   real(8), external :: ran

   clustermark=0
   update_counter=0d0
   aclcrr=0d0
   
   !do v0=0,dxl*mm-1,1
      !if (vertexlist_map(v0)==-1) cycle

   !print*,"mxl",mxl,"dxl",dxl
   !pause
   if (aclpre<0 .or. slpb==2d0) then
      self=0d0
   else
      self=1d0
   endif

   i=0d0 
   do 
      !if (i>=1) exit
      if (update_counter>=clustermax) exit
      !if (update_counter>=-1) exit

      !do j=0,dxl*mm-1
         !if (vertexlist(j,0)>0) vertexlist(j,0)=0
      !enddo
      
      call clusterbuilding()

      !print*,"clusterbuilding"

      call clusterflbprb(prid)

      !print*,"clusterflbprb"
      
      !print*,"prob",probnum
      open(10,file=culgname,position='append')
      clsiz=dble(legcon)/dble(legtot)
      if (ran()<(2d0**(probnum*1d0)) .and. clustermark/=0d0) then
         call clusterfliper(prid)
         write(10,*)clsiz,dble(sum(dealtyp(:)))/dble(sum(opertyp(:))),1
         aclcrr=aclcrr+clsiz
      else
         write(10,*)clsiz,dble(sum(dealtyp(:)))/dble(sum(opertyp(:))),0
      endif
      close(10)

      i=i+1

   enddo
   aclcrr=dble(aclcrr)/dble(i)
   if (self==1d0) then
      !print*,aclcrr,aclpre,slprob*(aclcrr)/(aclpre*1d0)
      !slprob=slprob*(aclpre)/(aclcrr*1d0)
   endif
   if (aclcrr/=0d0) aclpre=aclcrr

   !call clusterupding()

   do i=1,nn
      if (frstspinop(i)==-1) then
         if ( ran()*(2)<1 ) then
            if (sign==1) spin(i)=-spin(i)
         endif
      endif
   enddo

end subroutine clusterupdate
!==================================================!

!==================================================!

subroutine initdealtyp(btmp,typtmp,mmtmp)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,k,btmp,typtmp,mmtmp
   real(8), external :: ran

   if (dealtyp(tauscale(mmtmp))==-1) then
      if (typtmp==legtyp(1)) then
         !if (ran()<slpb) then
         !if (mmt==mm0) then
         !print*,btmp,b0,typtmp,typ0
         if (btmp==b0 .and. typtmp==typ0) then 
            dealtyp(tauscale(mmtmp))=1
         else
            dealtyp(tauscale(mmtmp))=0
         endif
         !print*,dealtyp(tauscale(mmtmp))
      elseif (typtmp==legtyp(2)) then
         !if (ran()<slpb) then
         !if (mmt==mm0) then
         !if (btmp==b0 .and. typtmp==typ0) then 
            dealtyp(tauscale(mmtmp))=1
         !else
            !dealtyp(tauscale(mmtmp))=0
         !endif
         !print*,dealtyp(tauscale(mmtmp))
      else
         dealtyp(tauscale(mmtmp))=0
      endif
   endif

end subroutine initdealtyp
!==================================================!

!==================================================!

subroutine clusterbuilding()
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,k,l,leg_in,vo,vidx,lengts,clusternum,test,test2,dv,dtmp2,btmp2,typtmp2,mmtmp1,mmtmp2,optmp2
   real(8) :: tautmp,tmp1,tmp2,tmp3,tmp4
   integer, allocatable :: space(:)
   real(8), external :: ran

   allocate(space(nn))
   space(:)=0d0


   clustermark=1
   mrk0=clustermark
   mrk1=mrk0+1
   length=0d0
   vertexlist(:,:)=0d0
   opflip(:)=0d0
   opvlog(:)=0d0
   opvtab(:)=0d0
   opflog(:)=0d0
   opftab(:)=0d0
   legcon=0d0
   !dealtyp(:)=-1

   !i=nh
   !tautmp=ran()*beta
   !do 
      !if (i/=nh) then
         !if (tautmp>=rantau(i) .and. tautmp<rantau(mod(i,nh)+1)) exit
      !else
         !if (tautmp>=rantau(nh) .or. tautmp<rantau(1)) exit
      !endif
      !i=mod(i,nh)+1
   !enddo

   !j=int(mod(opstring(oporder(i)),8)/2)+1
   !if (j==1) then
      !v0=dxl*oporder(i)+int(mxl*ran())+mxl
   !elseif (j==2) then
      !v0=dxl*oporder(i)+int(4*ran())+mxl
   !elseif (j==3) then
      !v0=dxl*oporder(i)+mxl
   !elseif (j==4) then
      !v0=dxl*oporder(i)+mxl
   !endif
   !if (vertexlist_map(v0)<0) then
      !print*,int(mod(opstring(oporder(i)),8)/2)+1,v0-dxl*oporder(i),vertexlist_map(v0)
      !pause
   !endif

   do 
      v0=int(dxl*mm*ran())
      !if (vertexlist_map(v0)>0 .and. opertyp(tauscale(int(v0/(dxl))))>=1) exit
      if (vertexlist_map(v0)>0 .and. dealtyp(tauscale(int(v0/(dxl))))>=1) exit
   enddo

   !do 
   !   v0=dxl*ofoporder(int(nh1*ran())+1)
   !   if (vertexlist_map(v0)>0 .and. opertyp(tauscale(int(v0/(dxl))))>=1) exit
   !enddo

   mm0=int(v0/(dxl))
   op0=opstring(mm0)
   b0=int(op0/8)
   typ0=int(mod(op0,8)/2)+1
   !if (dealtyp(tauscale(mm0))==-1) call initdealtyp(b0,typ0,mm0)
   dltyp0=dealtyp(tauscale(mm0))
   !print*,"b0",b0

   !_____________________________________________________________

   mmtmp1=int(v0/(dxl))
   dv=mod(v0,dxl)
   mmtmp2=int(vertexlist_map(v0)/(dxl))
   optmp2=opstring(mmtmp2)
   btmp2=int(optmp2/8)
   typtmp2=int(mod(optmp2,8)/2)+1
   !if (dealtyp(tauscale(mmtmp2))==-1) call initdealtyp(btmp2,typtmp2,mmtmp2)
   !dtmp2=dealtyp(tauscale(mmtmp2))

   if (updtyp==0) then
      if (btmp2==b0 .and. typtmp2==typ0 .and. dealtyp(tauscale(mmtmp2))==1) then 
         dtmp2=1
      else
         dtmp2=0
      endif
   elseif (updtyp==1) then
      dtmp2=dealtyp(tauscale(mmtmp2))
   endif
   tmp1=vertexlist_map(v0)
   tmp3=btmp2
   if (dtmp2==1) then  
      call clusterluch(dxl*mmtmp1,dv)
   else
      vertexlist(vertexlist_map(v0),0)=mrk1
      vertexlist(vertexlist_map(v0),1)=vertexlist(vertexlist_map(v0),1)+1
      opflog(tauscale(int(vertexlist_map(v0)/dxl)))=opflog(tauscale(int(vertexlist_map(v0)/dxl)))+1
      length=length+1
      opvlog(tauscale(int(vertexlist_map(v0)/dxl)))=opvlog(tauscale(int(vertexlist_map(v0)/dxl)))+1
      nhk1=nhk1+1
   endif

   mmtmp1=int(vertexlist_map(v0)/(dxl))
   dv=mod(vertexlist_map(v0),dxl)
   mmtmp2=int(v0/(dxl))
   optmp2=opstring(mmtmp2)
   btmp2=int(optmp2/8)
   typtmp2=int(mod(optmp2,8)/2)+1
   !if (dealtyp(tauscale(mmtmp2))==-1) call initdealtyp(btmp2,typtmp2,mmtmp2)
   !dtmp2=dealtyp(tauscale(mmtmp2))
   if (updtyp==0) then
      if (btmp2==b0 .and. typtmp2==typ0 .and. dealtyp(tauscale(mmtmp2))==1) then 
         dtmp2=1
      else
         dtmp2=0
      endif
   elseif (updtyp==1) then
      dtmp2=dealtyp(tauscale(mmtmp2))
   endif
   tmp2=v0
   tmp4=btmp2
   if (dtmp2==1) then
      call clusterluch(dxl*mmtmp1,dv)
   else
      vertexlist(v0,0)=mrk1
      vertexlist(v0,1)=vertexlist(v0,1)+1
      opflog(tauscale(int(v0/dxl)))=opflog(tauscale(int(v0/dxl)))+1
      length=length+1
      opvlog(tauscale(int(v0/dxl)))=opvlog(tauscale(int(v0/dxl)))+1
      nhk1=nhk1+1
   endif

   !wprint*,"========================================="
   !space(:)=0d0
   !do j=0,mm-1
   !   test2=0d0
      !print*,"vertexlist",vertexlist(dxl*j:dxl*j+dxl-1,1)
   !   do k=0,dxl-1
   !     i=dxl*j+k
   !      if (vertexlist(i,1)>0) then
   !         if (int(mod(opstring(j),8)/2)+1<=2) then 
   !            space(bsites(mod(k,mxl)+1,int(opstring(j)/8)))=1
   !            print*,"chec0",i,k,bsites(mod(k,mxl)+1,int(opstring(j)/8)),int(opstring(j)/8)
   !            print*,"chec0",int(mod(opstring(j),8)/2)+1,dealtyp(tauscale(j))
   !            print*,"chec0",vertexlist(i,0),mrk0,mrk1
   !         endif
   !         if (int(mod(opstring(j),8)/2)+1>=3) space(int(opstring(j)/8))=1
   !      endif
      !print*,k
   !   enddo
   !enddo

   space(:)=0d0

   !print*,"length",length,tmp1,tmp3
   !print*,"b0",b0,tmp2,tmp4
   !print*,"========================================="

   do while(length>0)

      !test=0d0
      !do j=0,mm-1
      !   test2=0d0
      !   !print*,"vertexlist",vertexlist(dxl*j:dxl*j+dxl-1,1)
      !   do k=0,dxl-1
      !     i=dxl*j+k
      !      if (vertexlist(i,1)>0) then
      !         if (int(mod(opstring(j),8)/2)+1<=2) then 
      !            space(bsites(mod(k,mxl)+1,int(opstring(j)/8)))=1
      !            print*,"check",i,k,sitnum,bsites(mod(k,mxl)+1,int(opstring(j)/8)),int(mod(opstring(j),8)/2)+1,dealtyp(tauscale(j))
      !         endif
      !         if (int(mod(opstring(j),8)/2)+1>=3) space(int(opstring(j)/8))=1
      !      endif
      !   !print*,k
      !   enddo
      !enddo
      !print*,length,clustermark,sum(space),dxl
      !if (sum(space)==5) pause

      if (length<0) then
         print*,"WARNING++++++++++length=",length,"+++++++++++++++++++++++"
      endif

      lengts=length


      clustermark=clustermark+1
      mrk0=clustermark
      mrk1=mrk0+1
      
      call initable(0)

      do i=1,nh
         !mmt=oporder(i)

         l=opvtab(i)
         if (l==0d0) exit
         mmt=oporder(l)

         vt=dxl*mmt
         opt=opstring(mmt)
         bt=int(opt/8)
         typt=int(mod(opt,8)/2)+1
         sigt=mod(opt,2)
         !if (dealtyp(tauscale(mmt))==-1) call initdealtyp(bt,typt,mmt)
         !dltypt=opertyp(tauscale(mmt))
         dltypt=dealtyp(tauscale(mmt))

         !print*,i,sigt,typt,vt

         if (typt==1) then
            call clustermaker(dxl,dltypt,typt)
         elseif (typt==2) then
            if (lz==1) then
               call clustermaker(dxl,dltypt,typt)
            else
               call clustermaker(8,dltypt,typt)
            endif
         elseif(typt==3) then
            call clustermaker(2,dltypt,typt)
         elseif(typt==4) then
            call clustermaker(2,dltypt,typt)
         endif
      enddo
   enddo

   call initable(1)

   !print*,"========================================="
   !space(:)=0d0
   !do j=0,mm-1
   !   test2=0d0
   !   !print*,"vertexlist",vertexlist(dxl*j:dxl*j+dxl-1,1)
   !   do k=0,dxl-1
   !     i=dxl*j+k
   !      if (vertexlist(i,1)>0) then
   !         if (int(mod(opstring(j),8)/2)+1<=2) then 
   !            space(bsites(mod(k,mxl)+1,int(opstring(j)/8)))=1
   !            !print*,"chec0",i,k,bsites(mod(k,mxl)+1,int(opstring(j)/8)),int(opstring(j)/8)
   !            !print*,"chec0",int(mod(opstring(j),8)/2)+1,dealtyp(tauscale(j))
   !            !print*,"chec0",vertexlist(i,0),mrk0,mrk1
   !         endif
   !         if (int(mod(opstring(j),8)/2)+1>=3) space(int(opstring(j)/8))=1
   !      endif
   !   !print*,k
   !   enddo
   !enddo

   !space(:)=0d0

   !print*,"length",length,tmp1,tmp3
   !print*,"b0",b0,tmp2,tmp4
   !print*,length,clustermark,sum(space),dxl
   !if (sum(space)/=5) then
   !   print*,sum(space)
   !   pause
   !endif
   !print*,"========================================="

end subroutine clusterbuilding
!==================================================!
!==================================================!

subroutine initable(c)

   use configuration
   implicit none
   integer :: i,j,k,c

   if (c==0d0) then
      opvtab(:)=0d0
      j=1
      k=0
      do i=1,nh
         if (opvlog(i)==0) cycle
         opvtab(j)=i
         j=j+1
      enddo
      nhk0=j-1
      opvlog(:)=0d0
      !nhk0=nhk1
      nhk1=0d0
   elseif (c==1d0) then
      opftab(:)=0d0
      j=1
      k=0
      do i=1,nh
         if (opflog(i)+opflip(i)==0) cycle
         legcon=legcon+opflog(i)
         k=k+1
         opftab(j)=i
         j=j+1
         !print*,"op",i,opflog(i),opflip(i)
      enddo
      nhk1=0d0
   endif

end subroutine initable

!==================================================!

!==================================================!

subroutine spinchecker()

   use configuration
   implicit none

   integer :: b,op,s1,s2,v0,dv,v1,v2,i,j,k,l,typ,sig,ctmp,stmp
   integer, allocatable :: spintest(:)
   integer, allocatable :: pich(:)

   allocate(spintest(nn))
   allocate(pich(ly))
   ctmp=0d0
   pich(:)=1d0

   spintest(:)=spin(:)

   do j=1, ly
      stmp=1+mod(lx-1+lx,lx)+mod(j-1+ly,ly)*lx
      pich(j)=pich(j)*spin(stmp+sitnum)
      s1=stmp
      stmp=1+mod(lx-1+lx,lx)+mod(j+ly,ly)*lx
      pich(j)=pich(j)*spin(stmp)
      s2=stmp
      stmp=1+mod(lx-1+lx,lx)+mod(j-1+ly,ly)*lx
      pich(j)=pich(j)*spin(stmp)

      !print*,s1+sitnum,s1,s2
      !print*,bontab(s1+sitnum),bontab(s1),bontab(s2)
      !print*,spin(s1+sitnum),spin(s1),spin(s2),pich(j)
   enddo
   do j=1, ly
      !if (pich(j)/=1) pause
   enddo


   j=nh
   do i=0,mm-1
      op=opstring(i)
      if (op==0) then
         cycle
      endif
      b=op/8
      typ=int(mod(op,8)/2)+1
      sig=mod(op,2)
      j=mod(j,nh)+1
      if (typ<=2) then
         do k=1,mxl
            s1=bsites(k,b)
            if (s1==-1) exit
            if (sig==1d0) then
               spintest(s1)=-spintest(s1)
            endif
            if (vertexspin(k-1,i)/=spintest(s1)) then 
               print*,"spinerror_1",b,typ,sig,j
               print*,"spinerror_1",opflog(j),dealtyp(j),opflip(j)
               print*,"spinerror_1",vertexlist(i*dxl:i*dxl+mxl-1,1)
               print*,"spinerror_1",vertexlist(i*dxl+mxl:i*dxl+mxl+mxl-1,1)
               !pause
            endif
         enddo   
      else
         s1=b
         if (b>nn) print*,b
         if (sig==1d0) then
            spintest(s1)=-spintest(s1)
         endif
         k=1
         if (vertexspin(k-1,i)/=spintest(s1)) then 
            print*,"spinerror_2",i,b,k,spintest(s1),vertexspin(k-1,i)
            !pause
         endif
      endif

   enddo

   do i=1,nn
      if (spintest(i)/=spin(i)) then 
         print*,"spinerror_3"
         !pause
      endif
   enddo

end subroutine spinchecker


!==================================================!

subroutine clustermaker(legnum,dealsign,tt)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,k,legmax,legnum,dealsign,vv,dv1,dv2,dv3,dv4,tt,udd,legcounter
   real(8) :: tmp1,tmp2
   real(8), external :: ran
   integer, allocatable :: legorder(:)
   real(8), allocatable :: legranod(:)
   allocate(legorder(0:dxl-1))
   allocate(legranod(0:dxl-1))

   legorder(:)=-1d0
   legranod(:)=beta
   legcounter=0d0
   legmax=legnum/2-1
   dv1=0d0
   dv2=0d0
   dv3=0d0
   dv4=0d0

   if (dealsign==0) then
      !print*,"diagonal clustermaker",vt,typt,legmax,length,mrk0
      do i=0,legmax
         dv1=i
         call clustermkr1(dv1,0)
         
         dv1=i+mxl
         call clustermkr1(dv1,1)
      enddo

      update_counter=update_counter+1

   elseif (dealsign==1) then

      do i=0,mxl-1
         if (vertexlist_map(dxl*mmt+i)<0) exit
         if (vertexlist(dxl*mmt+i,0)==mrk0) then
            legcounter=legcounter+1
            tmp1=ran()*beta
            !dv1=i
            !vv=mmt
            !do     
               !vv=dxl*vv
               !vv=vertexlist_map(vv+dv1)
               !dv1=mod(mod(vv,dxl)+mxl,dxl)
               !vv=int(vv/(dxl))
               !if (opertyp(tauscale(vv))==1d0) exit
            !enddo
            !tmp1=mod(rantau(tauscale(mmt))-rantau(tauscale(vv))+beta,beta)
            do k=0,dxl-1
               if (legranod(k)>tmp1) then
                  j=k
                  exit
               endif
            enddo
            do k=0,dxl-2-j
               legorder(dxl-1-(k))=legorder(dxl-1-(k+1))
               legranod(dxl-1-(k))=legranod(dxl-1-(k+1))
            enddo
            legorder(j)=i
            legranod(j)=tmp1
            tmp1=0d0
         endif

         if (vertexlist(dxl*mmt+i+mxl,0)==mrk0) then
            legcounter=legcounter+1
            tmp1=ran()*beta
            !dv1=i+mxl
            !vv=mmt
            !do     
               !vv=dxl*vv
               !vv=vertexlist_map(vv+dv1)
               !dv1=mod(mod(vv,dxl)+mxl,dxl)
               !vv=int(vv/(dxl))
               !if (opertyp(tauscale(vv))==1d0) exit
            !enddo
            !tmp1=mod(rantau(tauscale(vv))-rantau(tauscale(mmt))+beta,beta)
            do k=0,dxl-1
               if (legranod(k)>tmp1) then
                  j=k
                  exit
               endif
            enddo
            do k=0,dxl-2-j
               legorder(dxl-1-(k))=legorder(dxl-1-(k+1))
               legranod(dxl-1-(k))=legranod(dxl-1-(k+1))
            enddo
            legorder(j)=i+mxl
            legranod(j)=tmp1
            tmp1=0d0
         endif
      enddo 

      !k=0
      !do j=0,dxl-1
      !   if (legorder(j)/=-1) k=k+1
      !enddo
      !if (legcounter/=k) then
         !print*,"346.6",k,legcounter,i,mrk0
         !print*,legorder(mxl:mxl+mxl-1)
         !print*,legorder(0:mxl-1)
         !print*,legranod(mxl:mxl+mxl-1)
         !print*,legranod(0:mxl-1)
         !print*,vertexlist(dxl*mmt+mxl:dxl*mmt+mxl+mxl-1,0)
         !print*,vertexlist(dxl*mmt+0:dxl*mmt+mxl-1,0)
         !pause
      !endif

      !if (sum(vertexlist(dxl*mmt+mxl:dxl*mmt+dxl-1,0))/=0d0) then
         !print*,vertexlist(dxl*mmt+mxl:dxl*mmt+dxl-1,0)
         !print*,legorder(mxl:dxl-1)
         !print*,legranod(mxl:dxl-1)
         !print*,vertexlist(dxl*mmt:dxl*mmt+mxl-1,0)
         !print*,legorder(0:mxl-1)
         !print*,legranod(0:mxl-1)
      !endif

      !print*,legcounter(:)

      if (legcounter>0) then
         cmplsg(:)=0d0
         selfcest=0d0
         tmp1=0d0
         tmp2=0d0

         do i=0,legnum-1
            dv1=legorder(i)
            !print*,dv1,dv2
            if (dv1==-1) exit
            if (cmplsg(0)==1 .and. cmplsg(1)==1) exit
            if (vertexlist(dxl*mmt+dv1,0)/=mrk0) cycle
            if (dv1>=0 .and. dv1<=mxl-1) then
               udd=0
            elseif (dv1>=mxl .and. dv1<=dxl-1) then
               udd=1
            endif
            if (cmplsg(udd)==1) cycle

            !tmp1=ran()
            !legcounter=1
            !if (ran()>0.5d0) then
               !legcounter=1
            !else
               !legcounter=0
            !endif
            !legcounter=2

            if (updtyp==0d0) then
               if (bt==b0 .and. typt==typ0) then 
                  legcounter=1
               else
                  legcounter=0
               endif
            elseif (updtyp==1d0) then
               legcounter=dealsign
            endif

            !if (typt<=2) then
               !if (dealtyp(tauscale(mmt))==-1) then
                  !if (ran()<slpb) then
                  !if (mmt==mm0) then
                     !dealtyp(tauscale(mmt))=1
                  !else
                     !dealtyp(tauscale(mmt))=0
                  !endif
               !endif
               !legcounter=dealtyp(tauscale(mmt))
            !else
               !legcounter=1
            !endif
            !if (legcounter/=1 .and. legcounter/=0) then
               !print*,"legcounter",legcounter
               !pause
            !endif

            !if (dealtyp(tauscale(mmt))==-1) call initdealtyp(bt,typt,mmt)
            !legcounter=dealtyp(tauscale(mmt))
            
            !if (legcounter==0d0) call clustermkr1(dv1,udd)

            if (legcounter==0d0) then
               do j=0,legmax
                  dv2=mod(j+udd*mxl,dxl)
                  if (vertexlist(dxl*mmt+dv2,0)/=mrk0) cycle
                  call clustermkr1(dv2,udd)
               enddo
               cmplsg(udd)=1d0
            endif


            if (legcounter==1d0) then
               do j=0,legmax
                  dv2=mod(j+udd*mxl,dxl)
               
                  if (cmplsg(udd)==0d0) then
                     !print*,"mkr2",udd,j
                     call clustermkr2(dv2,udd)
                  endif

                  !if (selfcest/=0) print*, selfcest
                  !print*,cmplsg(:)

                  !if (legcounter(1)==1d0 .and. cmplsg(1)==0d0) then
                  !   call clustermkr2(dv2,1)
                  !endif
                  !if (mrk0==-3) vertexspin(i,mmt)=-vertexspin(i,mmt)
               enddo

               !if (legcounter==1d0) then
               !   legcounter=2d0
               !   opflip(tauscale(mmt))=opflip(tauscale(mmt))+1
               !endif
               !if (legcounter(1)==1d0) then
               !   legcounter(1)=2d0
               !   opflip(tauscale(mmt))=opflip(tauscale(mmt))+1
               !endif
               !update_counter=update_counter+int(legnum/2)
               cmplsg(udd)=1d0
               opflip(tauscale(mmt))=opflip(tauscale(mmt))+1
               !update_counter=update_counter+1
            endif

            if (legcounter==2d0) then
               do j=0,legmax
                  dv2=mod(j+udd*mxl,dxl)
                  if (cmplsg(udd)==0d0) then
                     call clustermkr3(dv2,udd)
                  endif
               enddo
               cmplsg(udd)=1d0
               opflip(tauscale(mmt))=opflip(tauscale(mmt))+1
            endif

            if (legcounter==3d0) then
               do j=0,legmax
                  dv2=mod(j+udd*mxl,dxl)
                  call clustermkr4(dv2,udd)
               enddo
               cmplsg(udd)=1d0
            endif

         enddo
      endif
      update_counter=update_counter+1


   endif

end subroutine clustermaker
!==================================================!

!==================================================!

subroutine clustermkr1(dv1,uds)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,vv,dv1,dv2,tt,uds,ud

   !legcounter=0d0
   !leg=0d0
   !dv1=0d0
   dv2=mod(dv1+mxl,dxl)
   !dv3=0d0
   !dv4=0d0
   
   if (vertexlist(vt+dv1,0)==mrk0) then
      vertexlist(vt+dv1,0)=0
      length=length-1
      !print*,"diagonal clustermaking",vt+dv1,vt+dv2
      if (vertexlist(vt+dv2,0)==mrk0) then
         vertexlist(vt+dv2,0)=0
         length=length-1
      elseif (vertexlist(vt+dv2,0)==mrk1) then
         vertexlist(vt+dv2,0)=0
         length=length-1
      else
         vertexlist(vt+dv2,0)=0
         vertexlist(vt+dv2,1)=vertexlist(vt+dv2,1)+1
         opflog(tauscale(int(vt/dxl)))=opflog(tauscale(int(vt/dxl)))+1
         call clusterluch(vt,dv2)
         !update_counter=update_counter+1
      endif
   endif

end subroutine clustermkr1
!==================================================!

!==================================================!

subroutine clustermkr2(dv1,uds)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,vv,dv1,tt,uds,mmd

   !dv1=0d0
   !dv2=0d0
   !dv3=0d0
   !dv4=0d0

   mmd=int(vertexlist_map(vt+dv1)/(dxl))
   !cmplsg(uds+2)=cmplsg(uds+2)+1

   if (vertexlist(vt+dv1,0)==mrk0) then
      vertexlist(vt+dv1,0)=0
      length=length-1
      !vertexlist(vt+dv1,1)=vertexlist(vt+dv1,1)+1
   elseif (vertexlist(vt+dv1,0)==mrk1) then
      vertexlist(vt+dv1,0)=0
      length=length-1
      !vertexlist(vt+dv1,1)=vertexlist(vt+dv1,1)+1
   elseif (vertexlist(vt+dv1,0)==0) then
      vertexlist(vt+dv1,1)=vertexlist(vt+dv1,1)+1
      opflog(tauscale(int(vt/dxl)))=opflog(tauscale(int(vt/dxl)))+1
      call clusterluch(vt,dv1)
   else
      print*,"missing mkr2",vertexlist(vt+dv1,0)
   endif

   !if (int(vertexlist_map(vt+dv1)/(dxl))/=mmt) cmplsg(uds+2)=cmplsg(uds+2)+1

end subroutine clustermkr2
!==================================================!

!==================================================!

subroutine clustermkr3(dv1,uds)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,vv,dv1,dv2,tt,uds,ud

   !legcounter=0d0
   !leg=0d0
   !dv1=0d0
   !dv2=0d0
   !dv3=0d0
   !dv4=0d0
   
   if (vertexlist(vt+dv1,0)==mrk0) then
      vertexlist(vt+dv1,0)=0
      length=length-1
   elseif (vertexlist(vt+dv1,0)==mrk1) then
      dv2=mod(dv1+mxl,dxl)
      if (vertexlist(vt+dv2,0)==mrk0) then
         vertexlist(vt+dv2,0)=0
         length=length-1
      elseif (vertexlist(vt+dv2,0)==mrk1) then
         vertexlist(vt+dv2,0)=0
         length=length-1
      else
         vertexlist(vt+dv2,1)=vertexlist(vt+dv2,1)+1
         opflog(tauscale(int(vt/dxl)))=opflog(tauscale(int(vt/dxl)))+1
         call clusterluch(vt,dv2)
      endif
   elseif (vertexlist(vt+dv1,0)==0) then
      dv2=mod(dv1+mxl,dxl)
      if (vertexlist(vt+dv2,0)==mrk0) then
         vertexlist(vt+dv2,0)=0
         length=length-1
      elseif (vertexlist(vt+dv2,0)==mrk1) then
         vertexlist(vt+dv2,0)=0
         length=length-1
      else
         vertexlist(vt+dv2,1)=vertexlist(vt+dv2,1)+1
         opflog(tauscale(int(vt/dxl)))=opflog(tauscale(int(vt/dxl)))+1
         call clusterluch(vt,dv2)
      endif
   endif

end subroutine clustermkr3
!==================================================!

!==================================================!

subroutine clustermkr4(dv1,uds)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,vv,dv1,dv2,tt,uds,ud

   !legcounter=0d0
   !leg=0d0
   !dv1=0d0
   !dv2=0d0
   !dv3=0d0
   !dv4=0d0
   
   if (vertexlist(vt+dv1,0)==mrk0) then
      vertexlist(vt+dv1,0)=0
      vertexlist(vt+dv1,1)=vertexlist(vt+dv1,1)+1
      opflog(tauscale(int(vt/dxl)))=opflog(tauscale(int(vt/dxl)))+1
      length=length-1
      call clusterluch(vt,dv1)
   endif

end subroutine clustermkr4
!==================================================!

!==================================================!

subroutine clusterluch(va,dv2)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,vv,mmv,dv1,dv2,dv3,dv4,leg,ud,va,d,tt,bv,demo
   integer, allocatable :: sumlog(:)
   allocate(sumlog(0:2))

   dv1=0d0
   !dv2=0d0
   dv3=0d0
   dv4=0d0
                  
   mmv=int(vertexlist_map(va+dv2)/(dxl))
   dv3=mod(vertexlist_map(va+dv2),dxl)
   dv4=mod(dv3+mxl,dxl)
   bv=int(opstring(mmv)/8)
   tt=int(mod(opstring(mmv),8)/2)+1
   !d=dealtyp(tauscale(mmv))if (typt<=2) then
   !if (dealtyp(tauscale(mmv))==-1) call initdealtyp(bv,tt,mmv)
   !d=dealtyp(tauscale(mmv))

   if (updtyp==0) then
      if (bv==b0 .and. tt==typ0 .and. dealtyp(tauscale(mmv))==1) then 
         d=1
      else
         d=0
      endif
   elseif (updtyp==1) then
      d=dealtyp(tauscale(mmv))
   endif
      !print*,tauscale(mmv),nh,d

   demo=0d0
   do
      if (dv3>=0 .and. dv3<=mxl-1) then
         ud=0
      elseif (dv3>=mxl .and. dv3<=dxl-1) then
         ud=1
      endif
      !tt=int(mod(opstring(mmv),8)/2)+1
      vv=mmv*dxl
      leg=0d0
      !sumlog=sum(vertexlist(dxl*mmv+ud*mxl:dxl*mmv+(ud+1)*mxl-1,1))
      sumlog=0d0
      !if (vertexlist(vertexlist_map(vv+dv4),0)==mrk1) then
      !   if (opertyp(tauscale(int(vertexlist_map(vv+dv4)/(dxl))))==0 .and. opertyp(tauscale(mmv))==0) then
      !      print*,"vertexlist_map(vv+dv4),0)==mrk1 .or. vertexlist_map(vv+dv4),0)==mrk0"
      !      print*,vertexlist(vertexlist_map(vv+dv4),0),mrk0,mrk1
      !      print*,opertyp(tauscale(mmv)),opertyp(tauscale(int(vertexlist_map(vv+dv4)/(dxl))))
      !      pause
      !   endif
      !endif

!--------------------------ready-----------------------------------------------------!
      !print*,"973",d

      if ((tt==legtyp(1) .or. tt==legtyp(2)) .and. d==1) then
      
         if (tt==1) then
            leg=mxl
         elseif (tt==2) then
            if (lz==1) then
               leg=mxl
            else
               leg=4d0
            endif
         elseif (tt==3 .or. tt==4) then
            leg=1
         endif



         do i=0,mxl-1
            if (vertexlist_map(dxl*mmv+ud*mxl+i)<0) exit
            if (vertexlist(dxl*mmv+ud*mxl+i,0)==mrk0) sumlog(0)=sumlog(0)+1
            if (vertexlist(dxl*mmv+ud*mxl+i,0)==mrk1) sumlog(1)=sumlog(1)+1
            !print*,sumlog
         enddo
         sumlog(2)=sumlog(0)+sumlog(1)

!--------------------------ready-----------------------------------------------------!

         if (vertexlist(vv+dv3,0)==mrk0) then
            vertexlist(vv+dv3,0)=0
            vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
            opflog(tauscale(int(vv/dxl)))=opflog(tauscale(int(vv/dxl)))+1
            length=length-1
         elseif (vertexlist(vv+dv3,0)==mrk1) then
            vertexlist(vv+dv3,0)=0
            vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
            opflog(tauscale(int(vv/dxl)))=opflog(tauscale(int(vv/dxl)))+1
            length=length-1
         else
            if (mmt==mmv) then
               if (sumlog(2)+1==leg) then
                  vertexlist(vv+ud*mxl:vv+ud*mxl+mxl-1,0)=0
                  vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
                  opflog(tauscale(int(vv/dxl)))=opflog(tauscale(int(vv/dxl)))+1
                  length=length-leg+1
                  opflip(tauscale(mmv))=opflip(tauscale(mmv))+1
                  update_counter=update_counter+1
               else
                  vertexlist(vv+dv3,0)=mrk1
                  vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
                  opflog(tauscale(int(vv/dxl)))=opflog(tauscale(int(vv/dxl)))+1
                  length=length+1
                  opvlog(tauscale(int(vv/dxl)))=opvlog(tauscale(int(vv/dxl)))+1
                  nhk1=nhk1+1
                  
                  !if (vertexlist(vv+dv4,0)==mrk0) then
                  !   vertexlist(vv+dv3,0)=0
                  !   vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
                  !   vertexlist(vv+dv4,0)=0
                  !   length=length-1
                  !elseif (vertexlist(vv+dv4,0)==mrk1) then
                  !   vertexlist(vv+dv3,0)=0
                  !   vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
                  !   vertexlist(vv+dv4,0)=0
                  !   length=length-1
                  !elseif (vertexlist(vv+dv4,0)==0) then
                  !   vertexlist(vv+dv3,0)=mrk1
                  !   vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
                  !   length=length+1
                  !else
                  !endif
               endif
            else
               if (sumlog(2)+1==leg) then
                  vertexlist(vv+ud*mxl:vv+ud*mxl+mxl-1,0)=0
                  vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
                  opflog(tauscale(int(vv/dxl)))=opflog(tauscale(int(vv/dxl)))+1
                  length=length-leg+1
                  opflip(tauscale(mmv))=opflip(tauscale(mmv))+1
                  update_counter=update_counter+1
               else
                  vertexlist(vv+dv3,0)=mrk1
                  vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
                  opflog(tauscale(int(vv/dxl)))=opflog(tauscale(int(vv/dxl)))+1
                  length=length+1
                  opvlog(tauscale(int(vv/dxl)))=opvlog(tauscale(int(vv/dxl)))+1
                  nhk1=nhk1+1
                  
                  !if (vertexlist(vv+dv4,0)==mrk0) then
                  !   vertexlist(vv+dv3,0)=0
                  !   vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
                  !   vertexlist(vv+dv4,0)=0
                  !   length=length-1
                  !elseif (vertexlist(vv+dv4,0)==mrk1) then
                  !   vertexlist(vv+dv3,0)=0
                  !   vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
                  !   vertexlist(vv+dv4,0)=0
                  !   length=length-1
                  !elseif (vertexlist(vv+dv4,0)==0) then
                  !   vertexlist(vv+dv3,0)=mrk1
                  !   vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
                  !   length=length+1
                  !else
                  !endif
               endif
            endif
         endif
         if (mmv==mmt) selfcest=selfcest+1d0

         exit

      endif

      if (d==0) then
         if (vertexlist(vv+dv3,0)==mrk0) then
            vertexlist(vv+dv3,0)=0
            vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
            opflog(tauscale(int(vv/dxl)))=opflog(tauscale(int(vv/dxl)))+1
            length=length-1

            exit

         elseif (vertexlist(vv+dv3,0)==mrk1) then
            vertexlist(vv+dv3,0)=0
            vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
            opflog(tauscale(int(vv/dxl)))=opflog(tauscale(int(vv/dxl)))+1
            length=length-1

            exit

         else
            if (vertexlist(vv+dv4,0)==mrk0) then
               vertexlist(vv+dv3,0)=0
               vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
               opflog(tauscale(int(vv/dxl)))=opflog(tauscale(int(vv/dxl)))+1
               vertexlist(vv+dv4,0)=0
               length=length-1

               exit

            elseif (vertexlist(vv+dv4,0)==mrk1) then
               vertexlist(vv+dv3,0)=0
               vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
               opflog(tauscale(int(vv/dxl)))=opflog(tauscale(int(vv/dxl)))+1
               vertexlist(vv+dv4,0)=0
               length=length-1

               exit

            elseif (vertexlist(vv+dv4,0)==0) then
               vertexlist(vv+dv3,0)=0
               vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
               opflog(tauscale(int(vv/dxl)))=opflog(tauscale(int(vv/dxl)))+1

               !print*,"8888888888888888888888888888888888888888888888888"
               !if (clustermark>2) pause

               vertexlist(vv+dv4,1)=vertexlist(vv+dv4,1)+1
               opflog(tauscale(int(vv/dxl)))=opflog(tauscale(int(vv/dxl)))+1
               mmv=int(vertexlist_map(vv+dv4)/(dxl))
               dv3=mod(vertexlist_map(vv+dv4),dxl)
               dv4=mod(dv3+mxl,dxl)
               bv=int(opstring(mmv)/8)
               tt=int(mod(opstring(mmv),8)/2)+1
               !d=dealtyp(tauscale(mmv))

               !if (dealtyp(tauscale(mmv))==-1) call initdealtyp(bv,tt,mmv)
               !d=dealtyp(tauscale(mmv))

               if (updtyp==0) then
                  if (bv==b0 .and. tt==typ0 .and. dealtyp(tauscale(mmv))==1) then 
                     d=1
                  else
                     d=0
                  endif
               elseif (updtyp==1) then
                  d=dealtyp(tauscale(mmv))
               endif

               update_counter=update_counter+1
               cycle
            else
            endif
         endif
      endif
   enddo

end subroutine clusterluch
!==================================================!

!==================================================!

subroutine clusterfliper(prid)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,p,vv,optmp,btmp,sigtmp,typtmp,up,dw,d,prid,c1,c2
   integer :: tmp
   integer, allocatable :: flipspin(:)
   allocate(flipspin(nn))
   flipspin(:)=0d0

   do i=1, nh 
      if (opftab(i)==0d0) exit
      p=oporder(opftab(i))
      d=dealtyp(opftab(i))

      !p=oporder(i)
      !d=opertyp(i)
      !d=dealtyp(i)
      vv=dxl*p
      optmp=opstring(p)
      btmp=int(optmp/8)
      typtmp=int(mod(optmp,8)/2)+1
      sigtmp=mod(optmp,2)
      up=0d0
      dw=0d0

      if (basis==0) then
         !if (sigtmp==1 .and. typtmp==1) print*,"CHECK"
         if (sigtmp==1 .and. typtmp==2) print*,"ERROR_F"
         !if (sigtmp==1 .and. typtmp==3) print*,"CHECK"
         if (sigtmp==1 .and. typtmp==4) print*,"ERROR_F"
      elseif (basis==1) then
         if (sigtmp==1 .and. typtmp==1) print*,"ERROR_F"
         !if (sigtmp==1 .and. typtmp==2) print*,"CHECK"
         if (sigtmp==1 .and. typtmp==3) print*,"ERROR_F"
         !if (sigtmp==1 .and. typtmp==4) print*,"CHECK"
      endif

      c1=0d0
      c2=0d0
      do j=0,mxl-1
         if (vertexlist_map(vv+j)<0) exit
         if (mod(vertexlist(vv+j,1),2)==1) then
            !cc=cc+1
         endif
         if (mod(vertexlist(vv+j+mxl,1),2)==1) then
            vertexspin(j,p)=-vertexspin(j,p)
            !cc=cc+1
         endif
         if (vertexlist(vv+j,1)>=0) c1=c1+1
         if (vertexlist(vv+j+mxl,1)>=0) c2=c2+1
      enddo
      !if (c1/=5 .and. c1/=0) then
      !   print*,"WARNING","c1",c1,typtmp
      !endif
      !if (c2/=5 .and. c2/=0) then
      !   print*,"WARNING","c2",c2,typtmp
      !endif


      if (typtmp==1 .and. d==1) then
         opstring(p)=ieor(opstring(p),mod(opflip(opftab(i)),2))
      elseif (typtmp==2 .and. d==1) then
         opstring(p)=ieor(opstring(p),mod(opflip(opftab(i)),2))
      elseif (typtmp==3 .and. d==1) then
         opstring(p)=ieor(opstring(p),mod(opflip(opftab(i)),2))
      elseif (typtmp==4 .and. d==1) then
         opstring(p)=ieor(opstring(p),mod(opflip(opftab(i)),2))
      endif

   enddo
   
   do i=1,nn
      if (i<=nn) then
         if (frstspinop(i)/=-1) then
            if (mod(vertexlist(frstspinop(i),1),2)==1) then           
               spin(i)=-spin(i)
               flipspin(i)=1d0
            endif
         endif
      endif
      
      !nhpm(i,1)=nhpm(i,1)+nhtp(i)
      !nhpm(i,0)=nhpm(i,0)-nhtp(i)
      
      !if (nhtp(i)/=0) then
         !pause
         !print*,"bilibili",nhtp(i)
      !endif
      !if (nhpm(i,1)<0d0 .or. nhpm(i,0)<0d0) then
      !   print*,"error",sum(nhtp(:)),probnum
      !   print*,"error",nhpm(i,1)-nhtp(i),nhpm(i,0)+nhtp(i),nhtp(i),i
      !   print*,"error",nhpm(i,1),nhpm(i,0),nhtp(i),i
      !   pause
      !endif
   enddo

   !print*,"----------------------------------------------------"
   !do i=1,sitnum
   !   tmp=1d0
   !   do j=1, 5 
   !      tmp=tmp*spin(bsites(j,i+((ieor(basis,1)))*sitnum))
   !   enddo
   !   if (tmp/=1) then
   !      do j=1, 5 
   !         tmp=bsites(j,i+((ieor(basis,1)))*sitnum)
   !         print*,j,tmp,flipspin(tmp)
   !      enddo
   !   else
   !   endif
   !enddo
   !print*,"----------------------------------------------------"

   !call spinchecker()

end subroutine clusterfliper
!==================================================!



!==================================================!

subroutine clusterflbprb(prid)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,p,up,dw,ty,legmax,l,d,prid
   integer :: vv,optmp,btmp,sigtmp,typtmp
   integer :: dnum,afts,bfrs
   integer :: sigaft, sigbfr

   dnum=0d0
   probnum=0d0
   wgtaft=1d0
   wgtbfr=1d0
   !nhtp(:)=0d0

   do i=1, nh 

      if (opftab(i)==0d0) exit
      p=oporder(opftab(i))
      d=dealtyp(opftab(i))

      !p=oporder(i)
      !d=dealtyp(i)
      vv=dxl*p
      optmp=opstring(p)
      btmp=int(optmp/8)
      typtmp=int(mod(optmp,8)/2)+1
      sigtmp=mod(optmp,2)
      l=0d0


      if (typtmp==legtyp(1) .or. typtmp==legtyp(2)) then 
         cycle
      else
         bfrs=1d0
         afts=1d0
         dnum=dnum+1
         do j=0,mxl-1
            if (vertexlist_map(vv+j)<0) exit
            if (mod(vertexlist(vv+j,1),2)==1 .and. mod(vertexlist(vv+j+mxl,1),2)==1) then
               bfrs=bfrs*vertexspin(j,p)
               afts=afts*vertexspin(j,p)*(-1)
               if (mod(vertexlist(vv+j,1),2)==1d0) l=l+1
            elseif (mod(vertexlist(vv+j,1),2)==0 .and. mod(vertexlist(vv+j+mxl,1),2)==0) then
               bfrs=bfrs*vertexspin(j,p)
               afts=afts*vertexspin(j,p)
            else
               print*,"ERROR_fl_0",mod(vertexlist(vv+j,1),2),mod(vertexlist(vv+j+mxl,1),2)
            endif
         enddo
      
         if (l==0d0) cycle
         !if (mod(l,2)==1) then 
            !print*,"l",l
            !pause
         !endif

         if (typtmp==2) then
            if (l/=0) then
               wgtbfr=sweightable(int((bfrs+1d0)/2d0),weightab(btmp,prid))
               wgtaft=sweightable(int((afts+1d0)/2d0),weightab(btmp,prid))
            endif
         elseif (typtmp==4) then
            if (bfrs==1 .and. afts==-1) then
               wgtbfr=4d0*hz
               wgtaft=2d0*hz
            elseif (bfrs==-1 .and. afts==1) then
               wgtbfr=2d0*hz
               wgtaft=4d0*hz
            endif
         elseif (typtmp==1) then
            if (l/=0) then
               wgtbfr=cweightable(int((bfrs+1d0)/2d0),weightab(btmp,prid))
               wgtaft=cweightable(int((afts+1d0)/2d0),weightab(btmp,prid))
            endif
         elseif (typtmp==3) then
            if (bfrs==1 .and. afts==-1) then
               wgtbfr=4d0*hx
               wgtaft=2d0*hx
            elseif (bfrs==-1 .and. afts==1) then
               wgtbfr=2d0*hx
               wgtaft=4d0*hx
            endif
         endif
      endif
            
      if (wgtbfr==0) print*,"err",l,wgtbfr,typtmp
      if (wgtaft>wgtbfr) then
         probnum=probnum+1
         !if (basis==1 .and. typtmp==1) nhtp(btmp)=nhtp(btmp)+afts 
         !if (basis==0 .and. typtmp==2) nhtp(btmp)=nhtp(btmp)+afts 
         !print*,"+1",probnum,wgtaft,wgtbfr,mod(l,2)
      elseif (wgtaft==wgtbfr) then
         probnum=probnum 
         !if (basis==1 .and. typtmp==1) nhtp(btmp)=nhtp(btmp)+0
         !if (basis==0 .and. typtmp==2) nhtp(btmp)=nhtp(btmp)+0
         !print*,"+0",probnum,wgtaft,wgtbfr,mod(l,2)
      elseif (wgtaft<wgtbfr) then
         probnum=probnum-1 
         !if (basis==1 .and. typtmp==1) nhtp(btmp)=nhtp(btmp)+afts 
         !if (basis==0 .and. typtmp==2) nhtp(btmp)=nhtp(btmp)+afts 
         !print*,"-1",probnum,wgtaft,wgtbfr,mod(l,2)
      endif

      if (abs(probnum)>dnum) print*,probnum,nh,dnum

      !if (mod(l,2)==1) dnum=dnum+1 
     
   enddo
   !if (probnum/=0d0) 
   !print*,"probnum,nh,dnum",probnum,nh,dnum


   ! do i=1,sitnum*4
   !    if (nhtp(i)/=0) then
   !       !pause
   !       print*,"Acfun",i,nhtp(i),sum(nhtp(:)),probnum
   !    endif
   ! enddo
   
end subroutine clusterflbprb
!==================================================!


!==================================================!

 subroutine extendconfig(ratio,nprocs,rank)
!---------------------!
 use configuration
 implicit none
 integer :: i,j,k,l,r,ratio,rush,tmp,op_old,b_old,t_old,b,op,t
 integer :: x,y,z,s,x_old,y_old,z_old,s_old,nprocs,rank
 integer :: mm_old,nh_old,nn_old,nb_old,nsite_old,nsite,bg_old,bg,mp,m_cur,m_per,m_ext
 integer :: lx_old,ly_old,lz_old,mm_mid,typtmp
 real(8) :: rantmp
 real(8), external :: ran
 real(8), allocatable :: opindex(:)
 integer, allocatable :: rtindex(:)
 integer, allocatable :: opstring_old(:)
 integer, allocatable :: spin_old(:)
 integer, allocatable :: bsites_old(:,:)

 nh_old=nh
 mm_old=mm
 nn_old=nn
 nb_old=nb
 lx_old=lx
 ly_old=ly
 lz_old=lz
 nsite_old=lx_old*ly_old*lz_old
 !tmp=mm-nh

 allocate(opstring_old(0:mm_old-1))
 allocate(bsites_old(mxl,nb_old))
 allocate(spin_old(nn_old))
 opstring_old(:)=opstring(:)
 bsites_old(:,:)=bsites(:,:)
 spin_old(:)=spin(:)

 rush=ratio**3
 nh=nh*rush
 nh1=nh1*rush
 nh2=nh2*rush
 nh3=nh3*rush
 nh4=nh4*rush
 !mm=tmp+nh
 m_ext=mm*rush
 mm=m_ext
 lx=lx*ratio
 ly=ly*ratio
 lz=lz*ratio
 nsite=lx*ly*lz
 nn=3*nsite
 nb=(1+3)*nsite
 mm_mid=mm

 !mm=mm*ratio
 !nh=nh*ratio
 !nh1=nh1*ratio
 !nh2=nh2*ratio
 !nh3=nh3*ratio
 !nh4=nh4*ratio

 deallocate(bsites)
 deallocate(spin)
 deallocate(opstring)
 deallocate(tauscale)
 deallocate(vertexlist)
 deallocate(vertexlist_map)
 deallocate(vertexspin) 
 deallocate(rantau) 

 call makelattice()

 allocate(spin(nn))
 allocate(opstring(0:mm-1))
 allocate(tauscale(0:mm-1))
 allocate(vertexlist(0:dxl*mm-1,0:1))
 allocate(vertexlist_map(0:dxl*mm-1))
 allocate(vertexspin(0:mxl-1,0:mm-1))  
 allocate(rantau(nh)) 
 tauscale(:)=0d0
 opstring(:)=0d0

 !print*,"extending step 1"

 do s=1,nn
   x=mod(s-1,lx)
   y=mod(int((s-1)/lx),ly)
   z=int((s-1)/(lx*ly))

   x_old=mod(x,lx_old)
   y_old=mod(y,ly_old)
   z_old=mod(z,lz_old)
   s_old=1+mod(x_old,lx_old)+mod(y_old,ly_old)*lx_old+mod(z_old,lz_old)*lx_old*ly_old

   !spin(s)=int(2*ran()-1)*spin_old(s_old)
   spin(s)=1d0
 enddo

 !print*,"extending step 2"
 allocate(opindex(nh))
 do j=1,nh
   do
      rantmp=ran()
      m_cur=int(m_ext*rantmp)
      if (opstring(m_cur)==0d0) then
         opstring(m_cur)=1d0
         opindex(j)=rantmp
         exit
      endif
   enddo
 enddo
 call quick_sort(opindex,nh,1,nh)
 allocate(rtindex(rush)) 
 do k=1, rush
   rtindex(k)=k
 enddo
 do l=1, rush
   k=int(ran()*rush)+1
   r=int(ran()*rush)+1
   if (k/=r) then
      tmp=rtindex(k)
      rtindex(k)=rtindex(r)
      rtindex(r)=tmp
   endif
 enddo

 !print*,opindex(1),opindex(nh)

 opstring(:)=0d0

 !i=0d0
 !do j=0,mm_old-1
 !  op_old=opstring_old(j)
 !  if (op_old==0d0) then
 !     opstring(i)=op_old
 !     i=i+1
 !  elseif (op_old/=0d0) then
 !     b_old=int(op_old/8)
 !     t_old=mod(op_old,8)
 !     s_old=mod(b_old-1,nsite_old)+1
 !     bg_old=int((b_old-1)/nsite_old)
 !     !print*,"bg_old",bg_old,nsite_old
 !
 !     x_old=mod(s_old-1,lx_old)
 !     y_old=mod(int((s_old-1)/lx_old),ly_old)
 !     z_old=int((s_old-1)/(lx_old*ly_old))
 !
 !     do r=1,rush
 !        x=mod(r-1,ratio)
 !        y=mod(int((r-1)/ratio),ratio)
 !        z=int((r-1)/(ratio*ratio))
 !
 !        x=lx_old*x+x_old
 !        y=ly_old*y+y_old
 !        z=lz_old*z+z_old
 !        s=1+mod(x,lx)+mod(y,ly)*lx+mod(z,lz)*lx*ly
 !        bg=bg_old
 !        b=s+bg*nsite
 !        t=t_old
 ! 
 !        !print*,s,s_old
 !
 !        opstring(i)=b*8+t
 !        !print*,i,size(opstring),mm-1
 !        i=i+1
 !     enddo
 !  endif
 !enddo
  !print*,"extending step 2.5",size(opstring_old,dim=1),size(opstring,dim=1),size(rtindex,dim=1),size(opindex,dim=1)
 
 i=1d0
 mp=0d0
 m_per=-1d0
 do j=0,mm_old-1
   op_old=opstring_old(j)
   typtmp=int(mod(op_old,8)/2)+1
   if (op_old==0d0) then
   elseif (op_old/=0d0 .and. typtmp<=2) then
      b_old=int(op_old/8)
      t_old=mod(op_old,8)
      s_old=mod(b_old-1,nsite_old)+1
      bg_old=int((b_old-1)/nsite_old)
      !print*,"bg_old",bg_old,nsite_old

      x_old=mod(s_old-1,lx_old)
      y_old=mod(int((s_old-1)/lx_old),ly_old)
      z_old=int((s_old-1)/(lx_old*ly_old))

      do k=1,rush
         r=rtindex(k)

         x=mod(r-1,ratio)
         y=mod(int((r-1)/ratio),ratio)
         z=int((r-1)/(ratio*ratio))

         x=lx_old*x+x_old
         y=ly_old*y+y_old
         z=lz_old*z+z_old
         s=1+mod(x,lx)+mod(y,ly)*lx+mod(z,lz)*lx*ly
         bg=bg_old
         b=s+bg*nsite
         t=t_old

         !print*,s,s_old

         m_cur=max(int(opindex(i)*m_ext),m_per+1)
         do 
             if (opstring(m_cur)==0d0) then
               !if (rank==0) print*,"befor",opstring(m_cur),m_cur,mm,rank
                opstring(m_cur)=b*8+t
               !if (rank==0) print*,"after",opstring(m_cur),m_cur,mm,rank
               exit
            endif
            m_cur=m_cur+1
            !print*,"opstring(m_cur),m_cur,mm"
         enddo
         m_per=m_cur
         !print*,m_cur,size(opstring),mm-1
         !print*,int(opindex(i)*m_ext),mm-1,rank
         !if (i==1) print*,opindex(i),int(opindex(i)*m_ext),mm-1
        !if (i==nh) print*,opindex(i),int(opindex(i)*m_ext),mm-1
        i=i+1
      enddo

      do l=1, rush         
         k=int(ran()*rush)+1
         r=int(ran()*rush)+1
         if (k/=r) then
            tmp=rtindex(k)
            rtindex(k)=rtindex(r)
            rtindex(r)=tmp
         endif
      enddo

   elseif (op_old/=0d0 .and. typtmp<=4 .and. typtmp>2) then
      b_old=int(op_old/8)
      t_old=mod(op_old,8)
      s_old=b_old
      bg_old=0
      !print*,"bg_old",bg_old,nsite_old

      x_old=mod(s_old-1,lx_old)
      y_old=mod(int((s_old-1)/lx_old),ly_old)
      z_old=int((s_old-1)/(lx_old*ly_old))

      do k=1,rush
         r=rtindex(k)

         x=mod(r-1,ratio)
         y=mod(int((r-1)/ratio),ratio)
         z=int((r-1)/(ratio*ratio))

         x=lx_old*x+x_old
         y=ly_old*y+y_old
         z=lz_old*z+z_old
         s=1+mod(x,lx)+mod(y,ly)*lx+mod(z,lz)*lx*ly
         bg=bg_old
         b=s+bg*nsite
         t=t_old

         !print*,s,s_old

         m_cur=max(int(opindex(i)*m_ext),m_per+1)
         do 
             if (opstring(m_cur)==0d0) then
               !if (rank==0) print*,"befor",opstring(m_cur),m_cur,mm,rank
                opstring(m_cur)=b*8+t
               !if (rank==0) print*,"after",opstring(m_cur),m_cur,mm,rank
               exit
            endif
            m_cur=m_cur+1
            !print*,"opstring(m_cur),m_cur,mm"
         enddo
         m_per=m_cur
         !print*,m_cur,size(opstring),mm-1
         !print*,int(opindex(i)*m_ext),mm-1,rank
         !if (i==1) print*,opindex(i),int(opindex(i)*m_ext),mm-1
        !if (i==nh) print*,opindex(i),int(opindex(i)*m_ext),mm-1
        i=i+1
      enddo

      do l=1, rush         
         k=int(ran()*rush)+1
         r=int(ran()*rush)+1
         if (k/=r) then
            tmp=rtindex(k)
            rtindex(k)=rtindex(r)
            rtindex(r)=tmp
         endif
      enddo
   endif
 enddo

!if (ratio>1) then
   !do i=0,mm_mid-1
      !do j=1,ratio-1
         !opstring(i+j*mm_mid)=opstring(i)
      !enddo
   !enddo
!endif
 !print*,"extending step 3"

 call initweight(0,1,0,nprocs)
 
 !print*,"extending finished"
 end subroutine extendconfig

!==================================================!

!==================================================!

subroutine adjustcutoff(step)
   use configuration
   implicit none

   integer, allocatable :: stringcopy(:)
   integer :: mmnew,step

   mmnew=nh+nh/3
   if (mmnew<=mm) return

   allocate(stringcopy(0:mm-1))
   stringcopy(:)=opstring(:)

   !print*,"1"

   deallocate(opstring)
   allocate(opstring(0:mmnew-1))
   opstring(:)=0

   !print*,"2"

   deallocate(tauscale)
   allocate(tauscale(0:mmnew-1))
   tauscale(:)=0

   !print*,"3"

   deallocate(vertexspin)
   allocate(vertexspin(0:mxl-1,0:mmnew-1))
   vertexspin(:,:)=-2

   !print*,"4"

   opstring(0:mm-1)=stringcopy(:)
   opstring(mm:mmnew-1)=0
   deallocate(stringcopy)

   !print*,"5"

   mm=mmnew
   !print*,"5.1"
   deallocate(vertexlist)
   allocate(vertexlist(0:dxl*mm-1,0:1))
   !print*,"5.2"
   deallocate(vertexlist_map)
   allocate(vertexlist_map(0:dxl*mm-1))

   !print*,"6"

   open(unit=10,file='info.dat',position='append')
   write(10,*)' Step: ',step,'  Cut-off L: ',mm,'  Current nh: ',nh
   close(10)

 end subroutine adjustcutoff
!==================================================!
!==================================================!

subroutine measurechain(signal)
   use configuration
   use measurementdata
   implicit none

   integer :: i,j,b,op,typ,s1,s2,am,rx,ry,rz,x,y,z,check,stmp,signal
   real(8) :: am1,am2,saft,e1,e2
   check=0d0

   am=0
   mag1=0d0
   mag2=0d0
   auen=0d0

   if (signal==0) then
      nhe1=0d0
      nhe2=0d0
      nms0=0d0
   elseif (signal==1) then
      do i = 1, nn
         am=am+spin(i)
      end do 

      am1=0.d0
      am2=0.d0

      do i = 0, mm-1
         op=opstring(i)
         saft=0d0

         if ( mod(op,2)==1 ) then
            typ=int(mod(op,8)/2)+1
            b=int(op/8)
            if (typ<=2) then
               do j=1,mxl
                  stmp=bsites(j,b)
                  if (stmp==-1) then
                     exit
                  else
                     spin(stmp)=-spin(stmp)
                     saft=saft+spin(stmp)
                  endif
               enddo
            else
            if (basis==0d0) then
               if (typ==3d0) then
                  spin(b)=-spin(b)
                  saft=saft+spin(b)
               endif
            elseif (basis==1d0) then
               if (typ==4d0) then
                  spin(b)=-spin(b)
                  saft=saft+spin(b)
               endif
            endif
         endif

         am=am+2d0*saft
         check=check+1
        endif

        am1=am1+dfloat(abs(am))
        am2=am2+dfloat(am)
      end do
    
      if (mm/=0) then
         am1=am1/dble(mm)
         am2=am2/dble(mm)
      else
         am1=dfloat(abs(am))
         am2=dfloat(am)
      endif

      if (basis==0) then
         auen=-(nh/(beta*dble(nn)))+((sitnum*Ac+nn*(1d0+hx+hz))+2d0*nn*(1d0+hz))/dble(nn)
      elseif (basis==1) then
         auen=-(nh/(beta*dble(nn)))+((sitnum*Ac+nn*(1d0+hx+hz))+2d0*(sitnum*Ac+nn*hx))/dble(nn)
      endif
      mag1=am1/dble(nn)
      mag2=am2/dble(nn)

   elseif (signal==2) then
      nms0=nms0+1
      nhe1=nhe1+dble(nh)
      nhe2=nhe2+dble(nh)**2d0
   elseif (signal==3) then
      e1=nhe1/dble(nms0)
      e2=nhe2/dble(nms0)
      culg=(e2-e1*(e1+1.d0))/dble(nn)
   endif


end subroutine measurechain

!==================================================!

subroutine measure(rank)
   use configuration
   use measurementdata
   implicit none

   integer :: i,j,b,op,typ,s1,s2,rx,ry,rz,x,y,z,check,stmp
   integer :: x1,y1,z1,dl,s3,s4,st,dir,rank
   real(8) :: am1,am2,tmp
   real(8), allocatable :: tptm(:,:)
   real(8), allocatable :: saft(:)
   real(8), external :: ran
   integer, allocatable :: am(:)
   allocate(am(2))
   allocate(saft(2))
   check=0d0
   am=0d0
   saft=0d0

   allocate(tptm(0:lx-1,2))
   tptm(:,:)=1d0

   am=0
   do i = 1, sitnum
      am(1)=am(1)+spin(i)
      am(2)=am(2)+spin(i+sitnum)
   end do 

    am1=0.d0
    am2=0.d0

    do i = 0, mm-1
      op=opstring(i)
      saft=0d0

      if ( mod(op,2)==1 ) then
         typ=int(mod(op,8)/2)+1
         b=int(op/8)
         if (typ<=2) then
            do j=1,mxl
               stmp=bsites(j,b)
               if (stmp==-1) then
                  exit
               else
                  spin(stmp)=-spin(stmp)
                  if (stmp<=sitnum) then
                     saft(1)=saft(1)+spin(stmp)
                  else
                     saft(2)=saft(2)+spin(stmp)
                  endif
               endif
            enddo
         else
            if (basis==0d0) then
               if (typ==3d0) then
                  spin(b)=-spin(b)
                  if (b<=sitnum) then
                     saft(1)=saft(1)+spin(b)
                  else
                     saft(2)=saft(2)+spin(b)
                  endif
               endif
            elseif (basis==1d0) then
               if (typ==4d0) then
                  spin(b)=-spin(b)
                  if (b<=sitnum) then
                     saft(1)=saft(1)+spin(b)
                  else
                     saft(2)=saft(2)+spin(b)
                  endif
               endif
            endif
         endif

         am(:)=am(:)+2d0*saft(:)
         check=check+1
        endif

        !am1=am1+dfloat(abs(am))
        !am2=am2+dfloat(am)**2

        am1=am1+dfloat(abs(am(1)))
        am2=am2+dfloat(abs(am(2)))

    end do
    
    if (mm/=0) then
      am1=am1/dble(mm)
      am2=am2/dble(mm)
   else
      !am1=dfloat(abs(am))
      !am2=dfloat(am)**2
      am1=dfloat(abs(am(1)))
      am2=dfloat(abs(am(2)))
   endif

    enrg1=enrg1+dble(nh)
    enrg2=enrg2+dble(nh)**2
    amag1=amag1+am1
    amag2=amag2+am2

    !if ( check==0 ) print*,"warning",ss(:) 

   do s1=1, sitnum
      x=mod(s1-1,lx)
      y=mod(int((s1-1)/lx),ly)
      z=int((s1-1)/(lx*ly))
      do rx=0, lx-1
         do ry=0, ly-1
            do rz=0, lz-1
               s2=mod(x+rx,lx)+mod(y+ry,ly)*lx+mod(z+rz,lz)*lx*ly+1
               do i=1, 2
                  crr(rx,ry,rz,i)=crr(rx,ry,rz,i)+spin(s1+(i-1)*sitnum)*spin(s2+(i-1)*sitnum)
                  !if (rx/=0 .and. ry/=0 .and. rz/=0) then
                     !if ((s1+(i-1)*sitnum)==(s2+(i-1)*sitnum)) print*, (s1+(i-1)*sitnum),(s2+(i-1)*sitnum)
                  !endif
                  !print*, (s1+(i-1)*sitnum),(s2+(i-1)*sitnum)
               enddo
            enddo
         enddo
      enddo
   enddo

   dir=2*basis-1
   !s1=int(ran()*sitnum)+1
   if (dir==1d0) then
      s1=1+1+lx
   elseif (dir==-1d0) then
      s1=sitnum
   endif
   x1=mod(s1-1,lx)
   y1=mod(int((s1-1)/lx),ly)

   tptm(0,1)=1d0
   i=(ieor(basis,1))+1
   tptm(0,2)=spin(s1+(i-1)*sitnum)
   topa(0)=topa(0)+tptm(0,1)*tptm(0,2)

   tmp=1d0
   i=(ieor(basis,1))+1
   !print*,s1+(i-1)*sitnum,sitnum,nn
   do j=1,5
      tmp=tmp*spin(bsites(j,s1+(i-1)*sitnum))
   enddo
   
   do dl=1, lx-1

      s2=1+mod(x1+(dir)*dl+lx,lx)+mod(y1,ly)*lx
      s3=1+mod(x1+(dir)*dl+lx,lx)+mod(y1+(dir)*dl+ly,ly)*lx
      s4=1+mod(x1,lx)+mod(y1+(dir)*dl+ly,ly)*lx
      !print*,s1,s2,s3,s4

      if (dl==1) then
         !print*,"--------------------------"
         !print*,s1,bsites(1,s1)
         !print*,s2,bsites(2,s1)
         !print*,s3,bsites(3,s1)
         !print*,s4,bsites(4,s1)
      endif
 
      i=basis+1
      tptm(dl,1)=tptm(dl-1,1)
      do j=0, dl-2
         st=1+mod(x1+(dir)*(dl-1)+lx,lx)+mod(y1+(dir)*(j)+ly,ly)*lx
         tptm(dl,1)=tptm(dl,1)*spin(st+(i-1)*sitnum)

         st=1+mod(x1+(dir)*(j)+lx,lx)+mod(y1+(dir)*(dl-1)+ly,ly)*lx
         tptm(dl,1)=tptm(dl,1)*spin(st+(i-1)*sitnum)
      enddo
      st=1+mod(x1+(dir)*(dl-1)+lx,lx)+mod(y1+(dir)*(dl-1)+ly,ly)*lx
      tptm(dl,1)=tptm(dl,1)*spin(st+(i-1)*sitnum)

      if (dl==1) then
         !print*,st+(i-1)*sitnum,bsites(5,s1),i,ieor(basis,1),ieor(0,1),basis
         !print*,"--------------------------"
      endif

      i=(ieor(basis,1))+1
      tptm(dl,2)=spin(s1+(i-1)*sitnum)
      tptm(dl,2)=tptm(dl,2)*spin(s2+(i-1)*sitnum)
      tptm(dl,2)=tptm(dl,2)*spin(s3+(i-1)*sitnum)
      tptm(dl,2)=tptm(dl,2)*spin(s4+(i-1)*sitnum)

      topa(dl)=topa(dl)+tptm(dl,1)*tptm(dl,2)
      !print*,dl,tptm(dl,1)*tptm(dl,2),tptm(dl,1),tptm(dl,2)
      !if (dl==1 .and. tmp/=1d0) print*,rank,tptm(dl,1)*tptm(dl,2),tmp,s1
      !if (tmp/=1 .and. dl==1) print*,"WARNING"
      !topa(dl)=topa(dl)+tptm(dl,1)
      !topa(dl)=topa(dl)+1

   enddo

   !print*,"+++++++++++++++++++++++++++++++++"
   !print*,spin(1),spin(9),spin(17)
   !print*,spin(2),spin(mxl-1),spin(21)
   nms1=nms1+1

end subroutine measure
!==================================================!

!==================================================!

subroutine writeresult(control,rank)
   use configuration
   use measurementdata
   use vertexupdate
   implicit none

   integer :: msteps,rx,ry,rz,q,t,i1,i2,i3,rank,i,control

   real(8), external :: qx
   real(8), external :: qy

    resname='res000.dat'
    crrname='crr000.dat'
    topaname='topa000.dat'
    backname='back000.dat'
    tcAcname='tcAc000.dat'

    i3=rank/100
    i2=mod(rank,100)/10
    i1=mod(rank,10)
    resname(6:6)=achar(48+i1)
    resname(5:5)=achar(48+i2)
    resname(4:4)=achar(48+i3)

    crrname(6:6)=achar(48+i1)
    crrname(5:5)=achar(48+i2)
    crrname(4:4)=achar(48+i3)

    topaname(7:7)=achar(48+i1)
    topaname(6:6)=achar(48+i2)
    topaname(5:5)=achar(48+i3)

    tcAcname(7:7)=achar(48+i1)
    tcAcname(6:6)=achar(48+i2)
    tcAcname(5:5)=achar(48+i3)

    backname(7:7)=achar(48+i1)
    backname(6:6)=achar(48+i2)
    backname(5:5)=achar(48+i3)

    open(10,file=resname,status='replace')
    close(10) 
    open(10,file=crrname,status='replace')
    close(10)  
    open(10,file=topaname,status='replace')
    close(10)  
    open(10,file=backname,status='replace')
    close(10)  
    open(10,file=tcAcname,status='replace')
    close(10) 


    if ( control==0 ) then 
      enrg1=enrg1/dble(nms1)
      enrg2=enrg2/dble(nms1)
      amag1=amag1/dble(nms1)
      amag2=amag2/dble(nms1)

      enrg2=(enrg2-enrg1*(enrg1+1.d0))/nn
      if (basis==0) then
         enrg1=-(enrg1/(beta*dble(nbs)))+((pbAc*Ac+pbBs*Bs+sitnum*(hx+hz))+2d0*(pbBs*Bs+sitnum*hz))/dble(nbs)
      elseif (basis==1) then
         enrg1=-(enrg1/(beta*dble(nbs)))+((pbAc*Ac+pbBs*Bs+sitnum*(hx+hz))+2d0*(pbAc*Ac+sitnum*hx))/dble(nbs)
      endif
      amag1=amag1/dble(sitnum)
      amag2=amag2/dble(sitnum)
   endif

   open(10,file=resname,position='append')
   write(10,*)enrg1,enrg2,amag1,amag2
   close(10)

   crr=crr/dble(sitnum)/dble(nms1)
   open(20,file=crrname,position='append')
   do rx=0,lx-1
      do ry=0,ly-1
         do rz=0,lz-1
            write(20,*)rx,ry,rz,crr(rx,ry,rz,1:2)
         enddo
      enddo
   end do
   close(20)
   crr=crr*dble(sitnum)*dble(nms1)


   topa=topa/dble(nms1)
   open(20,file=topaname,position='append')
   do rx=0,lx-1
      write(20,*)rx,topa(rx)
   end do
   close(20)
   topa=topa*dble(nms1)

   tcAc=tcAc/dble(nms2)
   cbbkgd=cbbkgd/dble(nms2)   
   open(10,file=tcAcname,position='append')
   do q=1,ly
      write(10,'(2i8)')q
      do t=0,ntau
         write(10,'(f20.12)')tcAc(t,q)
      enddo
   enddo
   close(10)

   open(10,file=backname,position='append')
   do q=1,ly
      write(10,*)q,cbbkgd(q)
   enddo
   close(10)

   tcAc=tcAc*dble(nms2) 
   cbbkgd=cbbkgd*dble(nms2)

   if ( control==0 ) then
      enrg1=0.d0
      enrg2=0.d0
      amag1=0.d0
      amag2=0.d0
      crr=0d0
      nms1=0 
      tcAc=0.d0
      cbbkgd=0d0
      nms2=0
   endif

end subroutine writeresult
!==================================================!


!==================================================!

real(8) function ran()
!----------------------------------------------!
! 64-bit congruental generator                 !
! iran64=oran64*2862933555777941757+1013904243 !
!----------------------------------------------!
 implicit none

 real(8) :: dmu64
 integer(8) :: ran64,mul64,add64
 common/bran64/dmu64,ran64,mul64,add64

 ran64=ran64*mul64+add64
 ran=0.5d0+dmu64*dble(ran64)

 end function ran


Subroutine initran(w,rank)
!--------------------------------------------------!
 implicit none
 integer(8) :: irmax
 integer(4) :: w,b
 integer :: rank,system_time
 real(8) :: dmu64
 integer(8) :: ran64,mul64,add64
 common/bran64/dmu64,ran64,mul64,add64
 
irmax=2_8**31
irmax=2*(irmax**2-1)+1
mul64=2862933555777941757_8
add64=1013904243
dmu64=0.5d0/dble(irmax)
call system_clock(system_time)
ran64=abs(system_time-(rank*1993+2018)*20160514)  

end Subroutine initran
!==================================================!


!==================================================!

subroutine deallocateall()
   use configuration
   use measurementdata
   implicit none

   deallocate(spin)
   !print*,"spin"
   deallocate(bsites)
   !print*,"sites"
   deallocate(opstring)
   !print*,"opstring"
   deallocate(tauscale)
   !print*,"tauscale"
   deallocate(frstspinop)
   !print*,"frstspinop"
   deallocate(lastspinop)
   !print*,"lastspinop"
   deallocate(vertexlist)
   !print*,"vertexlist"
   deallocate(vertexlist_map)
   !print*,"vertexlist_map"
   deallocate(rantau)
   !print*,"rantau"
   deallocate(crr)
   !print*,"crr"
   deallocate(vertexspin)
   !print*,"vertexspin"
   deallocate(tc)
   !print*,"tc"
   deallocate(phi)
   !print*,"phi"
   deallocate(tcAc)
   deallocate(ref)
   !print*,"ref"
   deallocate(imf)
   !print*,"imf"

end subroutine deallocateall
!==================================================!

!==================================================!     
subroutine taugrid(gtype,tmax)
!-------------------------------------------------------------------------!
!-constructs array tgrd(0,...,ntau) of time separations (in units of dtau)!
!-gtype = 1 for uniform grid of all separatiins up to tmax
!-        2 for quadratic grid t=dtau*n^2/4 up to beta/2
!-        3 for uniform grid up to tmax followed by quadratic to beta/2
!-actual time points including dtau factor are written to 'tgrid.dat'
!--------------------------------------------------------------------------!
 use configuration
 use measurementdata
 use vertexupdate
 implicit none

 integer :: i,t1,t2,gtype,nsm
 real(8) :: tmax

 nsm=int((tmax+1.d-5)/dtau)
 open(10,file='tgrid.dat',status='replace')

 if (gtype==1) then
    ntau=nsm
    write(10,'(i4)')ntau
    allocate(tgrd(0:ntau)) 
    do i=0,ntau
       tgrd(i)=i
       write(10,'(f15.8)')tgrd(i)*dtau
    enddo

 elseif (gtype==2) then    
    ntau=0
    t1=0
    do
       t2=((ntau+1)**2)/4
       if (t2==t1) t2=t1+1
       if (t2.le.nsm) then
          ntau=ntau+1
          t1=t2
       else
          exit
       endif
    enddo
    write(10,'(i4)')ntau
    allocate(tgrd(0:ntau)) 
    tgrd(0)=0
    write(10,'(f15.8)')0.d0
    do i=1,ntau
       tgrd(i)=(i**2)/4
       if (tgrd(i)==tgrd(i-1)) tgrd(i)=tgrd(i-1)+1       
       write(10,'(f15.8)')tgrd(i)*dtau
    enddo

 elseif (gtype==3) then  
    ntau=nsm
    t1=0
    i=0
    do
       t2=((i+1)**2)/4
       if (t2==t1) t2=t1+1
       if (t2.gt.nsm.and.t2.le.ns/2) then
          ntau=ntau+1
          t1=t2
       elseif (t2.gt.ns/2) then
          exit
       endif
       i=i+1
    enddo
    write(10,'(i4)')ntau
    allocate(tgrd(0:ntau)) 
    tgrd(0)=0
    do i=0,nsm
       tgrd(i)=i
       write(10,'(f15.8)')tgrd(i)*dtau
    enddo
    ntau=nsm
    t1=0
    i=0
    do
       t2=((i+1)**2)/4
       if (t2==t1) t2=t1+1
       if (t2.gt.nsm.and.t2.le.ns/2) then
          ntau=ntau+1
          tgrd(ntau)=t2
          write(10,'(f15.8)')tgrd(ntau)*dtau
          t1=t2
       elseif (t2.gt.ns/2) then
          exit
       endif
       i=i+1
    enddo
 endif 
 close(10)

 allocate(tc(0:ntau)) 
 allocate(tcAc(0:ntau,ly))
 allocate(cbbkgd(ly)) 

 tcAc=0.d0
 cbbkgd(:)=0d0
 nc=0d0

 allocate(cmplsg(0:3))
 cmplsg(:)=0d0
 selfcest=0d0

 end subroutine taugrid
 !==================================================!    

 !==================================================!
   
subroutine qarrays()
!-----------------------------------------------------------!
! phase factors for fourier transforms of spin configuration
!-----------------------------------------------------------!
 use configuration
 use measurementdata
 implicit none

 integer :: r,q
 real(8) :: qqx,qqy

 allocate(phi(2,nn,nq_all))
 allocate(ref(ns,nq_all))
 allocate(imf(ns,nq_all))

 end subroutine qarrays
!----------------------!
 

 subroutine measure2()
!---------------------------------------------!
! time dependent q-space correlation functions
!---------------------------------------------!
 use configuration
 use measurementdata
 implicit none

 integer :: i,j,l,k,s,q,b,op,t1,t2,dt,dd,s0,taumark,stmp,typ,q1,q2,qx,qy,qz,qx1,qy1,qz1
 integer :: k11,k12,k21,k22
 integer :: cou,nsig,s1,s2
 real(8) :: linetmp,sssstmp
 real(8), external :: ran
 integer, allocatable :: line_background(:)
 integer, allocatable :: line(:,:)
 integer, allocatable :: spts(:)
 allocate(spts(nn))
 allocate(line(ns,ly))
 allocate(line_background(ly))

 spts(:)=spin(:)

 i=0
 s0=1
 nsig=0
 line(:,:)=1d0
 dd=0d0

 do i=0,mm-1
   op=opstring(i)
   taumark=tauscale(i)
   if (nsig==0) then
      do s=s0,ns
         if (taumark/=nh) then
            if ( dble(s)/dble(ns)*beta > rantau(mod(taumark,nh)+1) ) then
               s0=s
               exit 
            endif 
         else 
            if ( dble(s)/dble(ns)*beta>rantau(mod(taumark,nh)+1) .and. dble(s)/dble(ns)*beta<=rantau(taumark) ) then
               s0=s
               exit 
            endif 
         endif
         if (s==ns) nsig=1
   
         !if (s==2) print*,"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"
         do j=1, ly
            stmp=1+mod(lx-1+lx,lx)+mod(j-1+ly,ly)*lx
            line(s,j)=line(s,j)*spin(stmp+sitnum)
            s1=stmp
            stmp=1+mod(lx-1+lx,lx)+mod(j+ly,ly)*lx
            line(s,j)=line(s,j)*spin(stmp)
            s2=stmp
            stmp=1+mod(lx-1+lx,lx)+mod(j-1+ly,ly)*lx
            line(s,j)=line(s,j)*spin(stmp)
      
            !if (s==2) then
            !   print*,s1+sitnum,s1,s2
            !   !print*,bontab(s1+sitnum),bontab(s1),bontab(s2)
            !   print*,spin(s1+sitnum),spin(s1),spin(s2),line(s,j)
            !endif
         enddo
         !if (s==2) print*,"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"

      enddo
   endif

   if (mod(op,2)==1) then        
      typ=int(mod(op,8)/2)+1
      b=int(op/8)
      if (typ<=2) then
         do j=1,mxl
            stmp=bsites(j,b)
            !print*,j,stmp
            if (stmp==-1) then
               exit
            else
               spin(stmp)=-spin(stmp)
            endif
         enddo
      else
         if (basis==0d0) then
            if (typ==3d0) spin(b)=-spin(b)
         elseif (basis==1d0) then
            if (typ==4d0) spin(b)=-spin(b)
         endif
      endif
   endif
 enddo

 do i=1,nn
   if (spts(i)/=spin(i)) then
      print*,"error"
      !pause
   endif
 enddo

 do q=1,ly        ! loop over q points
    dd=0d0
    tc=0d0
    line_background(:)=0d0
    do t1=1,ns,tstp   ! average time point t1 over time slices
      q1=1
      line_background(:)=line_background(:)+line(t1,:)

      do dt=0,ntau
         t2=mod(t1+tgrd(dt)-1,ns)+1   ! add time difference in tgrd(dt) to get time t2
         
         !qx1=mod(q1-1,lx)
         !qy1=mod(int((q1-1)/lx),ly)

         !qx=0
         !qy=q-1

         !q2=1+mod(qx1+qx,lx)+mod(qy1+qy,ly)*lx
         q2=q

         tc(dt)=tc(dt)+line(t1,q1)*line(t2,q2)  ! the real part of the correlation
      
      enddo
      dd=dd+1        ! count the number of measurements for t-averages
    enddo

    tcAc(:,q)=tcAc(:,q)+tc(:)/dble(dd)
    cbbkgd(:)=cbbkgd(:)+line_background(:)/dble(dd*ly) 
 enddo

 nms2=nms2+1

 end subroutine measure2
!==================================================!

!==================================================!

 subroutine random_tau()
!---------------------------------------------!
!time dependent q-space correlation functions S+S-
!---------------------------------------------!
 use configuration
 use measurementdata
 implicit none

 integer :: i,j,k
 real(8), external :: ran

 if ( size(rantau, dim=1)/=nh ) then
   deallocate(rantau)
   allocate(rantau(nh))
 endif 

 do i=1,nh
   rantau(i)=ran()*beta
 enddo

 call quick_sort(rantau,nh,1,nh)
 
 end subroutine random_tau
!==================================================!
!==================================================!

recursive subroutine quick_sort(a,n,s,e)
implicit none
integer :: n      
real(8) :: a(1:n+1) 
integer :: s      
integer :: e      
integer :: l,r    
real(8) :: k      
real(8) :: temp   
l=s
r=e+1
if ( r<=l ) return

k=a(s) 
do while(.true.)

   do while( .true. )
      l=l+1
      if ( (a(l) > k) .or. (l>=e) ) exit
   end do

   do while( .true. )
      r=r-1
      if ( (a(r) < k) .or. (r<=s) ) exit
   end do
   if ( r <= l ) exit

   temp=a(l)
   a(l)=a(r)
   a(r)=temp
end do
 
temp=a(s)
a(s)=a(r)
a(r)=temp

call quick_sort(a,n,s,r-1) 
call quick_sort(a,n,r+1,e)
return
end subroutine quick_sort
!==================================================!

!----------------------------------------------!
!----------------------------------------------!

subroutine writeconfig(rank)
!--------------------------------------!
 use configuration 
 implicit none
 integer :: i,rank
 character(len=3) :: ranks
 write (ranks,fmt='(i3.3)') rank
 open(10,file='conf'//ranks//'.log',status='replace')
 do i=1,nn
    write(10,'(i2)')spin(i)
 enddo
 !do i=1,sitnum*4
 !   write(10,'(i2)')nhpm(i,0),nhpm(i,1)
 !enddo
 write(10,*)mm,nh,nh1,nh2,nh3,nh4
 do i=0,mm-1
    write(10,*)opstring(i)
 enddo
 close(10)
 end subroutine writeconfig
!------------------------!

 subroutine readconfig(rank)
!---------------------!
 use configuration
 implicit none
 integer :: i,rank
 character(len=3) :: ranks
 write (ranks,fmt='(i3.3)') rank
 print*, 'conf'//ranks//'.log'
 open(10,file='conf'//ranks//'.log',status='old')
 do i=1,nn
    read(10,*)spin(i)
 enddo
 !do i=1,sitnum*4
 !   read(10,*)nhpm(i,0),nhpm(i,1)
 !enddo
 read(10,*)mm,nh,nh1,nh2,nh3,nh4
 allocate(opstring(0:mm-1))
 allocate(tauscale(0:mm-1))
 allocate(vertexlist(0:dxl*mm-1,0:1))
 allocate(vertexlist_map(0:dxl*mm-1))
 allocate(vertexspin(0:mxl-1,0:mm-1)) 
 allocate(rantau(nh)) 
 do i=0,mm-1
    read(10,*)opstring(i)
 enddo
 close(10)
 tauscale(:)=0
 end subroutine readconfig

!----------------------------------------------!

 subroutine clearconfig()
!---------------------!
 use configuration
 implicit none
 integer :: i
 mm=nn
 nh=nn
 nh1=0
 nh2=0
 nh3=0
 nh4=0
 !nhpm(:,:)=0
 deallocate(opstring)
 deallocate(tauscale)
 deallocate(vertexlist)
 deallocate(vertexlist_map)
 deallocate(vertexspin) 
 deallocate(rantau) 
 end subroutine clearconfig

!----------------------------------------------!
