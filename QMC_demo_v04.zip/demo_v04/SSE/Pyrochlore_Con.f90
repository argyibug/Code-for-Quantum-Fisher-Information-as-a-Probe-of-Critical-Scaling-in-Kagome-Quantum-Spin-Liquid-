module configuration
!----------------------------------------------!
! Most important parameters and data structures
!----------------------------------------------!
 save

 integer :: lx0
 integer :: ly0
 integer :: lz0
 integer :: lx
 integer :: ly
 integer :: lz
 integer :: nn0    ! number of sites
 integer :: nn    ! number of sites
 integer :: nb    ! number of bonds
 integer :: mm    ! total string length (mm=ns*ms)
 integer :: ns    ! number of substrings (time slices)
 integer :: mxl
 integer :: dxl
 !integer :: ms    ! maximum sub-string length
 integer :: tstp
 integer :: bincounter
 integer :: basis
 integer :: ntau
 integer :: nbs
 integer :: ofcc
 integer :: bb0
 integer :: bb1
 integer :: bb2

 integer :: clb_cur
 integer :: clb_nxt

 integer :: nms0
 integer :: bcty
 real(8) :: nhe1
 real(8) :: nhe2
 real(8) :: mag1
 real(8) :: mag2
 real(8) :: auen
 real(8) :: culg
 real(8) :: addele

 integer :: nms1=0
 integer :: nms2=0
 integer :: nms3=0

 real(8) :: beta  ! inverse temperature
 real(8) :: bet0  ! inverse temperature
 real(8) :: prob ! part of the acceptance probability for adding (removing) operator
 real(8) :: pbAc
 real(8) :: pbBs
 real(8) :: pbjp
 real(8) :: pbCn
 real(8) :: Ac0
 real(8) :: Bs0
 real(8) :: jp0
 real(8) :: hz0
 real(8) :: temp0
 real(8) :: temp1
 real(8) :: ntem
 real(8) :: dtem
 real(8) :: qastep
 real(8) :: lgstep
 real(8) :: Ac1
 real(8) :: Bs1
 real(8) :: jp1
 real(8) :: hz1
 real(8) :: Ac
 real(8) :: Bs
 real(8) :: jp
 real(8) :: hz
 real(8) :: dtau
 real(8) :: slpb
 real(8) :: slprob
 real(8) :: clustersize
 real(8) :: expb
 integer :: updtyp
 integer :: sitnum
 integer :: nnn
 integer :: bondmaker
 integer :: clustersignal
 integer, allocatable :: legn(:,:)
 integer :: nq
 integer :: nq_all
 integer :: cluster_lunch
 integer :: verdeg
 integer :: bonddeg
 integer :: grpbondnum
 integer :: btn
 integer :: grpbondepth
 real(8) :: time0
 real(8) :: time1
 
 integer, allocatable :: bondtab(:,:,:)
 integer, allocatable :: bondgrp(:,:,:)
 integer, allocatable :: vexgrptab(:,:,:,:,:)
 integer, allocatable :: vextag(:,:,:,:,:)
 integer, allocatable :: spingrpidx(:,:,:,:,:,:,:)
 integer, allocatable :: spingrploc(:,:)
 integer, allocatable :: spacevisit(:)
 integer, allocatable :: spingrptab(:,:,:,:,:,:,:)
 integer, allocatable :: spingrp(:,:,:)
 integer, allocatable :: loopgrploc(:)
 integer, allocatable :: bondchain(:,:)
 integer, allocatable :: hexagon(:,:,:)

 integer, allocatable :: parbok(:)
 real(8), allocatable :: parset(:,:)

 integer, allocatable :: ratab(:)
 integer, allocatable :: opvlog(:,:)
 integer, allocatable :: clusterflog(:,:)
 integer :: clusterbtm
 integer :: clusterdim
 integer :: clusterdimax

 real(8), allocatable :: weightable(:,:,:)

 integer, allocatable :: opstfp(:,:)
 integer, allocatable :: betable(:)
 integer, allocatable :: clustervislog(:,:)

 integer :: nh
 integer :: nh1
 integer :: nh2
 integer :: nh3
 integer :: nh4

 integer :: legcon
 integer :: legtot

 real(8) :: aclpre
 real(8) :: aclcrr

 !integer, allocatable :: nhpm(:,:)
 !integer, allocatable :: nhtp(:)

 integer, allocatable :: spin(:)
 integer, allocatable :: bsites(:,:)
 integer, allocatable :: sambon(:)
 integer, allocatable :: bontab(:)
 integer, allocatable :: opstring(:)
 integer, allocatable :: oporder(:)
 integer, allocatable :: tauscale(:)
 integer, allocatable :: vertexspin(:,:)
 integer, allocatable :: bondidx(:,:)
 !integer, allocatable :: opcluster(:,:)

 integer, allocatable :: frstspinop(:)
 integer, allocatable :: lastspinop(:)
 integer, allocatable :: vertexlist(:,:)
 integer, allocatable :: vertexlist_map(:)
 integer, allocatable :: opertyp(:)
 integer, allocatable :: dealtyp(:)
 integer, allocatable :: offoporder(:)
 integer, allocatable :: digoporder(:)
 real(8), allocatable :: rantau(:)
 integer, allocatable :: recorder(:,:)
 
 integer :: loop_eff_count
 integer :: loop_tot_count

 character(11) :: culgname
 character(11) :: loopname
 character(11) :: heauname

 real(8), parameter :: pi=3.14159265358979323d0
 real(8), parameter :: ex=2.71828182845904523d0

end module configuration

module measurementdata
 !--------------------------------------------!
 !Data we measured
 !--------------------------------------------!
 save

 real(8) :: enrg1=0.d0
 real(8) :: enrg2=0.d0
 real(8) :: amag1=0.d0
 real(8) :: amag2=0.d0
 real(8), allocatable :: bind1(:)
 real(8), allocatable :: bind2(:)
 real(8) :: tmag1=0.d0

 real(8), allocatable :: crr(:,:,:,:)      !correlation function in real space

 integer, allocatable :: qpts(:)    !list of q-points

 real(8), allocatable :: tcAc(:,:)    !correlation function in momentum space
 real(8), allocatable :: tc(:)
 real(8), allocatable :: ref(:,:)     ! real part of fourier transform of spins
 real(8), allocatable :: imf(:,:)      ! imaginary part of fourier transform of spins
 real(8), allocatable :: phi(:,:,:)   ! phase factors for fourier transforms
 real(8), allocatable :: cbbkgd(:)
 real(8), allocatable  :: ssbkgd(:)
 real(8), allocatable :: axie(:,:)

 real(8), allocatable :: stiff(:)


 integer, allocatable :: tgrd(:)    !grid of time points
 
 real(8), allocatable :: tcor(:,:)    !correlation function in momentum space
 real(8), allocatable :: tcorpm(:,:)    !correlation function in momentum space
 
 real(8), allocatable :: PMRS_temp(:,:,:,:)
 real(8), allocatable :: RealSpace(:,:,:,:)
 real(8), allocatable :: PMinRealSpace(:,:,:,:)
 real(8), allocatable :: demo_or(:,:,:,:)
 real(8), allocatable :: demo_pm(:,:,:,:)
 
 integer :: nc
 integer :: nf

 character(10) :: resname
 character(10) :: sffname
 character(10) :: bidname
 character(10) :: crrname
 character(11) :: tcAcname
 character(11) :: backname
 character(11) :: tcorname
 character(11) :: tcpmname
 character(11) :: tcdmname
 character(11) :: deorname
 character(11) :: depmname
 character(11) :: autoname
 character(11) :: etlgname

end module measurementdata

!==========================!
!main part of the programme!
!==========================!
! nn     =  number of spins
! beta   =  inverse temperature
! nbin   =  number of bins
! mstps  =  steps per bin for measurements
! istps  =  initial (equlibration) steps 

module vertexupdate
   save
   integer :: v0
   integer :: OpTy0
   integer :: site0
   integer :: v1
   integer :: v2
   integer :: vh0
   integer :: vh1
   integer :: vh2
   integer :: vht

   integer, allocatable :: x0(:)
   integer, allocatable :: x1(:)
   integer, allocatable :: x2(:)
   integer, allocatable :: vc(:,:)
   integer, allocatable :: xrelation(:,:)
   integer :: cerberus_flag
   integer :: bx
   integer :: opx
   integer, allocatable :: ix(:,:)
   integer :: iv

   integer :: looppm

   integer :: vt
   integer :: mmt
   integer :: bt
   integer :: opt
   integer :: udt
   integer :: typt
   integer :: sigt
   integer :: dealtyp_t

   integer :: lp
   integer :: lpdim
   integer :: lpdimax
   integer :: vdimcutoff
   integer :: vertexdim
   integer :: mvstep

   integer :: mm0
   integer :: b0
   integer :: op0
   integer :: ud0
   integer :: typ0
   integer :: sig0
   integer :: dltyp0
   integer :: nia

   integer :: length
   integer :: clustermark
   integer :: marker
   integer :: mrk0
   integer :: mrk1
   integer :: selfcest
   integer, allocatable :: cmplsg(:)
   integer :: update_counter
   integer :: cluster_counter
   integer :: counter
   integer :: dcounter
   integer :: ocounter
   integer :: probnum

   integer :: Spm_measure_signal
   integer :: OpTy1
   integer :: site1

   integer :: b
   integer :: op
   integer :: loop_counter

   integer :: vv
   integer :: dealtyp_v
   integer :: mmv

   integer :: udmrr
   integer :: rlmrr
   integer :: index_bp

   integer, allocatable :: pbcgcnt(:,:)
   integer, allocatable :: legtab(:,:)

   real(8) :: wgtaft
   real(8) :: wgtbfr
   real(8) :: totalwgt
   integer, allocatable :: state_leg(:,:)

   real(8) :: tau0
   real(8) :: delta_tau
   real(8), allocatable  :: dmweight(:)
   real(8), allocatable  :: fluxtable(:,:,:,:,:,:,:)
   real(8), allocatable :: fluxsut(:,:,:,:,:,:)
   integer, allocatable :: fluxnum(:,:,:,:,:,:)

end module vertexupdate

program basic_heisenberg_sse

   use configuration
   use measurementdata
   use vertexupdate
   implicit none
   include 'mpif.h'
   integer :: ierr,nprocs,i1,i2,i3,a1,a2,a3,cerberus_signal
   integer :: njp,nhz,annealing_signal
   real(8) :: dhz,djp
   integer :: rank,btidx,comm,st(mpi_status_size)
   integer :: i,j,k,r,l,nbins,msteps,isteps,tmsr,gtype,bsteps,dstep,xbins,cur_step
   integer :: pidx1,pidx2,nhtmp1,nhtmp2,idx1,idx2,aimproc,xsign,total_step,crr_step
   integer :: nhp1p1,nhn1p1,nhp2p1,nhn2p1,nhp1p2,nhn1p2,nhp2p2,nhn2p2,lt
   integer, allocatable :: extendhappen(:)
   real(8) :: jojo,beta_pev,beta_crr,en_crr,Ac_min,en_per,mg_crr,mg_per,m2_crr,m2_per
   real(8) :: tmax
   real(8), external :: ran

   open(unit=10, file='read.in', status="old")
   read(10,*)lx0,ly0,lz0,bcty
   read(10,*)Ac0,nnn
   read(10,*)slprob
   read(10,*)Ac1
   read(10,*)qastep,lgstep
   read(10,*)nbins,msteps,isteps
   read(10,*)xbins,bsteps
   read(10,*)dtau
   read(10,*)gtype,tmax
   read(10,*)tstp,tmsr
   close(unit=10)
   time0=0d0
   time1=0d0

   Bs0=0d0
   Bs1=0d0
   bondmaker=2
   Spm_measure_signal=0d0
   clustersignal=0d0
   cerberus_signal=0
   annealing_signal=1

   open(unit=10, file='temp.in', status="old")
   read(10,*)temp0
   read(10,*)temp1
   read(10,*)ntem
   close(unit=10)
   dtem=(temp1-temp0)/dble(ntem)
   bet0=temp1
   if (temp0==temp1) then
      beta=temp1
      ntem=0d0
   endif
   tmax=beta*0.5d0

   open(unit=10, file='jp.in', status="old")
   read(10,*)jp0
   read(10,*)jp1
   read(10,*)djp
   close(unit=10)
   njp=int((jp1-jp0)/dble(djp))
   if (jp0==jp1) then
      jp=jp0
      njp=0d0
   endif

   open(unit=10, file='hz.in', status="old")
   read(10,*)hz0
   read(10,*)hz1
   read(10,*)dhz
   close(unit=10)
   nhz=int((hz1-hz0)/dble(dhz))
   if (hz0==hz1) then
      hz=hz0
      nhz=0d0
   endif

   basis=0d0

   lx=lx0
   ly=ly0
   lz=lz0
   nn0=4*lx0*ly0*lz0
   beta=bet0

   !call initratiotable()
   !lx=ratab(1)
   !ly=ratab(1)
   !lz=ratab(1)

   !allocate(extendhappen(ratab(0)-1))
   !extendhappen(1)=1d0
   !extendhappen(2)=2d0
   !extendhappen(3)=4d0

   !lt=ratab(1)

   Ac=Ac0
   jp=jp0
   hz=hz0
   !call timemeasure(2)

   !allocate(nq(3))
   !xbins=2*xbins-1

   !rank=0
   dstep=100
   !dstep=dstep*xbins
   total_step=(xbins*bsteps)-dstep

   call MPI_init(ierr)
   call MPI_Comm_size(MPI_COMM_WORLD,nprocs,ierr)
   call MPI_Comm_rank(MPI_COMM_WORLD,rank,ierr)

   if (annealing_signal==1) call saveconfig(0,rank,-1)
   call initran(1,rank)
   call makelattice()
   print*,"make lattice done",nprocs
   call initconfig(rank,nprocs)
   print*,"step 0",nprocs,tmax
   call taugrid(gtype,tmax)
   !call qarrays()

   beta=bet0
   print*,"step 0",nprocs

   btidx=rank
   r=1
   l=1
   !beta_pev=bet0
   !beta_crr=bet0

   autoname='auto000.dat'
   heauname='heau000.dat'
   culgname='culg000.dat'
   loopname='lplg000.log'
   i3=rank/100
   i2=mod(rank,100)/10
   i1=mod(rank,10)

   heauname(7:7)=achar(48+i1)
   heauname(6:6)=achar(48+i2)
   heauname(5:5)=achar(48+i3)

   autoname(7:7)=achar(48+i1)
   autoname(6:6)=achar(48+i2)
   autoname(5:5)=achar(48+i3)

   culgname(7:7)=achar(48+i1)
   culgname(6:6)=achar(48+i2)
   culgname(5:5)=achar(48+i3)
   
   loopname(7:7)=achar(48+i1)
   loopname(6:6)=achar(48+i2)
   loopname(5:5)=achar(48+i3)

   open(10,file=heauname,status='replace')
   close(10)
   open(10,file=autoname,status='replace')
   close(10)
   open(10,file=culgname,status='replace')
   close(10)
   open(10,file=loopname,status='replace')
   close(10)

   !Ac_min=10**(-bet0)
   !Ac=Ac_min
   !call initweight(0,1,0,nprocs)

   print*,"step 1"

   open(10,file=culgname,status='replace')
   close(10)
   !slprob=0.01d0
   aclcrr=0d0
   aclpre=-1d0
   
   lx=lx0
   ly=ly0
   lz=lz0
   beta=bet0
   Ac=Ac0
   jp=jp0
   hz=hz0
   btidx=nprocs-1

   print*,int(njp),int(nhz),int(ntem)
   do a1=0, int(njp)
   if (njp/=0d0) jp=jp0+djp*a1
   do a2=0, int(nhz)
   if (nhz/=0d0) hz=hz0+dhz*a2
   do a3=0, int(ntem)
   if (ntem/=0d0) beta=temp0+dtem*a3
   !call reinconfig(rank,nprocs)
   deallocate(recorder)
   print*,"step init weight"
   call initweight(0,0,0,nprocs)
   print*,"step init flux"
   call initflux(1,rank)
   !call initfluxmul(1,rank)
   !if (clustersignal==1) call initspingroup(1,rank)
   print*,beta,hz,jp,rank,int(i/(100*1d0)),"heating"
   
   !pause
!==================================================================!
   !Do isteps equilibration sweeps, find the necessary sweep
   do i=1,isteps
      call diagonalupdate(rank)
      !call diagbondchanging(rank,1)
      !print*,"a",i,"rank",rank
      if (nh/=0) call linkvertices(2)
      !call timemeasure(0)
      !print*,"b",i,"rank",rank,nh
      if (clustersignal==1) call clusterupdate(rank,1)
      !print*,"c.0",i,"rank",rank,nh
      if (nh/=0) call loopupdate(0,rank)
      !call timemeasure(0)
      !print*,"c.a",i,"rank",rank,nh
      if (nh/=0) call cerberus(cerberus_signal,rank)
      !call timemeasure(1)
      !print*,"c",i,"rank",rank,nh
      call adjustcutoff(i)
      !print*,"d",i,"rank",rank,nh
      if (mod(i,1000)==0) then
         print*,beta,hz,jp,rank,int(i/(100*1d0)),"heating"
         !print*,rank,nh1,nh2,nh1*1d0/nh*1d0,nh2*1d0/nh*1d0
      endif
      !call automeasure()
      !print*,rank,i,nh1,nh2,nh1*1d0/nh*1d0,nh2*1d0/nh*1d0
   enddo
!==================================================================!

   print*,"step 2",rank

   allocate(recorder(nn,nh+1))
   recorder=0d0

   call writeconfig(rank)
   !print*,"check"
   recorder=0d0
   bincounter=0
   dmweight(:)=0d0
   call initCollection()
   !print*,"check"

   print*,"step 3",rank

   ! Do nbins bins with msteps MC sweeps in each, measure after each
   do j=1,nbins
      !bincounter=bincounter+1
      do i=1,msteps
         call diagonalupdate(rank)
         !call diagbondchanging(rank,1)
         !print*,"a",i,"rank",rank,nh
         if (nh/=0) call linkvertices(2)
         !call timemeasure(0)
         !print*,"b",i,"rank",rank
         if (clustersignal==1) call clusterupdate(rank,1)
         !print*,"c.0",i,"rank",rank,nh
         if (nh/=0) call loopupdate(1,rank)
         !call timemeasure(0)
         !print*,"c.0",i,"rank",rank,nh
         if (nh/=0) call cerberus(cerberus_signal,rank)
         !call timemeasure(1)
         !print*,"c.1",i,"rank",rank,nh
         call measure(rank)
         !print*,"c.2",i,"rank",rank,nh
         call measure2()
         !print*,"c.3",i,"rank",rank
         call measure3()
         !print*,"d",i,"rank",rank
         if ( mod(i,1000)==0 ) print*,beta,hz,jp,rank,i/(msteps*1d-2)
         !call automeasure()

      enddo
      !write bin averages to 'res.dat'!
      print*,bincounter
      call writeresult(0,rank)
      call writeconfig(rank)
      if (annealing_signal==1) call saveconfig(1,rank,a3)
      !rank=rank+1
   enddo 
   open(unit=10,file=heauname,position='append')
   write(10,*) dble(clusterdim)/dble(clusterbtm),clusterdimax
   close(10)
   clusterdimax=0d0
   clusterdim=0d0
   clusterbtm=0d0
   enddo
   enddo
   enddo
   print*,"step 4",rank

   call MPI_Barrier(MPI_COMM_WORLD,ierr)
   call MPI_Finalize(ierr) 

   bincounter=0
   call deallocateall()

end program basic_heisenberg_sse

!==================================================!

!==================================================!

subroutine initconfig(rank,nprocs)
   use configuration
   use measurementdata
   implicit none

   integer :: i,j,s,x,i1,i2,i3
   integer :: rank,nprocs
   real(8) :: rate,bmin,Acmin,Bsmin,jpmin,hzmin
   real(8), external :: ran

   print*, "initconfig",nprocs-1
   allocate(parset(0:nprocs-1,0:4))
   allocate(parbok(0:nprocs-1))
   print*, "initconfig",nprocs-1

   x=20
   !bmin=(bet0/2d0)*1d0
   bmin=1d0
   !rate=bet0*1d0/(bmin)
   !rate=(rate*((nprocs)**(-(1d0/x))))**(1/((nprocs-1d0)*1d0))
   !print*,rate
   !bmin=1d0*bet0/((nprocs*1d0)**(1d0/x))
   Acmin=0.8d0*Ac0
   Bsmin=1.2d0*Bs0
   jpmin=jp0
   hzmin=hz0
   do i=1,nprocs
      parbok(i-1)=i-1

      !parset(i-1,0)=bmin
      parset(i-1,0)=bet0
      !bmin=bmin*(((i+1d0)/i*1d0)**(1d0/x))
      !bmin=bmin*rate*(((i+1d0)/i*1d0)**(1d0/x))
      !bmin=bmin+(bet0-1d0)/((nprocs-1)*1d0)

      parset(i-1,1)=Ac0
      !Acmin=Acmin+(1d0-0.8d0)*Ac0/((nprocs-1)*1d0)
      !Acmin=Acmin-(1.1d0-1d0)*Ac0/((nprocs-1)*1d0)


      parset(i-1,2)=Ac0
      !Bsmin=Bsmin+(1d0-0.9d0)*Bs0/((nprocs-1)*1d0)
      !Bsmin=Bsmin-(1.2d0-1d0)*Bs0/((nprocs-1)*1d0)

      parset(i-1,3)=jp0

      parset(i-1,4)=hz0

   enddo
   !print*,parset(:,0),"0"
   !print*,parset(:,1),"1"
   !print*,parset(:,2),"2"
   !print*,parset(:,3),"3"
   !print*,parset(:,4),"4"
   parset(nprocs-1,0)=bet0
   parset(nprocs-1,1)=Ac0
   parset(nprocs-1,2)=Ac0
   parset(nprocs-1,3)=jp0
   parset(nprocs-1,4)=hz0
   parbok(nprocs-1)=nprocs-1

   print*,nn
   allocate(spin(nn))
   do i=1,sitnum
      do j=0,3
         spin(i+j*sitnum)=2*int(2.*ran())-1
      enddo
   enddo

   mm=nn
   ns=int(beta/dtau+0.1d0)

   nh=0
   nh1=0
   nh2=0
   nh3=0
   nh4=0
!=============================================================================!
   !allocate(opstring(0:mm-1))            !according to whether it is a sub-programme
   !opstring(:)=0                         !according to whether it is a sub-programme
   !allocate(tauscale(0:mm-1))            !according to whether it is a sub-programme
   !tauscale(:)=0                         !according to whether it is a sub-programme
   !allocate(opstfp(0:mm-1,0:mxl-1))             !according to whether it is a sub-programme
   !opstfp(:,:)=1                         !according to whether it is a sub-programme
   !allocate(vertexlist(0:dxl*mm-1,0:2))        !according to whether it is a sub-programme
   !allocate(vertexlist_map(0:dxl*mm-1))    !according to whether it is a sub-programme
   !allocate(vertexspin(0:mxl-1,0:mm-1))      !according to whether it is a sub-programme
   !allocate(spingrp(0:dxl-1,0:mm-1,0:2))
   !allocate(rantau(nh))                  !according to whether it is a sub-programme\
!=============================================================================!
!=============================================================================!
   call readconfig(rank)          !according to whether it is a sub-programme
!=============================================================================!
   allocate(opvlog(0:nn0,0:3))
   allocate(clusterflog(0:nn0,0:3))
   allocate(oporder(nn0))
   allocate(opertyp(nn0))
   allocate(dealtyp(nn0))
   allocate(offoporder(0:nn0))
   allocate(digoporder(0:nn0))
   allocate(frstspinop(nn0))
   allocate(lastspinop(nn0))
   allocate(crr(0:lx0-1,0:ly0-1,0:lz0-1,4))
   crr(:,:,:,:)=0
   allocate(stiff(0:3))
   stiff(:)=0
   clusterbtm=0
   clusterdim=0
   clusterdimax=0

   allocate(recorder(nn,nh+1))
   recorder=0d0

   call initweight(1,1,1,nprocs)
   allocate(clustervislog(0:dxl-1,0:1))

   allocate(bind1(2))
   bind1(:)=0d0
   allocate(bind2(2))
   bind2(:)=0d0

   resname='res000.dat'
   sffname='sff000.dat'
   bidname='bid000.dat'
   crrname='crr000.dat'
   backname='back000.dat'
   tcAcname='tcAc000.dat'

   i3=rank/100
   i2=mod(rank,100)/10
   i1=mod(rank,10)
   resname(6:6)=achar(48+i1)
   resname(5:5)=achar(48+i2)
   resname(4:4)=achar(48+i3)

   sffname(6:6)=achar(48+i1)
   sffname(5:5)=achar(48+i2)
   sffname(4:4)=achar(48+i3)

   bidname(6:6)=achar(48+i1)
   bidname(5:5)=achar(48+i2)
   bidname(4:4)=achar(48+i3)

   crrname(6:6)=achar(48+i1)
   crrname(5:5)=achar(48+i2)
   crrname(4:4)=achar(48+i3)

   tcAcname(7:7)=achar(48+i1)
   tcAcname(6:6)=achar(48+i2)
   tcAcname(5:5)=achar(48+i3)

   backname(7:7)=achar(48+i1)
   backname(6:6)=achar(48+i2)
   backname(5:5)=achar(48+i3)

   open(10,file=resname,status='replace')
   close(10)  
   open(10,file=sffname,status='replace')
   close(10)      
   open(10,file=bidname,status='replace')
   close(10) 
   open(10,file=crrname,status='replace')
   close(10)  
   open(10,file=backname,status='replace')
   close(10)  
   open(10,file=tcAcname,status='replace')
   close(10) 

   print*,"initflux"
   call initflux(0,rank)
   call initfluxmul(0,rank)
   if (clustersignal==1) call initspingroup(0,rank)
   !pause

   allocate(axie(3,0:72))
   axie=0d0
   !a1=(1,sqrt(3),0)
   !a2=(2,0,0)
   !a3=(1,1/sqrt(3),2*sqrt(2/3))
   !a1=(1,sqrt(3),0)
   !a2=(2,0,0)
   !a3=(1,1/sqrt(3),2*sqrt(2/3))
   !axie(1,0)=0d0
   !axie(2,0)=1d0
   !axie(3,0)=0d0

   !axie(1,1)=-0.5d0
   !axie(2,1)=0.5d0
   !axie(3,1)=0d0

   !axie(1,2)=-1d0
   !axie(2,2)=-0d0
   !axie(3,2)=-0d0

   !axie(1,3)=0d0
   !axie(2,3)=0d0
   !axie(3,3)=1d0

   !axie(1,4)=0d0
   !axie(2,4)=-0.5d0
   !axie(3,4)=0.5d0

   !axie(1,5)=-0.5d0
   !axie(2,5)=0d0
   !axie(3,5)=0.5d0

   !axie(1,6)=0.5d0
   !axie(2,6)=-0.5d0
   !axie(3,6)=0d0

   !axie(1,7)=0d0
   !axie(2,7)=0d0
   !axie(3,7)=0d0

   !axie(1,8)=0d0
   !axie(2,8)=0d0
   !axie(3,8)=0d0

   !axie(1,9)=0
   !axie(2,9)=0d0
   !axie(3,9)=0d0

   !axie(1,10)=0d0
   !axie(2,10)=0d0
   !axie(3,10)=0d0

   !axie(1,11)=0d0
   !axie(2,11)=0d0
   !axie(3,11)=0d0

   !a1=(1,sqrt(3),0)
   !a2=(2,0,0)
   !a3=(1,1/sqrt(3),2*sqrt(2/3))
   axie(1,0)=1d0
   axie(2,0)=0d0
   axie(3,0)=0d0

   axie(1,1)=-0.5d0
   axie(2,1)=sqrt(3d0)/2d0
   axie(3,1)=0d0

   axie(1,2)=-0.5d0
   axie(2,2)=-sqrt(3d0)/2d0
   axie(3,2)=-0d0

   axie(1,3)=0.5d0
   axie(2,3)=1d0/(2d0*sqrt(3d0))
   axie(3,3)=sqrt(2d0/3d0)

   axie(1,4)=-0.5d0
   axie(2,4)=1d0/(2d0*sqrt(3d0))
   axie(3,4)=sqrt(2d0/3d0)

   axie(1,5)=0d0
   axie(2,5)=1d0/(2d0*sqrt(3d0))-sqrt(3d0)/2d0
   axie(3,5)=sqrt(2d0/3d0)

   axie(1,6)=0.5d0
   axie(2,6)=-sqrt(3d0)/2d0
   axie(3,6)=0d0

   axie(1,7)=0.5d0
   axie(2,7)=sqrt(3d0)/2d0
   axie(3,7)=0d0

   axie(1,8)=-1d0
   axie(2,8)=0d0
   axie(3,8)=0d0

   axie(1,9)=0.5d0
   axie(2,9)=-1d0/(2d0*sqrt(3d0))
   axie(3,9)=-sqrt(2d0/3d0)

   axie(1,10)=0d0
   axie(2,10)=-1d0/(2d0*sqrt(3d0))+sqrt(3d0)/2d0
   axie(3,10)=-sqrt(2d0/3d0)

   axie(1,11)=-0.5d0
   axie(2,11)=-1d0/(2d0*sqrt(3d0))
   axie(3,11)=-sqrt(2d0/3d0)

end subroutine initconfig
!==================================================!
!==================================================!

subroutine reinconfig(rank,nprocs)
   use configuration
   use measurementdata
   implicit none

   integer :: i,j,s,x
   integer :: rank,nprocs
   real(8) :: rate,bmin,Acmin,Bsmin,jpmin,hzmin
   real(8), external :: ran

   do i=1,sitnum
      spin(i)=2*int(2.*ran())-1
      spin(i+sitnum)=2*int(2.*ran())-1
      spin(i+2*sitnum)=2*int(2.*ran())-1
      spin(i+3*sitnum)=2*int(2.*ran())-1
      !spin(i)=1
      !spin(i+sitnum)=1
      !spin(i+2*sitnum)=1
      !spin(i+3*sitnum)=1
   enddo

   mm=nn
   ns=int(beta/dtau+0.1d0)

   nh=0
   nh1=0
   nh2=0
   nh3=0
   nh4=0
!=============================================================================!
   deallocate(opstring)                  !according to whether it is a sub-programme
   allocate(opstring(0:mm-1))            !according to whether it is a sub-programme
   opstring(:)=0                         !according to whether it is a sub-programme
   deallocate(tauscale)                  !according to whether it is a sub-programme
   allocate(tauscale(0:mm-1))            !according to whether it is a sub-programme
   tauscale(:)=0                         !according to whether it is a sub-programme
   deallocate(vertexlist)                !according to whether it is a sub-programme
   allocate(vertexlist(0:dxl*mm-1,0:2))  !according to whether it is a sub-programme
   deallocate(vertexlist_map)            !according to whether it is a sub-programme
   allocate(vertexlist_map(0:dxl*mm-1))  !according to whether it is a sub-programme
   deallocate(vertexspin)                !according to whether it is a sub-programme
   allocate(vertexspin(0:mxl-1,0:mm-1))  !according to whether it is a sub-programme
   deallocate(spingrp)                   !according to whether it is a sub-programme
   allocate(spingrp(0:dxl-1,0:mm-1,0:2))     !according to whether it is a sub-programme
   deallocate(rantau)                    !according to whether it is a sub-programme
   allocate(rantau(nh))                  !according to whether it is a sub-programme
!=============================================================================!
!=============================================================================!
   !call readconfig(rank)          !according to whether it is a sub-programme
!=============================================================================!
   deallocate(opvlog)
   allocate(opvlog(0:nh,0:3))
   deallocate(clusterflog)
   allocate(clusterflog(0:nn0,0:3))
   deallocate(oporder)
   allocate(oporder(nn0))
   deallocate(opertyp)
   allocate(opertyp(nn0))
   deallocate(dealtyp)
   allocate(dealtyp(nn0))
   deallocate(offoporder)
   allocate(offoporder(0:nn0))
   deallocate(digoporder)
   allocate(digoporder(0:nn0))
   deallocate(frstspinop)
   allocate(frstspinop(nn0))
   deallocate(lastspinop)
   allocate(lastspinop(nn0))

   deallocate(opstfp)
   allocate(opstfp(0:mm-1,0:mxl-1))
   opstfp(:,:)=1d0

   crr=0d0
   enrg1=0d0
   enrg2=0d0
   amag1=0d0
   amag2=0d0
   bind1=0d0
   bind2=0d0
   nms1=0d0
   nms2=0d0
   nms0=0d0
   stiff(:)=0d0

end subroutine reinconfig
!==================================================!

!==================================================!

subroutine initweight(signal,signal2,signal3,nprocs)
   use configuration
   implicit none
   integer :: i,j,k,l,temp,spnum,index,signal,signal2,signal3,nprocs
   integer :: dnn,kit,pn
   integer, allocatable :: spinstate(:,:)
   integer, allocatable :: spinflip(:)
   real(8) :: wgt,sptm,cf
   allocate(spinstate(0:mxl-1,0:1))
   allocate(spinflip(0:mxl-1))

   cf=2d0

   if (signal==1) then
      allocate(weightable(0:verdeg,0:verdeg,4))
      weightable(:,:,:)=0d0
   endif
   
   if (bondmaker==0) then
      weightable(:,:,1)=0d0
      addele=Ac*0.25d0+hz/3d0*0.5d0+jp
      do i=0,legn(1,2)
         do k=0,mxl-1
            spinstate(k,0)=(mod(int(i/(2**(k))),2))*2-1
         enddo
         do j=0,legn(1,2)
            if (i==j) then
               weightable(i,j,1)=((addele)-Ac*(spinstate(0,0)*spinstate(1,0))*0.25d0-(spinstate(0,0)+spinstate(1,0))*hz/6d0*0.5d0)
            else
               kit=0d0
               dnn=0d0
               do k=0,mxl-1
                  spinstate(k,1)=(mod(int(j/(2**(k))),2))*2-1
                  if (spinstate(k,1)==spinstate(k,0)) then
                     spinflip(k)=1
                  else
                     kit=kit+1
                     pn=pn+spinstate(k,0)
                     spinflip(k)=-1
                  endif
               enddo
               if (kit==2 .and. pn==0d0) then
                  if (spinflip(0)==-1 .and. spinflip(1)==-1) then
                     weightable(i,j,1)=jp
                  else
                     weightable(i,j,1)=0
                  endif
               else
                  weightable(i,j,1)=0
               endif
            endif
         enddo
      enddo

   elseif (bondmaker==1) then
      weightable(:,:,1)=0d0
      !addele=Ac*3d0*0.25d0*0.5d0+hz*0.5d0*0.5d0+jp
      addele=Ac*3d0*0.25d0*0.5d0+hz*0.5d0*0.5d0
      do i=0,legn(1,2)
         do k=0,mxl-1
            spinstate(k,0)=(mod(int(i/(2**(k))),2))*2-1
         enddo
         !print*, "idx",i,"spinstate",spinstate(:,0)
         do j=0,legn(1,2)
            if (i==j) then
               weightable(i,j,1)=((addele)-Ac*(spinstate(0,0)*spinstate(1,0)+&
               &spinstate(1,0)*spinstate(2,0)+&
               &spinstate(2,0)*spinstate(0,0))*0.25d0*0.5d0-&
               &(spinstate(0,0)+spinstate(1,0)+spinstate(2,0))*hz/6d0*0.5d0)
            else
               kit=0d0
               dnn=0d0
               pn=0d0
               do k=0,mxl-1
                  spinstate(k,1)=(mod(int(j/(2**(k))),2))*2-1
                  if (spinstate(k,1)==spinstate(k,0)) then
                     spinflip(k)=1
                  else
                     kit=kit+1
                     pn=pn+spinstate(k,0)
                     spinflip(k)=-1
                  endif
               enddo
               if (kit==2 .and. pn==0) then
                  if (spinflip(0)==-1 .and. spinflip(1)==-1) then
                     weightable(i,j,1)=jp*0.5d0
                  elseif (spinflip(1)==-1 .and. spinflip(2)==-1) then
                     weightable(i,j,1)=jp*0.5d0
                  elseif (spinflip(2)==-1 .and. spinflip(3)==-1) then
                     weightable(i,j,1)=jp*0.5d0
                  elseif (spinflip(0)==-1 .and. spinflip(3)==-1) then
                     weightable(i,j,1)=jp*0.5d0
                  else
                     weightable(i,j,1)=0
                  endif
               else
                  weightable(i,j,1)=0
               endif
            endif
         enddo
      enddo

   elseif (bondmaker==2) then
      weightable(:,:,1)=0d0
      addele=Ac*3d0*0.5d0+hz!+jp
      do i=0,legn(1,2)
         do k=0,mxl-1
            spinstate(k,0)=(mod(int(i/(2**(k))),2))*2-1
         enddo
         !print*, "idx",i,"spinstate",spinstate(:,0)
         do j=0,legn(1,2)
            if (i==j) then
               weightable(i,j,1)=((addele)-Ac*(spinstate(0,0)*spinstate(1,0)+&
               &spinstate(1,0)*spinstate(2,0)+&
               &spinstate(2,0)*spinstate(3,0)+&
               &spinstate(3,0)*spinstate(0,0)+&
               &spinstate(0,0)*spinstate(2,0)+&
               &spinstate(1,0)*spinstate(3,0))*0.25d0-&
               &(spinstate(0,0)+spinstate(1,0)+spinstate(2,0)+spinstate(3,0))*hz*0.5d0*0.5d0)
            else
               kit=0d0
               dnn=0d0
               pn=0d0
               do k=0,mxl-1
                  spinstate(k,1)=(mod(int(j/(2**(k))),2))*2-1
                  if (spinstate(k,1)==spinstate(k,0)) then
                     spinflip(k)=1
                  else
                     kit=kit+1
                     pn=pn+spinstate(k,0)
                     dnn=dnn+2**k+1
                     spinflip(k)=-1
                  endif
               enddo
               if (kit==2 .and. pn==0) then
                  if (spinflip(0)==-1 .and. spinflip(1)==-1) then
                     weightable(i,j,1)=jp
                  elseif (spinflip(1)==-1 .and. spinflip(2)==-1) then
                     weightable(i,j,1)=jp
                  elseif (spinflip(2)==-1 .and. spinflip(3)==-1) then
                     weightable(i,j,1)=jp
                  elseif (spinflip(3)==-1 .and. spinflip(0)==-1) then
                     weightable(i,j,1)=jp
                  elseif (spinflip(0)==-1 .and. spinflip(2)==-1) then
                     weightable(i,j,1)=jp
                  elseif (spinflip(1)==-1 .and. spinflip(3)==-1) then
                     weightable(i,j,1)=jp
                  else
                     weightable(i,j,1)=0
                  endif
               else
                  weightable(i,j,1)=0
               endif
            endif
         enddo
      enddo
   
   elseif (bondmaker==3) then
      weightable(:,:,1)=0d0
      addele=Ac*12d0*0.25d0*0.25d0+7d0*hz*0.5d0*0.25d0!+jp*0.25d0
      do i=0,legn(1,2)
         do k=0,mxl-1
            spinstate(k,0)=(mod(int(i/(2**(k))),2))*2-1
         enddo
         !print*, "idx",i,"spinstate",spinstate(:,0)
         do j=0,legn(1,2)
            if (i==j) then
               weightable(i,j,1)=((addele)-Ac*(spinstate(0,0)*spinstate(1,0)+&
               &spinstate(1,0)*spinstate(2,0)+&
               &spinstate(2,0)*spinstate(3,0)+&
               &spinstate(3,0)*spinstate(0,0)+&
               &spinstate(0,0)*spinstate(2,0)+&
               &spinstate(1,0)*spinstate(3,0)+&
               
               &spinstate(0,0)*spinstate(4,0)+&
               &spinstate(4,0)*spinstate(5,0)+&
               &spinstate(5,0)*spinstate(6,0)+&
               &spinstate(6,0)*spinstate(0,0)+&
               &spinstate(0,0)*spinstate(5,0)+&
               &spinstate(4,0)*spinstate(6,0))*0.25d0*0.25d0-&
               &(spinstate(0,0)+spinstate(1,0)+spinstate(2,0)+spinstate(3,0)&
               &+spinstate(4,0)+spinstate(5,0)+spinstate(6,0))*hz*0.5d0*0.25d0)
            else
               kit=0d0
               dnn=0d0
               pn=0d0
               do k=0,mxl-1
                  spinstate(k,1)=(mod(int(j/(2**(k))),2))*2-1
                  if (spinstate(k,1)==spinstate(k,0)) then
                     spinflip(k)=1
                  else
                     kit=kit+1
                     pn=pn+spinstate(k,0)
                     spinflip(k)=-1
                  endif
               enddo
               if (kit==2 .and. pn==0) then
                  if (spinflip(0)==-1 .and. spinflip(1)==-1) then
                     weightable(i,j,1)=jp*0.25d0
                  elseif (spinflip(1)==-1 .and. spinflip(2)==-1) then
                     weightable(i,j,1)=jp*0.25d0
                  elseif (spinflip(2)==-1 .and. spinflip(3)==-1) then
                     weightable(i,j,1)=jp*0.25d0
                  elseif (spinflip(3)==-1 .and. spinflip(0)==-1) then
                     weightable(i,j,1)=jp*0.25d0
                  elseif (spinflip(0)==-1 .and. spinflip(2)==-1) then
                     weightable(i,j,1)=jp*0.25d0
                  elseif (spinflip(1)==-1 .and. spinflip(3)==-1) then
                     weightable(i,j,1)=jp*0.25d0
                  elseif (spinflip(0)==-1 .and. spinflip(4)==-1) then
                     weightable(i,j,1)=jp*0.25d0
                  elseif (spinflip(4)==-1 .and. spinflip(5)==-1) then
                     weightable(i,j,1)=jp*0.25d0
                  elseif (spinflip(5)==-1 .and. spinflip(6)==-1) then
                     weightable(i,j,1)=jp*0.25d0
                  elseif (spinflip(6)==-1 .and. spinflip(0)==-1) then
                     weightable(i,j,1)=jp*0.25d0
                  elseif (spinflip(0)==-1 .and. spinflip(5)==-1) then
                     weightable(i,j,1)=jp*0.25d0
                  elseif (spinflip(4)==-1 .and. spinflip(6)==-1) then
                     weightable(i,j,1)=jp*0.25d0
                  else
                     weightable(i,j,1)=0
                  endif
               else
                  weightable(i,j,1)=0
               endif
            endif
         enddo
      enddo
   
   elseif (bondmaker==4) then
      weightable(:,:,1)=0d0
      addele=Ac*6d0*0.25d0*0.5d0+6d0*hz*0.5d0*0.5d0!+jp*0.5d0
      do i=0,legn(1,2)
         do k=0,mxl-1
            spinstate(k,0)=(mod(int(i/(2**(k))),2))*2-1
         enddo
         !print*, "idx",i,"spinstate",spinstate(:,0)
         do j=0,legn(1,2)
            if (i==j) then
               weightable(i,j,1)=((addele)-Ac*(spinstate(0,0)*spinstate(1,0)+&
               &spinstate(1,0)*spinstate(2,0)+&
               &spinstate(2,0)*spinstate(0,0)+&

               &spinstate(0,0)*spinstate(3,0)+&
               &spinstate(1,0)*spinstate(4,0)+&
               &spinstate(2,0)*spinstate(5,0))*0.25d0*0.5d0-&
               &(spinstate(0,0)+spinstate(1,0)+spinstate(2,0)+spinstate(3,0)&
               &+spinstate(4,0)+spinstate(5,0))*hz*0.5d0*0.5d0)
            else
               kit=0d0
               dnn=0d0
               pn=0d0
               do k=0,mxl-1
                  spinstate(k,1)=(mod(int(j/(2**(k))),2))*2-1
                  if (spinstate(k,1)==spinstate(k,0)) then
                     spinflip(k)=1
                  else
                     kit=kit+1
                     pn=pn+spinstate(k,0)
                     spinflip(k)=-1
                  endif
               enddo
               if (kit==2 .and. pn==0) then
                  if (spinflip(0)==-1 .and. spinflip(1)==-1) then
                     weightable(i,j,1)=jp*0.5d0
                  elseif (spinflip(1)==-1 .and. spinflip(2)==-1) then
                     weightable(i,j,1)=jp*0.5d0
                  elseif (spinflip(2)==-1 .and. spinflip(0)==-1) then
                     weightable(i,j,1)=jp*0.5d0
                  elseif (spinflip(0)==-1 .and. spinflip(3)==-1) then
                     weightable(i,j,1)=jp*0.5d0
                  elseif (spinflip(1)==-1 .and. spinflip(4)==-1) then
                     weightable(i,j,1)=jp*0.5d0
                  elseif (spinflip(2)==-1 .and. spinflip(5)==-1) then
                     weightable(i,j,1)=jp*0.5d0
                  else
                     weightable(i,j,1)=0
                  endif
               else
                  weightable(i,j,1)=0
               endif
            endif
         enddo
      enddo
      
   endif
   !do i=0,verdeg
   !   kit=0d0
   !   do j=0,verdeg
   !      if (weightable(i,j,1)/=0d0) then
   !         print*,"i=",i,"j=",j,weightable(i,j,1)
   !         kit=kit+1
   !      endif
   !   enddo
   !   print*, "kit",kit
   !   print*, "++++++++++++++++++++++++++++++++"
   !enddo
   !pause
   
   if (nnn==1) then
   endif

   !print*,nn
   if (signal2==1) then
      pbjp=0d0
      if (nnn==1) then
         prob=pbAc+pbBs+pbjp+pbCn
         nbs=nbs
      else
         prob=pbAc+pbjp
         nbs=pbAc
      endif
   endif
   ! print*,prob,sitnum,nn
   ! do i=0,verdeg
   !    print*,"weightable",i,weightable(i,i,1),(mod(int(i/(2**(0))),2))*2-1
   !    print*,"weightable",i,(mod(int(i/(2**(0))),2))*2-1,(mod(int(i/(2**(1))),2))*2-1,(mod(int(i/(2**(2))),2))*2-1&
   !    &,(mod(int(i/(2**(3))),2))*2-1&
   !    &,(mod(int(i/(2**(4))),2))*2-1,(mod(int(i/(2**(5))),2))*2-1,(mod(int(i/(2**(6))),2))*2-1
   ! enddo
   !pause

end subroutine initweight
!==================================================!
!==================================================!

subroutine makelattice()
   use configuration
   implicit none
   integer :: s,x1,x2,y1,y2,z1,z2,index,i
   integer :: s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,bt,bc
   integer :: s11,s12,s13,s14,s15,s16,s17,s18,s19,s20
   integer :: s21,s22,s23,s24,s25,bmk
   integer :: xx1,xx2,xx3,xx4,yy1,yy2,yy3,yy4
   integer :: numbd

   !bondmaker=1
   !bondmaker=0

   allocate(legn(4,2))

   nn=lx*ly*lz
   print*,nn,lx,ly,lz
   bc=0d0
   pbAc=0d0
   pbBs=0d0
   pbCn=0d0

   if (bondmaker==1) then
      nb=8*nn+24*nn+36*nn
      mxl=3
      numbd=8-1
      bonddeg=3
      allocate(bondtab(2,3,4))
      bondtab(:,:,:)=0
      bondtab(1,1,1)=0
      bondtab(2,1,1)=1
      bondtab(1,2,1)=1
      bondtab(2,2,1)=2
      bondtab(1,3,1)=2
      bondtab(2,3,1)=0
   elseif (bondmaker==0) then
      nb=12*nn+24*nn+36*nn
      mxl=2
      numbd=12-1
      bonddeg=1
      allocate(bondtab(2,1,4))
      bondtab(:,:,:)=0
      bondtab(1,1,1)=0
      bondtab(2,1,1)=1
   elseif (bondmaker==2) then
      nb=2*nn+24*nn+36*nn
      mxl=4
      numbd=2-1
      bonddeg=6
      allocate(bondtab(2,6,4))
      bondtab(:,:,:)=0
      bondtab(1,1,1)=0
      bondtab(2,1,1)=1
      bondtab(1,2,1)=1
      bondtab(2,2,1)=2
      bondtab(1,3,1)=2
      bondtab(2,3,1)=3
      bondtab(1,4,1)=3
      bondtab(2,4,1)=0
      bondtab(1,5,1)=0
      bondtab(2,5,1)=2
      bondtab(1,6,1)=1
      bondtab(2,6,1)=3
   elseif (bondmaker==3) then
      nb=4*nn+24*nn+36*nn
      mxl=7
      numbd=4-1
      bonddeg=12
      allocate(bondtab(2,12,4))
      bondtab(:,:,:)=0
      bondtab(1,1,1)=0
      bondtab(2,1,1)=1
      bondtab(1,2,1)=1
      bondtab(2,2,1)=2
      bondtab(1,3,1)=2
      bondtab(2,3,1)=3
      bondtab(1,4,1)=3
      bondtab(2,4,1)=0
      bondtab(1,5,1)=0
      bondtab(2,5,1)=2
      bondtab(1,6,1)=1
      bondtab(2,6,1)=3

      bondtab(1,7,1)=0
      bondtab(2,7,1)=4
      bondtab(1,8,1)=4
      bondtab(2,8,1)=5
      bondtab(1,9,1)=5
      bondtab(2,9,1)=6
      bondtab(1,10,1)=6
      bondtab(2,10,1)=0
      bondtab(1,11,1)=0
      bondtab(2,11,1)=5
      bondtab(1,12,1)=4
      bondtab(2,12,1)=6
   elseif (bondmaker==4) then
      nb=4*nn+24*nn+36*nn
      mxl=6
      numbd=4-1
      bonddeg=6
      allocate(bondtab(2,6,4))
      bondtab(:,:,:)=0
      bondtab(1,1,1)=0
      bondtab(2,1,1)=1
      bondtab(1,2,1)=1
      bondtab(2,2,1)=2
      bondtab(1,3,1)=2
      bondtab(2,3,1)=1

      bondtab(1,4,1)=0
      bondtab(2,4,1)=3
      bondtab(1,5,1)=1
      bondtab(2,5,1)=4
      bondtab(1,6,1)=2
      bondtab(2,6,1)=5

   endif
   dxl=2*mxl

   if (clustersignal==1) call initvexgrptab()
   
   allocate(bsites(mxl,nb))
   allocate(sambon(nb))
   sambon(:)=-1d0
   allocate(bontab(nb))
   bontab(:)=-1d0
   bsites(:,:)=-1
   allocate(hexagon(nn,0:3,0:5))
   do x1=0,lx-1
      do y1=0,ly-1
         do z1=0,lz-1
         s=1+x1+y1*lx+z1*lx*ly

         s1=1+mod(x1+0+lx,lx)+mod(y1+0+ly,ly)*lx+mod(z1+0+lz,lz)*lx*ly
         s2=1+mod(x1+0+lx,lx)+mod(y1+0+ly,ly)*lx+mod(z1+1+lz,lz)*lx*ly
         s3=1+mod(x1-1+lx,lx)+mod(y1+0+ly,ly)*lx+mod(z1+1+lz,lz)*lx*ly
         s4=1+mod(x1+0+lx,lx)+mod(y1-1+ly,ly)*lx+mod(z1+1+lz,lz)*lx*ly

         s5=1+mod(x1+1+lx,lx)+mod(y1+0+ly,ly)*lx+mod(z1+0+lz,lz)*lx*ly
         s6=1+mod(x1+0+lx,lx)+mod(y1+1+ly,ly)*lx+mod(z1+0+lz,lz)*lx*ly
         s7=1+mod(x1-1+lx,lx)+mod(y1+0+ly,ly)*lx+mod(z1+0+lz,lz)*lx*ly
         s8=1+mod(x1+0+lx,lx)+mod(y1-1+ly,ly)*lx+mod(z1+0+lz,lz)*lx*ly

         s9=1+mod(x1+0+lx,lx)+mod(y1+0+ly,ly)*lx+mod(z1-1+lz,lz)*lx*ly
         s10=1+mod(x1+1+lx,lx)+mod(y1-1+ly,ly)*lx+mod(z1+0+lz,lz)*lx*ly
         s11=1+mod(x1+0+lx,lx)+mod(y1+1+ly,ly)*lx+mod(z1-1+lz,lz)*lx*ly
         s12=1+mod(x1-1+lx,lx)+mod(y1+1+ly,ly)*lx+mod(z1+0+lz,lz)*lx*ly

         s13=1+mod(x1+1+lx,lx)+mod(y1+0+ly,ly)*lx+mod(z1-1+lz,lz)*lx*ly
         s14=1+mod(x1-1+lx,lx)+mod(y1-1+ly,ly)*lx+mod(z1+1+lz,lz)*lx*ly
         s15=1+mod(x1-2+lx,lx)+mod(y1+0+ly,ly)*lx+mod(z1+1+lz,lz)*lx*ly
         s16=1+mod(x1+0+lx,lx)+mod(y1+1+ly,ly)*lx+mod(z1+1+lz,lz)*lx*ly

         s17=1+mod(x1+0+lx,lx)+mod(y1-2+ly,ly)*lx+mod(z1+1+lz,lz)*lx*ly
         s18=1+mod(x1-1+lx,lx)+mod(y1+1+ly,ly)*lx+mod(z1+1+lz,lz)*lx*ly
         s19=1+mod(x1-2+lx,lx)+mod(y1+1+ly,ly)*lx+mod(z1+1+lz,lz)*lx*ly
         s20=1+mod(x1+1+lx,lx)+mod(y1+0+ly,ly)*lx+mod(z1+1+lz,lz)*lx*ly

         s21=1+mod(x1+1+lx,lx)+mod(y1-1+ly,ly)*lx+mod(z1+1+lz,lz)*lx*ly
         s22=1+mod(x1+1+lx,lx)+mod(y1-2+ly,ly)*lx+mod(z1+1+lz,lz)*lx*ly
         s23=1+mod(x1-1+lx,lx)+mod(y1+2+ly,ly)*lx+mod(z1+2+lz,lz)*lx*ly
         s24=1+mod(x1-1+lx,lx)+mod(y1-1+ly,ly)*lx+mod(z1+2+lz,lz)*lx*ly
         s25=1+mod(x1-1+lx,lx)+mod(y1+0+ly,ly)*lx+mod(z1+2+lz,lz)*lx*ly

         hexagon(s,0,0)=s5+3*nn
         hexagon(s,0,1)=s5+2*nn
         hexagon(s,0,2)=s6+1*nn
         hexagon(s,0,3)=s6+3*nn
         hexagon(s,0,4)=s2+2*nn
         hexagon(s,0,5)=s2+1*nn
         !==============================!
         hexagon(s,1,0)=s7+3*nn
         hexagon(s,1,1)=s7+2*nn
         hexagon(s,1,2)=s12+0*nn
         hexagon(s,1,3)=s12+3*nn
         hexagon(s,1,4)=s3+2*nn
         hexagon(s,1,5)=s3+0*nn
         !==============================!
         hexagon(s,2,0)=s8+3*nn
         hexagon(s,2,1)=s8+1*nn
         hexagon(s,2,2)=s10+0*nn
         hexagon(s,2,3)=s10+3*nn
         hexagon(s,2,4)=s4+1*nn
         hexagon(s,2,5)=s4+0*nn
         !==============================!
         hexagon(s,3,0)=s9+2*nn
         hexagon(s,3,1)=s9+1*nn
         hexagon(s,3,2)=s13+0*nn
         hexagon(s,3,3)=s13+2*nn
         hexagon(s,3,4)=s11+1*nn
         hexagon(s,3,5)=s11+0*nn
         !==============================!

         if (bondmaker==4) then
            bmk=0d0
            bsites(1,s+bmk*nn)=s1
            bsites(2,s+bmk*nn)=s1+1*nn
            bsites(3,s+bmk*nn)=s1+2*nn
            bsites(4,s+bmk*nn)=s9+3*nn
            bsites(5,s+bmk*nn)=s11+3*nn
            bsites(6,s+bmk*nn)=s13+3*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=1d0
            bsites(1,s+bmk*nn)=s1+2*nn
            bsites(2,s+bmk*nn)=s1+3*nn
            bsites(3,s+bmk*nn)=s1+1*nn
            bsites(4,s+bmk*nn)=s5
            bsites(5,s+bmk*nn)=s2
            bsites(6,s+bmk*nn)=s6
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=2d0
            bsites(1,s+bmk*nn)=s1
            bsites(2,s+bmk*nn)=s1+2*nn
            bsites(3,s+bmk*nn)=s1+3*nn
            bsites(4,s+bmk*nn)=s8+1*nn
            bsites(5,s+bmk*nn)=s10+1*nn
            bsites(6,s+bmk*nn)=s4+1*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=3d0
            bsites(1,s+bmk*nn)=s1
            bsites(2,s+bmk*nn)=s1+1*nn
            bsites(3,s+bmk*nn)=s1+3*nn
            bsites(4,s+bmk*nn)=s7+2*nn
            bsites(5,s+bmk*nn)=s12+2*nn
            bsites(6,s+bmk*nn)=s3+2*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1
         
         elseif (bondmaker==3) then
            bmk=0d0
            bsites(1,s+bmk*nn)=s1+3*nn
            bsites(2,s+bmk*nn)=s1
            bsites(3,s+bmk*nn)=s1+1*nn
            bsites(4,s+bmk*nn)=s1+2*nn
            bsites(5,s+bmk*nn)=s2
            bsites(6,s+bmk*nn)=s4+1*nn
            bsites(7,s+bmk*nn)=s3+2*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=1d0
            bsites(1,s+bmk*nn)=s1
            bsites(2,s+bmk*nn)=s1+nn
            bsites(3,s+bmk*nn)=s1+3*nn
            bsites(4,s+bmk*nn)=s1+2*nn
            bsites(5,s+bmk*nn)=s8+nn
            bsites(6,s+bmk*nn)=s9+3*nn
            bsites(7,s+bmk*nn)=s7+2*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=2d0
            bsites(1,s+bmk*nn)=s1+nn
            bsites(2,s+bmk*nn)=s1
            bsites(3,s+bmk*nn)=s1+2*nn
            bsites(4,s+bmk*nn)=s1+3*nn
            bsites(5,s+bmk*nn)=s6
            bsites(6,s+bmk*nn)=s12+2*nn
            bsites(7,s+bmk*nn)=s11+3*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=3d0
            bsites(1,s+bmk*nn)=s1+2*nn
            bsites(2,s+bmk*nn)=s1
            bsites(3,s+bmk*nn)=s1+3*nn
            bsites(4,s+bmk*nn)=s1+1*nn
            bsites(5,s+bmk*nn)=s5
            bsites(6,s+bmk*nn)=s13+3*nn
            bsites(7,s+bmk*nn)=s10+1*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1
         
         elseif (bondmaker==2) then
            bmk=0d0
            bsites(1,s+bmk*nn)=s1
            bsites(2,s+bmk*nn)=s1+nn
            bsites(3,s+bmk*nn)=s1+2*nn
            bsites(4,s+bmk*nn)=s1+3*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=1d0
            bsites(1,s+bmk*nn)=s2
            bsites(2,s+bmk*nn)=s4+2*nn
            bsites(3,s+bmk*nn)=s3+nn
            bsites(4,s+bmk*nn)=s1+3*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1
                  
         elseif (bondmaker==1) then
            bmk=0d0
            bsites(1,s+bmk*nn)=s1
            bsites(2,s+bmk*nn)=s1+nn
            bsites(3,s+bmk*nn)=s1+2*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=1d0
            bsites(1,s+bmk*nn)=s1
            bsites(2,s+bmk*nn)=s1+nn
            bsites(3,s+bmk*nn)=s1+3*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=2d0
            bsites(1,s+bmk*nn)=s1
            bsites(2,s+bmk*nn)=s1+2*nn
            bsites(3,s+bmk*nn)=s1+3*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=3d0
            bsites(1,s+bmk*nn)=s1+nn
            bsites(2,s+bmk*nn)=s1+3*nn
            bsites(3,s+bmk*nn)=s1+2*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=4d0
            bsites(1,s+bmk*nn)=s2
            bsites(2,s+bmk*nn)=s3+nn
            bsites(3,s+bmk*nn)=s4+2*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=5d0
            bsites(1,s+bmk*nn)=s2
            bsites(2,s+bmk*nn)=s3+nn
            bsites(3,s+bmk*nn)=s1+3*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=6d0
            bsites(1,s+bmk*nn)=s2
            bsites(2,s+bmk*nn)=s4+2*nn
            bsites(3,s+bmk*nn)=s1+3*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=7d0
            bsites(1,s+bmk*nn)=s3+nn
            bsites(2,s+bmk*nn)=s1+3*nn
            bsites(3,s+bmk*nn)=s4+2*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1
                  
         elseif (bondmaker==0) then

            bmk=0d0
            bsites(1,s)=s1
            bsites(2,s)=s1+nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=1d0
            bsites(1,s+bmk*nn)=s1+nn
            bsites(2,s+bmk*nn)=s1+2*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=2d0
            bsites(1,s+bmk*nn)=s1+2*nn
            bsites(2,s+bmk*nn)=s1
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1
            
            bmk=3d0
            bsites(1,s+bmk*nn)=s1
            bsites(2,s+bmk*nn)=s1+3*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=4d0
            bsites(1,s+bmk*nn)=s1+nn
            bsites(2,s+bmk*nn)=s1+3*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=5d0
            bsites(1,s+bmk*nn)=s1+2*nn
            bsites(2,s+bmk*nn)=s1+3*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=6d0
            bsites(1,s+bmk*nn)=s3+nn
            bsites(2,s+bmk*nn)=s4+2*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=7d0
            bsites(1,s+bmk*nn)=s4+2*nn
            bsites(2,s+bmk*nn)=s2
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=8d0
            bsites(1,s+bmk*nn)=s2
            bsites(2,s+bmk*nn)=s3+nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1
            
            bmk=9d0
            bsites(1,s+bmk*nn)=s3+nn
            bsites(2,s+bmk*nn)=s1+3*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1
            
            bmk=10d0
            bsites(1,s+bmk*nn)=s4+2*nn
            bsites(2,s+bmk*nn)=s1+3*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1

            bmk=11d0
            bsites(1,s+bmk*nn)=s2
            bsites(2,s+bmk*nn)=s1+3*nn
            bc=bc+1
            sambon(bc)=s+bmk*nn
            bontab(s+bmk*nn)=bc
            pbAc=pbAc+1
         endif

!+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

         bmk=numbd+1
         bsites(1,s+bmk*nn)=s1+1*nn
         bsites(2,s+bmk*nn)=s2+0*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

         bmk=numbd+2
         bsites(1,s+bmk*nn)=s1+3*nn
         bsites(2,s+bmk*nn)=s5+0*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

         bmk=numbd+3
         bsites(1,s+bmk*nn)=s1+2*nn
         bsites(2,s+bmk*nn)=s6+0*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1
!=================================================================

         bmk=numbd+4
         bsites(1,s+bmk*nn)=s1+0*nn
         bsites(2,s+bmk*nn)=s10+1*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

         bmk=numbd+5
         bsites(1,s+bmk*nn)=s1+2*nn
         bsites(2,s+bmk*nn)=s4+1*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

         bmk=numbd+6
         bsites(1,s+bmk*nn)=s1+3*nn
         bsites(2,s+bmk*nn)=s8+1*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1
!=================================================================

         bmk=numbd+7
         bsites(1,s+bmk*nn)=s1+0*nn
         bsites(2,s+bmk*nn)=s3+2*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

         bmk=numbd+8
         bsites(1,s+bmk*nn)=s1+3*nn
         bsites(2,s+bmk*nn)=s12+2*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

         bmk=numbd+9
         bsites(1,s+bmk*nn)=s1+1*nn
         bsites(2,s+bmk*nn)=s7+2*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1
!=================================================================

         bmk=numbd+10
         bsites(1,s+bmk*nn)=s1+0*nn
         bsites(2,s+bmk*nn)=s11+3*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

         bmk=numbd+11
         bsites(1,s+bmk*nn)=s1+1*nn
         bsites(2,s+bmk*nn)=s13+3*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

         bmk=numbd+12
         bsites(1,s+bmk*nn)=s1+2*nn
         bsites(2,s+bmk*nn)=s9+3*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

!=================================================================

         bmk=numbd+13
         bsites(1,s+bmk*nn)=s1+3*nn
         bsites(2,s+bmk*nn)=s2+1*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

         bmk=numbd+14
         bsites(1,s+bmk*nn)=s3+2*nn
         bsites(2,s+bmk*nn)=s1+1*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

         bmk=numbd+15
         bsites(1,s+bmk*nn)=s2+0*nn
         bsites(2,s+bmk*nn)=s3+1*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1
!=================================================================

         bmk=numbd+16
         bsites(1,s+bmk*nn)=s1+3*nn
         bsites(2,s+bmk*nn)=s4+2*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

         bmk=numbd+17
         bsites(1,s+bmk*nn)=s2+0*nn
         bsites(2,s+bmk*nn)=s1+2*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

         bmk=numbd+18
         bsites(1,s+bmk*nn)=s4+1*nn
         bsites(2,s+bmk*nn)=s2+2*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1
!=================================================================

         bmk=numbd+19
         bsites(1,s+bmk*nn)=s3+2*nn
         bsites(2,s+bmk*nn)=s4+0*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

         bmk=numbd+20
         bsites(1,s+bmk*nn)=s4+1*nn
         bsites(2,s+bmk*nn)=s1+0*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

         bmk=numbd+21
         bsites(1,s+bmk*nn)=s1+3*nn
         bsites(2,s+bmk*nn)=s3+0*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1
!=================================================================

         bmk=numbd+22
         bsites(1,s+bmk*nn)=s3+2*nn
         bsites(2,s+bmk*nn)=s2+3*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

         bmk=numbd+23
         bsites(1,s+bmk*nn)=s2+0*nn
         bsites(2,s+bmk*nn)=s4+3*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

         bmk=numbd+24
         bsites(1,s+bmk*nn)=s4+1*nn
         bsites(2,s+bmk*nn)=s3+3*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbBs=pbBs+1

!=================================================================
         bmk=numbd+25
         bsites(1,s+bmk*nn)=s1+0*nn
         bsites(2,s+bmk*nn)=s2+0*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+26
         bsites(1,s+bmk*nn)=s1+1*nn
         bsites(2,s+bmk*nn)=s2+1*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+27
         bsites(1,s+bmk*nn)=s1+0*nn
         bsites(2,s+bmk*nn)=s5+0*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+28
         bsites(1,s+bmk*nn)=s1+3*nn
         bsites(2,s+bmk*nn)=s5+3*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+29
         bsites(1,s+bmk*nn)=s1+0*nn
         bsites(2,s+bmk*nn)=s6+0*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+30
         bsites(1,s+bmk*nn)=s1+2*nn
         bsites(2,s+bmk*nn)=s6+2*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

!========================================================
         bmk=numbd+31
         bsites(1,s+bmk*nn)=s1+1*nn
         bsites(2,s+bmk*nn)=s8+1*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+32
         bsites(1,s+bmk*nn)=s1+3*nn
         bsites(2,s+bmk*nn)=s8+3*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+33
         bsites(1,s+bmk*nn)=s1+1*nn
         bsites(2,s+bmk*nn)=s4+1*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+34
         bsites(1,s+bmk*nn)=s1+2*nn
         bsites(2,s+bmk*nn)=s4+2*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+35
         bsites(1,s+bmk*nn)=s1+1*nn
         bsites(2,s+bmk*nn)=s10+1*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+36
         bsites(1,s+bmk*nn)=s1+0*nn
         bsites(2,s+bmk*nn)=s10+0*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

!========================================================
         bmk=numbd+37
         bsites(1,s+bmk*nn)=s1+2*nn
         bsites(2,s+bmk*nn)=s3+2*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+38
         bsites(1,s+bmk*nn)=s1+0*nn
         bsites(2,s+bmk*nn)=s3+0*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+39
         bsites(1,s+bmk*nn)=s1+2*nn
         bsites(2,s+bmk*nn)=s7+2*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+40
         bsites(1,s+bmk*nn)=s1+1*nn
         bsites(2,s+bmk*nn)=s7+1*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+41
         bsites(1,s+bmk*nn)=s1+2*nn
         bsites(2,s+bmk*nn)=s12+2*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+42
         bsites(1,s+bmk*nn)=s1+3*nn
         bsites(2,s+bmk*nn)=s12+3*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

!========================================================
         bmk=numbd+43
         bsites(1,s+bmk*nn)=s1+3*nn
         bsites(2,s+bmk*nn)=s9+3*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+44
         bsites(1,s+bmk*nn)=s1+2*nn
         bsites(2,s+bmk*nn)=s9+2*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+45
         bsites(1,s+bmk*nn)=s1+3*nn
         bsites(2,s+bmk*nn)=s11+3*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+46
         bsites(1,s+bmk*nn)=s1+0*nn
         bsites(2,s+bmk*nn)=s11+0*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+47
         bsites(1,s+bmk*nn)=s1+3*nn
         bsites(2,s+bmk*nn)=s13+3*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+48
         bsites(1,s+bmk*nn)=s1+1*nn
         bsites(2,s+bmk*nn)=s13+1*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

!========================================================
         bmk=numbd+49
         bsites(1,s+bmk*nn)=s2+0*nn
         bsites(2,s+bmk*nn)=s18+0*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+50
         bsites(1,s+bmk*nn)=s3+2*nn
         bsites(2,s+bmk*nn)=s12+2*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+51
         bsites(1,s+bmk*nn)=s1+3*nn
         bsites(2,s+bmk*nn)=s6+3*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

!========================================================
         bmk=numbd+52
         bsites(1,s+bmk*nn)=s4+1*nn
         bsites(2,s+bmk*nn)=s21+1*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+53
         bsites(1,s+bmk*nn)=s1+3*nn
         bsites(2,s+bmk*nn)=s10+3*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+54
         bsites(1,s+bmk*nn)=s2+0*nn
         bsites(2,s+bmk*nn)=s5+0*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1
!========================================================
         bmk=numbd+55
         bsites(1,s+bmk*nn)=s3+2*nn
         bsites(2,s+bmk*nn)=s14+2*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+56
         bsites(1,s+bmk*nn)=s4+1*nn
         bsites(2,s+bmk*nn)=s8+1*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+57
         bsites(1,s+bmk*nn)=s1+3*nn
         bsites(2,s+bmk*nn)=s7+3*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1
!========================================================
         bmk=numbd+58
         bsites(1,s+bmk*nn)=s4+1*nn
         bsites(2,s+bmk*nn)=s24+1*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+59
         bsites(1,s+bmk*nn)=s3+2*nn
         bsites(2,s+bmk*nn)=s25+2*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         bmk=numbd+60
         bsites(1,s+bmk*nn)=s2+0*nn
         bsites(2,s+bmk*nn)=s23+0*nn
         bc=bc+1
         sambon(bc)=s+bmk*nn
         bontab(s+bmk*nn)=bc
         pbCn=pbCn+1

         enddo
      enddo
   enddo
   sitnum=nn
   nn=4*nn
   nbs=bc
   print*,nbs,nb,nn,sitnum,pbAc,pbBs,pbCn
   !pause

   if (bondmaker==4) then
      legn(1,1)=6
      legn(1,2)=2**6-1
      legn(2,1)=2
      legn(2,2)=2**2-1
      legn(3,1)=1
      legn(3,2)=2**1-1
      legn(4,1)=2
      legn(4,2)=2**2-1
   elseif (bondmaker==3) then
      legn(1,1)=7
      legn(1,2)=2**7-1
      legn(2,1)=2
      legn(2,2)=2**2-1
      legn(3,1)=1
      legn(3,2)=2**1-1
      legn(4,1)=2
      legn(4,2)=2**2-1
   elseif (bondmaker==2) then
      legn(1,1)=4
      legn(1,2)=2**4-1
      legn(2,1)=2
      legn(2,2)=2**2-1
      legn(3,1)=1
      legn(3,2)=2**1-1
      legn(4,1)=2
      legn(4,2)=2**2-1
   elseif (bondmaker==1) then
      legn(1,1)=3
      legn(1,2)=2**3-1
      legn(2,1)=2
      legn(2,2)=2**2-1
      legn(3,1)=1
      legn(3,2)=2**1-1
      legn(4,1)=2
      legn(4,2)=2**2-1
   elseif (bondmaker==0) then
      legn(1,1)=2
      legn(1,2)=2**2-1
      legn(2,1)=2
      legn(2,2)=2**2-1
      legn(3,1)=1
      legn(3,2)=2**1-1
      legn(4,1)=2
      legn(4,2)=2**2-1
   endif

   !s2=0d0
   !s=1+x1+y1*lx+z1*lx*ly
   !do s1=1,nn/3
      !print*,int((s1-1)/(lx*ly)),s2
      !if (int((s1-1)/(lx*ly))==s2) then
         !print*,s1,s2
         !print*,bsites(9:mxl,s1)
         !print*,bsites(5:8,s1)
         !print*,bsites(1:4,s1)
         !print*,"//////////////////////"
         !print*,bsites(9:mxl,s1+nn/3)
         !print*,bsites(5:8,s1+nn/3)
         !print*,bsites(1:4,s1+nn/3)
         !print*,"++++++++++++++++++++++++"
         !print*,bsites(9:mxl,s1+2*nn/3)
         !print*,bsites(5:8,s1+2*nn/3)
         !print*,bsites(1:4,s1+2*nn/3)
         !print*,"++++++++++++++++++++++++"
         !print*,bsites(9:mxl,s1+3*nn/3)
         !print*,bsites(5:8,s1+3*nn/3)
         !print*,bsites(1:4,s1+3*nn/3)
         !print*,"//////////////////////"
      !endif
      !if (mod((s1-1),(lx*ly))==lx*ly-1) s2=s2+1
   !enddo   

   verdeg=2**(mxl)-1
   allocate(spingrploc(nb,0:3))
   spingrploc(nb,:)=0d0
   allocate(spacevisit(nb))
   spacevisit(:)=0d0
   allocate(loopgrploc(nb))
   loopgrploc(nb)=0d0
   allocate(bondchain(nb,0:2))

end subroutine makelattice
!==================================================!

!==================================================!

subroutine diagonalupdate(prid)
   use configuration
   use measurementdata
   implicit none

   integer :: i,j,k,key,s,prid,stmp,typ,b,op,nz,nv,a
   integer :: bond
   integer :: cs
   integer :: ss
   real(8) :: p1,wght
   real(8), external :: ran

   cs=1d0
   ss=1d0
   !if (jp/=0) then
      !nz=nz+nn
   !endif
   !if (hz/=0) then
      !nz=nz+nn
   !endifdiagonalup
   nz=prob

   do i=0,mm-1
      op=opstring(i)
      bond=0d0
      wght=0d0
      if ( op==0 ) then

         nv=int(nz*ran())+1

         if (nv<=pbAc .and. sambon(bontab(nv))<=nbs) then
            bond=sambon(bontab(nv))
            typ=1
            cs=0d0
            do j=1,mxl
               if (bsites(j,bond)==-1) exit
               cs=cs+2**(j-1)*int((spin(bsites(j,bond))+1)*0.5d0)
            enddo
            wght=weightable(cs,cs,typ)
            !print*,wght,cs
	         if (wght/=0d0) then
	            if ((mm-nh)*ran()<=wght*prob*beta) then
	               opstring(i)=8*bond
	               nh=nh+1
	               nh1=nh1+1
	               !if (basis==1) nhpm(bond,int((cs+1)/2))=nhpm(bond,int((cs+1)/2))+1
	            endif
	         endif
         elseif (nv>pbAc .and. nv<=pbAc+pbBs .and. sambon(bontab(nv))<=nbs .and. nnn==1d0) then
            bond=sambon(bontab(nv))
            typ=2
            cs=0d0
            do j=1,mxl
               if (bsites(j,bond)==-1) exit
               cs=cs+2**(j-1)*int((spin(bsites(j,bond))+1)*0.5d0)
            enddo
            wght=weightable(cs,cs,typ)
	         if (wght/=0d0) then
               if ((mm-nh)*ran()<=wght*prob*beta) then
                  opstring(i)=8*bond+2
                  nh=nh+1
                  nh2=nh2+1
               endif
            endif
            !print*,"3",bond
         elseif (nv>pbAc+pbBs .and. nv<=pbAc+pbBs+pbCn .and. sambon(bontab(nv))<=nbs .and. nnn==1d0) then
            bond=sambon(bontab(nv))
            typ=4
            cs=0d0
            do j=1,mxl
               if (bsites(j,bond)==-1) exit
               cs=cs+2**(j-1)*int((spin(bsites(j,bond))+1)*0.5d0)
            enddo
            wght=weightable(cs,cs,typ)
	         if (wght/=0d0) then
               if ((mm-nh)*ran()<=wght*prob*beta) then
                  opstring(i)=8*bond+6
                  nh=nh+1
                  nh4=nh4+1
               endif
            endif
         elseif (nv<=nbs+pbjp .and. nv>nbs .and. jp/=0) then
         else
         endif

      elseif(mod(op,2)==0) then
         typ=int(mod(op,8)/2)+1
         b=int(op/8)
         cs=0d0
         if (typ==1 .or. typ==2 .or. typ==4) then
            do j=1,mxl
               if (bsites(j,b)==-1) exit
               cs=cs+2**(j-1)*int((spin(bsites(j,b))+1)*0.5d0)
            enddo
         elseif (typ==3) then
            cs=int((spin(b)+1)*0.5d0)
         endif
         wght=weightable(cs,cs,typ)

         if (prob*beta*wght*ran()<=(mm-nh+1)) then
            opstring(i)=0d0
            nh=nh-1
            if (typ==1) then
               nh1=nh1-1
               !if (basis==1) nhpm(b,int((cs+1)/2))=nhpm(b,int((cs+1)/2))-1
            elseif (typ==2) then
               nh2=nh2-1
               !if (basis==0) nhpm(b,int((cs+1)/2))=nhpm(b,int((cs+1)/2))-1
            elseif (typ==3) then
               nh3=nh3-1
            elseif (typ==4) then
               nh4=nh4-1
            endif
         endif
      else
         typ=int(mod(op,8)/2)+1
         b=int(op/8)
         if (typ==1 .or. typ==2 .or. typ==4) then
            do j=1,mxl
               stmp=bsites(j,b)
               if (stmp==-1) then
                  exit
               elseif (opstfp(i,j-1)==-1) then
                  spin(stmp)=-spin(stmp)
               endif
            enddo
         else
            spin(b)=-spin(b)
         endif
      endif
   enddo

end subroutine diagonalupdate
!==================================================!

!==================================================!

subroutine linkvertices(s)
   use configuration
   implicit none

   integer :: b,op,s1,s2,v0,dv,v1,v2,i,j,k,l,typ,sig,a,s,tmp
   integer :: sitin,spother,sitcr,m,spinpro
   integer :: cur0,cur1,s0
   real(8), external :: ran

   frstspinop(:)=-1
   lastspinop(:)=-1
   vertexspin(:,:)=-2
   spingrp(:,:,:)=0d0
   spingrploc(:,0)=0d0
   spingrploc(:,1:3)=1d0
   tmp=0d0
   legtot=0d0
   offoporder(0)=0
   !do
   !   bb0=int(ran()*sitnum)+1
   !   bb1=int(ran()*sitnum)+1
   !   bb2=int(ran()*sitnum)+1
   !   if (bb0/=bb1 .and. bb1/=bb2 .and. bb2/=bb0) exit
   !enddo
   if (lx>=4) then
      if (s==2) then
         updtyp=1
         slpb=slprob
      else
         updtyp=1
         slpb=2d0
      endif
   else
      updtyp=1
      slpb=slprob
   endif
   !slpb=1d0

   do v0=0, dxl*mm-1, dxl
      op=opstring(int(v0/(dxl)))
      if ( op==0 ) then
         vertexlist(v0:v0+dxl-1,:)=0
         vertexlist_map(v0:v0+dxl-1)=-1
      else
         b=op/8
         typ=int(mod(op,8)/2)+1

         if (typ==1 .or. typ==2 .or. typ==4) then
            do i=1,mxl
               s1=bsites(i,b)
               dv=i-1
               if (s1==-1) then
                  vertexlist(v0+dv,:)=0
                  vertexlist(v0+dv+mxl,:)=0
                  vertexlist_map(v0+dv)=-1
                  vertexlist_map(v0+dv+mxl)=-1
                  cycle
               endif
               v1=lastspinop(s1)
               if ( v1/=-1 ) then
                  vertexlist(v1,:)=0
                  vertexlist(v0+dv,:)=0
                  vertexlist_map(v1)=v0+dv
                  vertexlist_map(v0+dv)=v1
                  legtot=legtot+2
               else
                  frstspinop(s1)=v0+dv
               endif
               lastspinop(s1)=v0+dv+mxl
            enddo
         else
            s1=b
            dv=0
            v1=lastspinop(s1)
            if ( v1/=-1 ) then
               vertexlist(v1,:)=0
               vertexlist(v0+dv,:)=0
               vertexlist_map(v1)=v0+dv
               vertexlist_map(v0+dv)=v1
               legtot=legtot+2
            else
               frstspinop(s1)=v0+dv
            endif
            lastspinop(s1)=v0+dv+mxl

            do i=2,mxl
               s1=bsites(i,b)
               dv=i-1
               vertexlist(v0+dv,:)=0
               vertexlist(v0+dv+mxl,:)=0
               vertexlist_map(v0+dv)=-1
               vertexlist_map(v0+dv+mxl)=-1
            enddo
         endif
       endif
    enddo

   do s1=1,nn
      v1=frstspinop(s1)
      if ( v1/=-1 ) then
         v2=lastspinop(s1)
         vertexlist(v2,:)=0
         vertexlist(v1,:)=0
         vertexlist_map(v2)=v1
         vertexlist_map(v1)=v2
         legtot=legtot+2
       end if
    enddo

   call random_tau()
   !call random_bond()
   !print*,"link 0",nh,size(oporder, dim=1)

   if ( size(oporder, dim=1)/=nh ) then
      deallocate(oporder)
      allocate(oporder(nh))
      deallocate(offoporder)
      allocate(offoporder(0:nh))
      deallocate(digoporder)
      allocate(digoporder(0:nh))
      deallocate(opertyp)
      allocate(opertyp(nh))
      deallocate(dealtyp)
      allocate(dealtyp(nh))
      deallocate(opvlog)
      allocate(opvlog(0:nh,0:3))
      if (nh>=nn0) then
         deallocate(clusterflog)
         allocate(clusterflog(0:nh,0:3))
      endif
   endif
   clusterflog(:,:)=0
   oporder(:)=0
   opertyp(:)=0
   dealtyp(:)=0
   opvlog(:,2:3)=0
   offoporder(0)=0
   digoporder(0)=0
   ofcc=0d0
   !if ( size(offoporder, dim=1)/=! ) then
   !   deallocate(offoporder)
   !   allocate(offoporder(nh1))
   !   deallocate(digoporder)
   !   allocate(digoporder(nh1))
   !endif
   !offoporder(:)=0
   !print*,"link 1",nh,size(oporder, dim=1)

   do
      j=nh
      a=nh1
      l=0
      tmp=0d0
      do i=0,mm-1
         op=opstring(i)
         !print*,"link 0.0",i,op
         if (op==0) then
            tauscale(i)=j
            cycle
         endif
         b=op/8
         typ=int(mod(op,8)/2)+1
         if (typ==3) then
            !print*,"error1"
            !pause
         endif
         sig=mod(op,2)
         j=mod(j,nh)+1
         oporder(j)=i
         !print*,"link 0.1",i,j,nh,mm 

         if (typ<=2 .or. typ==4) then
            cur0=0
            cur1=0
            do k=1,mxl
               s1=bsites(k,b)
               if (s1==-1) exit
               if (sig==1d0) then
                  spin(s1)=opstfp(i,k-1)*spin(s1)
               endif
               !print*,k-1,i,s1,size(vertexspin, dim=1)
               vertexspin(k-1,i)=spin(s1)
               
               s1=int((vertexspin(k-1,i)+1d0)*0.5d0)
               s0=int((vertexspin(k-1,i)*opstfp(i,k-1)+1d0)*0.5d0)
               cur0=cur0+s0*2**k
               cur1=cur1+s1*2**k

            enddo

            ! if (cur0==cur1) then
            !    k=vextag(cur0,cur1,0,0,typ)
            !    do k=1,3
            !       m=vextag(cur0,cur1,3,k,typ)
            !       if (m==4) then
            !          spingrploc(b,k)=0
            !       endif
            !    enddo
            ! endif

         else
            s1=b
            !if (b>nn) print*,b
            if (sig==1d0) then
               spin(s1)=-spin(s1)
            endif
            vertexspin(0,i)=spin(s1)
         endif 
         tauscale(i)=j

         l=l+1
         opertyp(j)=1
         if (typ==1) then
            tmp=tmp+1
         elseif (typ==2) then
            !tmp=tmp+1
         elseif (typ==3) then
            tmp=tmp+1
         elseif (typ==4) then
            !tmp=tmp+1
         else
         endif
         
         if (clustersignal==1) call initspingrp(i,j,typ)
         !print*,"initspingrp",spingrp(0,i,0)

      enddo
      if (l==0d0 .or. slpb==0d0) then
         !print*,"l,slpb",l,slpb
         exit
      endif  
      if (l/=0d0 .and. slpb/=0d0 .and. tmp/=0d0) then
         !print*,"l,slpb,tmp",l,slpb,tmp
         exit
      endif 
   enddo
   

   !do i=0, dxl*mm-1
      !if (vertexlist(i,0)==0 .and. vertexlist_map(i)==-1) then
         !if (mod(i,dxl)>=mxl) then
            !if (vertexspin(mod(i,dxl)-mxl,i/(dxl))/=-1) print*,"check1"
         !endif
      !elseif (vertexlist_map(i)>=0) then
         !if (mod(i,dxl)>=mxl) then
            !if (vertexspin(mod(i,dxl)-mxl,i/(dxl))/=-1 .and. vertexspin(mod(i,dxl)-mxl,i/(dxl))/=1) print*,"check2"
         !endif
      !else
         !print*,"check...."
      !endif
   !enddo
   !pause
   !print*,"link========================================"
   !call spinchecker()
   !call bondchecker()
   !call checkspingrp()

 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


end subroutine linkvertices
!==================================================!

!==================================================!
subroutine checkspingrp()

   use configuration
   implicit none

   integer :: b,op,s1,s2,v0,dv,v1,v2,i,j,k,l,typ,sig,a,s,tmp
   integer :: sitin,spother,sitcr,m,spinpro,m2,lpnum,totalspin
   integer :: l0,l1,l2,l3,ph,g_indx,cur0,cur1,cur2,cur3
   integer :: s0
   real(8), external :: ran

   print*,"checkspingrp start"
   do i=0,mm-1
      op=opstring(i)
      b=int(op/8)
      sig=mod(op,2)

      if (op/=0d0) then
         cur0=0
         cur1=0
         do k=0,mxl-1
            s1=int((vertexspin(k,i)+1d0)*0.5d0)
            s0=int((vertexspin(k,i)*opstfp(i,k)+1d0)*0.5d0)

            cur0=cur0+s0*2**k
            cur1=cur1+s1*2**k

            if (spingrp(spingrp(k,i,0),i,0)/=k) then
               print*,"spinerror_2",i
               print*,"spinerror_2",k,spingrp(k,i,0),spingrp(spingrp(k,i,0),i,0)
               print*,"spinerror_2",spingrp(:,i,0)
               pause
            endif
         enddo
         


      endif
   enddo
   print*,"checkspingrp done"


end subroutine checkspingrp
!==================================================!

!==================================================!

subroutine spinchecker()

   use configuration
   implicit none

   integer :: b,op,s0,s1,s2,v0,dv,v1,v2,i,j,k,l,typ,sig,ctmp,stmp,cur0,cur1
   integer :: bspn
   integer, allocatable :: sptp(:)
   integer, allocatable :: stt(:,:)
   allocate(sptp(nn))
   allocate(stt(0:mxl-1,0:1))

   ctmp=0d0

   sptp(:)=spin(:)
   stt(:,:)=0d0

   j=nh
   do i=0,mm-1
      op=opstring(i)
      if (op==0) then
         cycle
      endif
      b=int(op/8)
      typ=int(mod(op,8)/2)+1
      sig=mod(op,2)
      j=mod(j,nh)+1

      do k=1,mxl
         s1=bsites(k,b)
         bspn=int((k-1)/2)
         if (s1==-1) exit
         stt(k-1,0)=sptp(s1)
         if (sig==1d0) then
            sptp(s1)=opstfp(i,k-1)*sptp(s1) 
            if (opstfp(i,k-1)==0d0) then
               print*,"link",opstfp(i,k-1)
               pause
            endif
         endif
         stt(k-1,1)=sptp(s1)
         !print*,k-1,i,s1,size(vertexspin, dim=1)
         if (vertexspin(k-1,i)/=sptp(s1)) then 
            print*,"spinerror_1","mm",i
            print*,"spinerror_1",vertexspin(k-1,i),sptp(s1),k-1,i,tauscale(i),s1
            print*,"spinerror_1",spingrp(:,i,0)
            print*,"spinerror_1",vertexspin(0,i),vertexspin(1,i),dealtyp(tauscale(i)),mod(op,2)
            print*,"spinerror_1",vertexlist(i*dxl:i*dxl+dxl-1,1)
            print*,"spinerror_1",clusterflog(vertexlist(i*dxl,1),0)
            print*,"spinerror_1",clusterflog(vertexlist(i*dxl+1,1),0)
            print*,"spinerror_1",clusterflog(vertexlist(i*dxl+2,1),0)
            print*,"spinerror_1",clusterflog(vertexlist(i*dxl+3,1),0)
            pause
         endif
       enddo

      cur0=0d0
      cur1=0d0
      do l=0,mxl-1
         s1=int((stt(l,1)+1d0)*0.5d0)
         s0=int((stt(l,0)+1d0)*0.5d0)

         cur0=cur0+s0*2**l
         cur1=cur1+s1*2**l
      enddo
      if (weightable(cur0,cur1,typ)==0d0) then
         print*,"weight error",weightable(cur0,cur1,typ),cur0,cur1,typ
         print*,spingrp(:,i,0)
         print*,spingrp(:,i,1)
         print*,spingrp(:,i,2)
         print*,vertexspin(:,i)
         print*,opstfp(i,:)
         print*,"++++++++++++++++++++++++++++++++"
         print*,stt(:,1)
         print*,stt(:,0)
         pause
      endif
   enddo

   do i=1,nn
      if (sptp(i)/=spin(i)) then
        print*,"erro0",i,lastspinop(i),vertexlist_map(lastspinop(i))
        print*,"erro0",i,sptp(i),spin(i)
        pause
      endif
   enddo

end subroutine spinchecker


!==================================================!

!==================================================!

subroutine loopupdate(signal,rank)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,k,signal,rank,i1,i2,i3
   integer :: site_o,typ
   real(8), external :: ran
   real(8), external :: hf

   Spm_measure_signal=signal
   update_counter=0
   loop_counter=0
   cluster_counter=0
   vertexlist(:,2)=0d0
   if ( Spm_measure_signal==1 ) call initRecorder()

   if (nh==0d0) return
   loop_eff_count=0d0
   loop_tot_count=0d0

   do
      do
         v0=int(ran()*mm)*dxl+int(dxl*ran())
         if ( vertexlist_map(v0)>=0 ) exit
      enddo

      !open(unit=10,file=loopname)
      !write(10,*)v0
      !close(10)
      
      v1=v0
      loopgrploc(:)=0d0
      counter=1
      cluster_counter=cluster_counter+1
      if ( Spm_measure_signal==1 ) then
         !call OperatorType(v0,0)
         call initRecorder()
      endif

      !call bondchecker()
      
      !print*,"loop start","rank",rank,loop_counter,update_counter
      !if (update_counter<0 .or. update_counter>cluster_counter) pause
      do
         if ( v1==v0 .and. counter/=1 ) then
            !print*,"==============================loop1================================"
            loop_counter=loop_counter+1
            !print*,loop_counter,rank
            exit
         endif

         i=v1/dxl
         op=opstring(i)
         typ=int(mod(op,8)/2)+1
         b=int(op/8)
         !print*, "loop",v0,v1,counter
         if (loopgrploc(b)==0d0) then
            looppm=int(ran()*3)+1
            loopgrploc(b)=looppm
         else
            looppm=loopgrploc(b)
         endif
         looppm=0d0
         !print*,"loopgrploc",loopgrploc(b),looppm
         !print*,typ
         !print*,b,v1,mod(op,2),vertexspin(:,i),mod(v1,dxl),vertexlist_map(v1)
         !print*,b,v1,mod(op,2),"-----------------"

         if (typ==1) then
            !print*,"loop1","loopdeter"
            call loopdeter(i,0,rank,1)
            !print*,"loop1","loopbuilding"
            call loopbuilding(i,0,rank,1)
            !print*,"loop1","loopend"
         elseif (typ==2 .or. typ==4) then
         elseif (typ==3) then
         else
            print*,"error1"
            pause
         endif

         counter=counter+1
         cluster_counter=cluster_counter+1
         !if (cluster_counter>100*nh) then
         !   print*, "cluster_counter>100*nh"
         !   pause
         !else
         !   print*,"+++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
         !endif

         if ( v2==v0 ) then
            !print*,"==============================loop2================================"
            loop_counter=loop_counter+1
            !if (Spm_measure_signal==1) call SpinFlippingRecorder(int(v2/dxl))
            !print*,loop_counter,rank
            exit
         endif
      end do
      !print*,"loop_counter",loop_counter,update_counter
      !print*,"loop end","rank",rank,loop_counter,update_counter
      !if (update_counter<0 .or. update_counter>cluster_counter) pause

      if (Spm_measure_signal==1) then
         !print*,"loop_counter",loop_counter,update_counter
         call CollectRecorder()
      endif

      if ( Spm_measure_signal==0 ) then
         if ( update_counter>=nn ) then
         !if ( loop_counter>=10 ) then
            exit
         endif
      elseif( Spm_measure_signal==1 ) then
         if ( loop_counter>=nn ) then
         !if ( loop_counter>=10 ) then
         !if ( update_counter>=2*nn ) then
            exit
         endif
      endif
   enddo

   !open(unit=10,file=loopname,position='append')
   !write(10,*)loop_eff_count,dble(loop_eff_count)/dble(nh*dxl),loop_tot_count,&
   !&dble(loop_tot_count)/dble(nh*dxl),dble(loop_eff_count)/dble(loop_tot_count)
   !close(10)
   loop_eff_count=0d0
   loop_tot_count=0d0

   do i = 1, nn
      if ( frstspinop(i)/=-1 ) then
         if (mod(vertexlist(frstspinop(i),2),2)==1) then
            spin(i)=-spin(i)
         end if
      elseif ( ran()*(2)<1 ) then
            spin(i)=-spin(i)
      end if
   end do

   !print*,"loop========================================"
   !call spinchecker()
   !call bondchecker()

end subroutine loopupdate
!==================================================!


!==================================================!

subroutine cerberus(signal,rank)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,k,signal,rank,i1,i2,i3,idx_mm
   integer :: site_o,typ,typx,bp,opp,repeat
   integer, allocatable :: hex_counter(:)
   real(8), external :: ran
   real(8), external :: hf

   Spm_measure_signal=signal
   update_counter=0
   loop_counter=0
   cluster_counter=0
   vertexlist(:,2)=0d0
   allocate(hex_counter(0:5))

   if (nh==0d0) return
   loop_eff_count=0d0
   loop_tot_count=0d0

   !signal=0 trival 3 loop
   !signal=1 start at hexagon
   !signal=2 add new pair S+- update

   do
      vc(:,:)=0d0
      if (signal/=1 .or. lpdim/=3) then
         do i=1,lpdim
            call cerberus_insertSpSm(i,i)
         enddo
      else
         hex_counter(:)=0
         do
            i1=int(ran()*sitnum)+1
            i2=int(ran()*4)
            j=0
            if (sum(frstspinop(hexagon(i1,i2,:)))/=-6) then
               i3=int(ran()*2)
               do k=0,2
                  !i=int(ran()*6)
                  i=int(2d0*k+i3)
                  if (hex_counter(i)==0) then
                     hex_counter(i)=1
                     site_o=hexagon(i1,i2,i)
                     if (frstspinop(site_o)/=-1) then
                        j=j+1
                        x0(j)=frstspinop(site_o)
                        if (ran()*(2)<1) then
                           x0(j)=vertexlist_map(x0(j))
                        endif
                        x1(j)=x0(j)
                     else
                        cycle
                     endif
                  endif
                  !if (j==3) exit
               enddo
               if (j==3) then
                  vc(:,0)=1d0
                  vc(:,1)=1d0
                  exit
               endif
            endif
         enddo
      endif
      !print*,"cerberus",vertexlist_map(x0(:))

      !open(unit=10,file=loopname)
      !write(10,*)v0
      !close(10)

      loopgrploc(:)=0d0
      counter=1
      cerberus_flag=0
      cluster_counter=cluster_counter+1

      !call bondchecker()
      
      !print*,"loop start","rank",rank,loop_counter,update_counter
      !if (update_counter<0 .or. update_counter>cluster_counter) pause
      do
         call cerberus_prepare(1,signal)
         !if ( (v1==v0 .and. x1==x0) .or. (v1==x0 .and. x1==v0) ) then
         if ( cerberus_flag==1 .and. counter/=1 ) then
            !print*,"==============================loop1================================"
            loop_counter=loop_counter+1
            !print*,loop_counter,cluster_counter,rank
            exit
         endif
         
         !print*,"cerberus",ix(:,0)

         do j=1,lpdim
            if (ix(j,0)==-1d0) then
               cycle
            else
               opp=opstring(ix(j,0))
               bp=int(opp/8)
               typ=int(mod(opp,8)/2)+1
               if (typ==1) then
                  !if (ix(j,1)==3) print*,"cerberus",ix(j,1)
                  !if (ix(j,1)==3) call timemeasure(0)
                  call mulloopdeter(ix(j,0),ix(j,1),j,rank)
                  !if (ix(j,1)==3) call timemeasure(0)
                  call mulloopbuilding(ix(j,0),ix(j,1),j,rank)
                  !if (ix(j,1)==3) call timemeasure(0)
                  !if (ix(j,1)==3) print*,"+++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
               elseif (typ==2 .or. typ==4) then
               elseif (typ==3) then
               else
                  pause
               endif
            endif
         enddo

         counter=counter+1
         cluster_counter=cluster_counter+1
         !print*,"cerberus",counter,cluster_counter,loop_counter
         !if (cluster_counter>100*nh) then
         !   print*, "cluster_counter>100*nh"
         !   pause
         !else
         !   print*,"+++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
         !endif

         call cerberus_prepare(2,signal)
         if ( cerberus_flag==1 .and. counter/=1 ) then
            !print*,"==============================loop2================================"
            loop_counter=loop_counter+1
            !print*,loop_counter,cluster_counter,rank
            exit
         endif
      end do
      !print*,"loop_counter",loop_counter,update_counter
      !print*,"loop end","rank",rank,loop_counter,update_counter
      !if (update_counter<0 .or. update_counter>cluster_counter) pause

      !if ( update_counter>=nn ) then
      if ( loop_counter>=10 ) then
         exit
      endif
   enddo

   ! open(unit=10,file=loopname,position='append')
   ! write(10,*)loop_eff_count,dble(loop_eff_count)/dble(nh*dxl),loop_tot_count,&
   ! &dble(loop_tot_count)/dble(nh*dxl),dble(loop_eff_count)/dble(loop_tot_count)
   ! close(10)
   loop_eff_count=0d0
   loop_tot_count=0d0

   do i = 1, nn
      if ( frstspinop(i)/=-1 ) then
         if (mod(vertexlist(frstspinop(i),2),2)==1) then
            spin(i)=-spin(i)
         end if
      elseif ( ran()*(2)<1 ) then
            spin(i)=-spin(i)
      end if
   end do

   !print*,"loop========================================"
   !call spinchecker()
   !call bondchecker()

end subroutine cerberus
!==================================================!

subroutine bondchecker()
!-----------------------------------------------------------!
!-----------------------------------------------------------!
 use configuration
 use vertexupdate
 implicit none
 integer :: i,j
 
 !print*, "bondchecker"
 do i=0,mm-1
   if (opstring(i)==0) cycle
   if (sum(opstfp(i,:))==3) then
      if (sum(vertexspin(:,i))==3 .or. sum(vertexspin(:,i))==-3) then
         !print*,"check"
      elseif (sum(vertexspin(:,i))==1 .or. sum(vertexspin(:,i))==-1) then
         !print*,"check"
      else
         print*,"sum(vertexspin(:,i)) error t2",sum(vertexspin(:,i)),opstring(i)
         pause
      endif
   elseif (sum(opstfp(i,:))==-1) then
      if (sum(vertexspin(:,i))==1 .or. sum(vertexspin(:,i))==-1) then
         !print*,"check"
      else
         print*,"sum(vertexspin(:,i)) error t3",sum(vertexspin(:,i)),opstring(i)
         print*,vertexspin(:,i)
         print*,opstfp(i,:)
         pause
      endif
   else
      print*,"sum(opstfp(i,:)) error t2",sum(opstfp(i,:)),opstring(i)
      pause
   endif
 enddo

 end subroutine bondchecker
!==================================================!
!==================================================!

subroutine cerberus_prepare(ht,signal)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,ht,ix_t,load_flag,signal,jx_t,vnew,repeat
   real(8), external :: ran

   if (ht==1) then
      ix(:,0)=-1
      ix(0,0)=0
      do i=1,lpdim
         ix_t=int(x1(i)/dxl)
         !print*,i,ix_t,ix(0,0)
         load_flag=0d0
         if (ix(0,0)/=0) then
            do j=1,ix(0,0)
               !print*,j,ix_t,ix(0,0)
               if (ix(j,0)==ix_t) then
                  ix(j,1)=ix(j,1)+1
                  xrelation(j,ix(j,1))=i
                  load_flag=1d0
                  !exit
               endif
            enddo
         endif
         !print*,"load_flag",load_flag
         if (load_flag==0d0) then
            ix(0,0)=ix(0,0)+1
            ix(ix(0,0),0)=ix_t
            ix(ix(0,0),1)=1
            xrelation(ix(0,0),1)=i
            load_flag=1d0
         endif
         !print*,"load_flag",load_flag
      enddo

      ! do i=1,lpdim
      !    if (ix(i,0)==-1) then
      !       cycle
      !    else
      !       ix_t=ix(i,0)
      !       do j=1,ix(i,1)
      !          if (int(x1(xrelation(i,j))/dxl)==ix_t) then
      !          else
      !             print*,"cerberus prepare error",i,j,ix_t,int(x1(xrelation(i,j))/dxl)
      !             print*,"cerberus prepare error",xrelation(i,j),int(x1(xrelation(i,j))/dxl)
      !             print*,"cerberus prepare error",ix(i,0),ix(i,1),ix(0,0)
      !             print*,"cerberus prepare error",int(x1(:)/dxl)
      !             pause
      !          endif
      !       enddo
      !    endif
      ! enddo
   elseif (ht==2) then
      do i=1,lpdim
         do j=1,lpdim
            if (x2(i)==x0(j) .or. x1(i)==x0(j)) then
               if (vc(j,0)==1 .and. vc(i,1)==1) then
                  vc(j,2)=j
                  vc(j,3)=i
                  vc(j,0)=ieor(vc(j,0),1)
                  vc(i,1)=ieor(vc(i,1),1)
                  !print*,"cerberus",i,j,x0(j),x1(i),x2(i)
                  cycle
               endif
            endif
         enddo
      enddo

      if (sum(vc(:,0))==0 .and. counter/=1) then
         !print*,"cerberus prepare",vc(:,0)
         !print*,"cerberus prepare",x0(:)
         !print*,"cerberus prepare",x1(:)
         !print*,"cerberus prepare",x2(:)
         !print*,"============================="
         cerberus_flag=cerberus_flag+1
      elseif (sum(vc(:,0))/=0 .and. counter/=1) then
         if (signal/=2) then
            vc(:,0)=1d0
            vc(:,1)=1d0
         else
            do i=1,lpdim
               if (vc(i,0)==0d0) then
                  call cerberus_insertSpSm(vc(i,2),vc(i,3))
               endif
            enddo
         endif
      endif
   endif

end subroutine cerberus_prepare
!==================================================!
!==================================================!

subroutine cerberus_insertSpSm(ix_t0,ix_t1)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,ix_t0,ix_t1,v_insert,repeat
   real(8), external :: ran

   !print*,"check cerberus_insertSpSm start",ix_t0,ix_t1
   repeat=0d0
   do
      v_insert=int(ran()*mm)*dxl+int(dxl*ran())
      !x0(i)=idx_mm*dxl+int(dxl*ran())
      repeat=0d0
      do j=1,lpdim
         if (vc(j,0)==1 .and. v_insert==x0(j)) then
            repeat=1
            exit
         endif
      enddo
      if ( vertexlist_map(v_insert)>=0 .and. repeat==0) then
         x0(ix_t0)=v_insert
         x1(ix_t1)=v_insert
         x2(ix_t1)=0d0
         vc(ix_t0,0)=ieor(vc(ix_t0,0),1)
         vc(ix_t1,1)=ieor(vc(ix_t1,1),1)
         exit
      endif
   enddo
   !print*,"check cerberus_insertSpSm"


end subroutine cerberus_insertSpSm
!==================================================!

subroutine mulloopbuilding(i,lpnum_cur,lpgp_idx,rank)
!-----------------------------------------------------------!
!-----------------------------------------------------------!
 use configuration
 use vertexupdate
 implicit none

 integer :: i,j,legold,legnew,upold,upnew,opsmold,opsmnew,bstmp,rank,update_counter_0,lpgp_idx
 integer :: opfp_tmp,leg_in_0,leg_out_0,leg_in_1,leg_out_1,opsum,k,headnum,lpnum_cur,lp_idx
 integer, allocatable :: vertexleg(:,:)
 integer, allocatable :: va(:,:)
 integer, allocatable :: lg(:,:)
 allocate(vertexleg(0:dxl-1,0:1))
 opsmold=mod(opstring(i),2)

 allocate(va(lpnum_cur,0:2))
 allocate(lg(lpnum_cur,2))
 do j=1,lpnum_cur
   lp_idx=xrelation(lpgp_idx,j)
   va(j,0)=x0(lp_idx)
   va(j,1)=x1(lp_idx)
   va(j,2)=x2(lp_idx)
   lg(j,1)=mod(x1(lp_idx),dxl)
   lg(j,2)=mod(x2(lp_idx),dxl)
 enddo

 if (va(1,1)/dxl/=i) then
   print*,"va(1,1)/dxl/=i, building",va(1,1),i
   print*,va(1,1)/dxl
   pause
 endif

 do j=0,mxl-1
   vertexleg(j+mxl,0)=vertexspin(j,i)
   if (opstfp(i,j)/=1 .and. opstfp(i,j)/=-1) then
      print*,"opstfp0",opstfp(i,:),j,opstfp(i,j),i
      pause
   endif
   vertexleg(j,0)=opstfp(i,j)*vertexspin(j,i)
   if (opstfp(i,j)/=1 .and. opstfp(i,j)/=-1) then
      print*,"opstfp1",opstfp(i,:),j,opstfp(i,j)
      pause
   endif
   vertexleg(j+mxl,1)=vertexleg(j+mxl,0)
   vertexleg(j,1)=vertexleg(j,0)
 enddo
 
 do j=1,lpnum_cur
   vertexleg(lg(j,1),1)=-vertexleg(lg(j,1),1)
   vertexleg(lg(j,2),1)=-vertexleg(lg(j,2),1)
 enddo

 opsum=0d0
 do j=0,mxl-1
   opstfp(i,j)=vertexleg(j+mxl,1)*vertexleg(j,1)
   if (opstfp(i,j)==-1) then
      opsum=opsum+1
   elseif (opstfp(i,j)==1) then
   else
      print*,"opstfp2",opstfp(i,:),j,opstfp(i,j)
      pause
   endif
 enddo

 if (opsum==0) then
   opsmnew=0d0
 elseif (opsum==2) then
   opsmnew=1d0
 else
   print*,"opsum",opsum,opstfp(i,:)
   print*,"opsum",lg(:,1),lg(:,2),lpnum_cur,lpgp_idx
   print*,"opsum",vertexleg(:,0)
   print*,"opsum",vertexleg(:,1)
   print*,"opsum",vertexspin(:,i)
   pause
 endif
 if (opsmold/=opsmnew) then
   opstring(i)=ieor(opstring(i),1)
 else
 endif

 do j=1,lpnum_cur
   if (lg(j,1)>=mxl) then 
      vertexspin(mod(lg(j,1),mxl),i)=vertexleg(lg(j,1),1)
   endif
   vertexlist(va(j,1),2)=vertexlist(va(j,1),2)+1
   if (mod(vertexlist(va(j,1),2),2)==0) then
      loop_eff_count=loop_eff_count-1
      loop_tot_count=loop_tot_count+1
   else
      loop_eff_count=loop_eff_count+1
      loop_tot_count=loop_tot_count+1
   endif

   if (lg(j,2)>=mxl) then 
      vertexspin(mod(lg(j,2),mxl),i)=vertexleg(lg(j,2),1)
   endif
   vertexlist(va(j,2),2)=vertexlist(va(j,2),2)+1
   if (mod(vertexlist(va(j,2),2),2)==0) then
      loop_eff_count=loop_eff_count-1
      loop_tot_count=loop_tot_count+1
   else
      loop_eff_count=loop_eff_count+1
      loop_tot_count=loop_tot_count+1
   endif

   va(j,1)=vertexlist_map(va(j,2))
 enddo
 
 do j=1,lpnum_cur
   lp_idx=xrelation(lpgp_idx,j)
   x0(lp_idx)=va(j,0)
   x1(lp_idx)=va(j,1)
   x2(lp_idx)=va(j,2)
 enddo
 
 update_counter_0=update_counter
 update_counter=update_counter+1

 end subroutine mulloopbuilding
!==================================================!
!==================================================!

subroutine mulloopdeter(i,lpnum_cur,lpgp_idx,rank)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,k,signal,rank,i1,i2,i3,lpnum_cur,lp_idx,lpgp_idx
   integer :: site_o,typ,opp,bp,totalspin,l01,l11,ph,l02,l12,v_dim
   integer :: cur0,cur1,s0,s1,index_t,index_in,index_out,dim_dxl
   integer :: typ_num,cage_num
   integer, allocatable :: va(:,:)
   integer, allocatable :: lg(:,:)
   real(8) :: totalflux
   real(8), external :: ran
   real(8), external :: hf

   allocate(va(lpnum_cur,0:2))
   allocate(lg(lpnum_cur,2))
   
   do j=1,lpnum_cur
      lp_idx=xrelation(lpgp_idx,j)
      va(j,0)=x0(lp_idx)
      va(j,1)=x1(lp_idx)
      va(j,2)=x2(lp_idx)
      lg(j,1)=mod(x1(lp_idx),dxl)
   enddo

   if (va(1,1)/dxl/=i) then
      print*,"va(1,1)/dxl/=i",va(1,1),i
      print*,va(1,1)/dxl
      pause
   endif
   opp=opstring(i)
   bp=int(opp/8)
   typ=int(mod(opp,8)/2)+1

   !index_in=l01+l11*dxl
   index_in=0d0
   do j=1,lpnum_cur
      index_in=index_in+lg(j,1)*(dxl**(j-1))
   enddo

   cur0=0d0
   cur1=0d0
   !print*,opstfp(i,:),"++++++++++++++++++++++",i
   do j=0,mxl-1
      s1=int((vertexspin(j,i)+1d0)*0.5d0)
      state_leg(j+mxl,:)=vertexspin(j,i)
      if (mod(opp,2)==0) then
         s0=int((vertexspin(j,i)+1d0)*0.5d0)
         state_leg(j,:)=vertexspin(j,i)
      elseif (mod(opp,2)==1) then
         s0=int((vertexspin(j,i)*opstfp(i,j)+1d0)*0.5d0)
         state_leg(j,:)=vertexspin(j,i)*opstfp(i,j)
      endif

      !print*,j,s0,s1,2**j,mod(opp,2)
      cur0=cur0+s0*2**j
      cur1=cur1+s1*2**j

   enddo

   totalflux=weightable(cur0,cur1,typ)
   if (totalflux==0d0) then
      print*, "totalflux==0d0",cur0,cur1,totalflux
      pause
   endif

   if (lpnum_cur<=lpdimax) then
   !if (1==0) then
      v_dim=dxl**lpnum_cur
      typ_num=fluxnum(cur0,cur1,index_in,0,0,lpnum_cur)
      if (abs(totalflux-sum(fluxsut(cur0,cur1,index_in,1:typ_num,lpnum_cur,2)))>0.00001d0) then
         print*, "abs(totalflux-sum())>0.00001d0"
         pause
      endif
      do j=1,typ_num
         if (j==typ_num) then
            cage_num=fluxnum(cur0,cur1,index_in,j,0,lpnum_cur)
            index_out=int(ran()*cage_num)+1
            !print*, "typ_num",typ_num,cage_num,index_out
            index_out=fluxnum(cur0,cur1,index_in,j,index_out,lpnum_cur)
         elseif (ran()*totalflux<=fluxsut(cur0,cur1,index_in,j,lpnum_cur,2)) then
            cage_num=fluxnum(cur0,cur1,index_in,j,0,lpnum_cur)
            index_out=int(ran()*cage_num)+1
            !print*, "typ_num",typ_num,cage_num,index_out
            index_out=fluxnum(cur0,cur1,index_in,j,index_out,lpnum_cur)
            exit
         else
            totalflux=totalflux-fluxsut(cur0,cur1,index_in,j,lpnum_cur,2)
         endif
         !print*, "typ_num",typ_num,cage_num,index_out
      enddo
      ! do j=0,v_dim-1
      !    !print*, fluxtamul(cur0,cur1,l1,j,looppm,1,2)
      !    if (fluxtamul(cur0,cur1,index_in,j,lpnum_cur,2)/=0d0) then
      !       if (fluxtamul(cur0,cur1,index_in,j,lpnum_cur,1)==0d0) cycle
      !       if (ran()*totalflux<=fluxtamul(cur0,cur1,index_in,j,lpnum_cur,1)) then
      !          index_out=j
      !          !print*, "v1-v2","0",l1,j
      !          exit
      !       else
      !          totalflux=totalflux-fluxtamul(cur0,cur1,index_in,j,lpnum_cur,1)
      !       endif
      !    elseif (fluxtamul(cur0,cur1,index_in,j,lpnum_cur,2)==0d0) then
      !       index_out=j
      !       !print*, "v1-v2","1",l1,j
      !       exit
      !    endif
      ! enddo
   else
      call mullooprobe(lpnum_cur,index_in,totalflux,typ,2)
      index_out=index_bp
   endif

   index_t=index_out
   do j=1,lpnum_cur
      dim_dxl=dxl**(j-1)
      lg(j,2)=mod(int(index_t/dim_dxl),dxl)
      lp_idx=xrelation(lpgp_idx,j)
      va(j,2)=lg(j,2)+i*dxl
      x2(lp_idx)=va(j,2)
   enddo

end subroutine mulloopdeter
!==================================================!
!==================================================!

subroutine mullooprobe(lpnum_cur,index_in,w_org,typ,sol_typ)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,k,lpnum_cur,v_dim,index_in,dim_dxl
   integer :: cur2,cur3,typ,index_last,sol_typ,index_it
   real(8) :: weight_tmp,w_org,w_org_tmp
   integer, allocatable :: leg_in(:)
   integer, allocatable :: leg_out(:)
   real(8), external :: ran

   allocate(leg_in(0:lpnum_cur-1))
   allocate(leg_out(0:lpnum_cur-1))
   !print*, "index_bp start",index_bp

   totalwgt=0d0
   v_dim=dxl**lpnum_cur

   do j=1,lpnum_cur
      dim_dxl=dxl**(j-1)
      leg_in(j-1)=mod(int(index_in/dim_dxl),dxl)
      state_leg(leg_in(j-1),1)=-state_leg(leg_in(j-1),1)
   enddo

   if (sol_typ==1) then
      do i=0,v_dim-1
         if (i<=v_dim-1) then
            do j=1,lpnum_cur
               dim_dxl=dxl**(j-1)
               leg_out(j-1)=mod(int(i/dim_dxl),dxl)
               state_leg(leg_out(j-1),1)=-state_leg(leg_out(j-1),1)
            enddo

            cur2=0d0
            cur3=0d0
            do k=0,mxl-1
               cur2=cur2+int((state_leg(k,1)+1)*0.5d0)*2**(k)
               cur3=cur3+int((state_leg(k+mxl,1)+1)*0.5d0)*2**(k)
            enddo
            weight_tmp=weightable(cur2,cur3,typ)

            do j=1,lpnum_cur
               state_leg(leg_out(j-1),1)=-state_leg(leg_out(j-1),1)
            enddo

            totalwgt=totalwgt+weight_tmp*w_org
            !print*, "check",totalwgt,weight_tmp
         else
         endif
      enddo

      index_bp=-1
      do i=0,v_dim-1
         if (i<=v_dim-1) then
            do j=1,lpnum_cur
               dim_dxl=dxl**(j-1)
               leg_out(j-1)=mod(int(i/dim_dxl),dxl)
               state_leg(leg_out(j-1),1)=-state_leg(leg_out(j-1),1)
            enddo

            cur2=0d0
            cur3=0d0
            do k=0,mxl-1
               cur2=cur2+int((state_leg(k,1)+1)*0.5d0)*2**(k)
               cur3=cur3+int((state_leg(k+mxl,1)+1)*0.5d0)*2**(k)
            enddo
            weight_tmp=weightable(cur2,cur3,typ)

            if (weight_tmp/=0) then
               index_last=i
               if (ran()*totalwgt<=weight_tmp*w_org) then
                  index_bp=i
                  exit
               else
                  totalwgt=totalwgt-weight_tmp*w_org
               endif
            else
            endif

            do j=1,lpnum_cur
               state_leg(leg_out(j-1),1)=-state_leg(leg_out(j-1),1)
            enddo
         else
         endif
      enddo
   elseif (sol_typ==2) then
      index_bp=-1
      w_org_tmp=w_org
      index_it=index_in
      do i=0,v_dim-1
         index_it=mod(index_in+i+1,v_dim)
         !print*, "index_it",index_it,i,v_dim,w_org_tmp
         if (index_it==index_in) then
            index_bp=index_it
         else
            do j=1,lpnum_cur
               dim_dxl=dxl**(j-1)
               leg_out(j-1)=mod(int(index_it/dim_dxl),dxl)
               state_leg(leg_out(j-1),1)=-state_leg(leg_out(j-1),1)
            enddo

            cur2=0d0
            cur3=0d0
            do k=0,mxl-1
               cur2=cur2+int((state_leg(k,1)+1)*0.5d0)*2**(k)
               cur3=cur3+int((state_leg(k+mxl,1)+1)*0.5d0)*2**(k)
            enddo
            weight_tmp=weightable(cur2,cur3,typ)

            if (weight_tmp/=0) then
               index_last=index_it
               if (ran()*w_org_tmp*(v_dim-1)<=min(weight_tmp,w_org)) then
                  index_bp=index_it
                  exit
               else
                  w_org_tmp=w_org_tmp-min(weight_tmp,w_org)/dble(v_dim-1)
               endif
            else
            endif

            do j=1,lpnum_cur
               state_leg(leg_out(j-1),1)=-state_leg(leg_out(j-1),1)
            enddo
         endif
      enddo
   elseif (sol_typ==3) then
      index_bp=index_in
   endif

   if (index_bp==-1) then
      index_bp=index_last
   endif
   !print*, "index_bp end",index_bp,v_dim

end subroutine mullooprobe
!==================================================!

!==================================================!

subroutine loopbuilding(i,vxw,rank,headnum)
!-----------------------------------------------------------!
!-----------------------------------------------------------!
 use configuration
 use vertexupdate
 implicit none

 integer :: i,j,legold,legnew,upold,upnew,opsmold,opsmnew,bstmp,rank,update_counter_0
 integer :: opfp_tmp,leg_in,leg_out,opsum,k,headnum
 integer :: vxw
 integer, allocatable :: vertexleg(:,:)
 
 !vxw=0
 if (vxw==0) then
   vh1=v1
   vh2=v2
   vh0=v0
 endif

 allocate(vertexleg(0:dxl-1,0:1))
 opsmold=mod(opstring(i),2)
 leg_in=mod(vh1,dxl)
 leg_out=mod(vh2,dxl)

 
 !print*,"loop build start",i,vh1,vh2
 do j=0,mxl-1
   vertexleg(j+mxl,0)=vertexspin(j,i)
   if (opstfp(i,j)/=1 .and. opstfp(i,j)/=-1) then
      print*,"opstfp0",opstfp(i,:),j,opstfp(i,j)
      pause
   endif
   vertexleg(j,0)=opstfp(i,j)*vertexspin(j,i)
   if (opstfp(i,j)/=1 .and. opstfp(i,j)/=-1) then
      print*,"opstfp1",opstfp(i,:),j,opstfp(i,j)
      pause
   endif
   vertexleg(j+mxl,1)=vertexleg(j+mxl,0)
   vertexleg(j,1)=vertexleg(j,0)
 enddo
 vertexleg(leg_in,1)=-vertexleg(leg_in,1)
 vertexleg(leg_out,1)=-vertexleg(leg_out,1)

 opsum=0d0
 do j=0,mxl-1
   opstfp(i,j)=vertexleg(j+mxl,1)*vertexleg(j,1)
   if (opstfp(i,j)==-1) then
      opsum=opsum+1
   elseif (opstfp(i,j)==1) then
   else
      print*,"opstfp2",opstfp(i,:),j,opstfp(i,j)
      pause
   endif
 enddo

 if (opsum==0) then
   opsmnew=0d0
 elseif (opsum==2) then
   opsmnew=1d0
 else
   print*,"opsum",opsum,opstfp(i,:)
   print*,"opsum",vertexleg(:,1)
   print*,"opsum",vertexspin(:,i)
   pause
 endif
 if (opsmold/=opsmnew) then
   opstring(i)=ieor(opstring(i),1)
 else
 endif

 if (leg_in>=mxl) then 
   vertexspin(mod(leg_in,mxl),i)=vertexleg(leg_in,1)
 endif
 if (leg_out>=mxl) then 
   vertexspin(mod(leg_out,mxl),i)=vertexleg(leg_out,1)
 endif
 vertexlist(vh1,2)=vertexlist(vh1,2)+1
 vertexlist(vh2,2)=vertexlist(vh2,2)+1
 
 if (vh1/=vh2) then
   if (mod(vertexlist(vh1,2),2)==0) then
      loop_eff_count=loop_eff_count-1
      loop_tot_count=loop_tot_count+1
   else
      loop_eff_count=loop_eff_count+1
      loop_tot_count=loop_tot_count+1
   endif
   
   if (mod(vertexlist(vh2,2),2)==0) then
      loop_eff_count=loop_eff_count-1
      loop_tot_count=loop_tot_count+1
   else
      loop_eff_count=loop_eff_count+1
      loop_tot_count=loop_tot_count+1
   endif
   
   vh1=vertexlist_map(vh2)
 else
   if (headnum==1) then
      vh1=vertexlist_map(vh2)
   else
      vh1=vertexlist_map(vh2)
      vht=vh1
      vh1=vh0
      vh0=vht
      !print*,"loop build exchange",vh0,vh1,vht,v0,v1
   endif

 endif
 
 !v1=vertexlist_map(v2)
 
 if (Spm_measure_signal==1) call SpinFlippingRecorder(i,2)
 update_counter_0=update_counter
 update_counter=update_counter+1

 if (vxw==0) then
   v1=vh1
   v2=vh2
   v0=vh0
 endif

 !do k=0,mm-1
 !  do j=0,mxl-1
 !     if (opstfp(k,j)==-1) then
 !     elseif (opstfp(k,j)==1) then
 !     else
 !        print*,"opstfp3",i,k,j
 !        print*,"opstfp3",opstfp(k,:),j,opstfp(k,j)
 !        pause
 !     endif
 !  enddo
 !enddo

 !print*,"loop build end",v1,v2

 end subroutine loopbuilding
!==================================================!
!==================================================!

subroutine loopdeter(signal,vxw,rank,headnum)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,k,signal,rank,i1,i2,i3
   integer :: site_o,typ,opp,bp,totalspin,l1,ph,l2
   integer :: cur0,cur1,s0,s1,headnum
   integer :: vxw
   real(8) :: totalflux
   real(8), external :: ran
   real(8), external :: hf

   !vxw=0d0
   if (vxw==0) then
      vh1=v1
      vh2=v2
      vh0=v0
   endif

   i=vh1/dxl
   opp=opstring(i)
   bp=int(opp/8)
   typ=int(mod(opp,8)/2)+1
   l1=mod(vh1,dxl)
   udmrr=int(l1/mxl)

   cur0=0d0
   cur1=0d0
   do j=0,mxl-1
      s1=int((vertexspin(j,i)+1d0)*0.5d0)
      if (mod(opp,2)==0) then
         s0=int((vertexspin(j,i)+1d0)*0.5d0)
      elseif (mod(opp,2)==1) then
         s0=int((vertexspin(j,i)*opstfp(i,j)+1d0)*0.5d0)
      endif

      !print*,j,s0,s1,2**j,mod(op,2)
      cur0=cur0+s0*2**j
      cur1=cur1+s1*2**j
   enddo

   totalflux=weightable(cur0,cur1,typ)
   !print*, "totalflux",totalflux
   !if (headnum==2) print*, "totalflux",totalflux
   if (totalflux==0d0) then
      print*, "totalflux==0d0",cur0,cur1,totalflux
      pause
   endif
   do j=0,dxl-1
      !print*, fluxtable(cur0,cur1,l1,j,looppm,1,2)
      if (fluxtable(cur0,cur1,l1,j,looppm,1,2)/=0d0) then
         if (fluxtable(cur0,cur1,l1,j,looppm,1,1)==0d0) cycle
         if (ran()*totalflux<=fluxtable(cur0,cur1,l1,j,looppm,1,1)) then
            vh2=i*dxl+j
            !print*, "v1-v2","0",l1,j
            exit
         else
            totalflux=totalflux-fluxtable(cur0,cur1,l1,j,looppm,1,1)
         endif
      elseif (fluxtable(cur0,cur1,l1,j,looppm,1,2)==0d0) then
         vh2=i*dxl+j
         !print*, "v1-v2","1",l1,j
         exit
      endif
   enddo

   if (vxw==0) then
      v1=vh1
      v2=vh2
      v0=vh0
   endif

end subroutine loopdeter
!==================================================!

!==================================================!

subroutine markleg(totalspin,i)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,k,l,t
   integer :: site_o,typ,totalspin,l1

   i=v1/dxl

   if (mod(op,2)==0d0) then
      rlmrr=0d0
      if (totalspin==3 .or. totalspin==-3) then
         do j=0,mxl-1
            if (j==0) then
               legtab(j,0)=0
               legtab(0,1)=j
               legtab(j+mxl,0)=3
               legtab(3,1)=j+mxl

               k=mod(j+1+mxl,mxl)
               l=mod(j-1+mxl,mxl)
               legtab(k,0)=1
               legtab(1,1)=k
               legtab(l,0)=2
               legtab(2,1)=l

               legtab(l+mxl,0)=4
               legtab(4,1)=l+mxl
               legtab(k+mxl,0)=5
               legtab(5,1)=k+mxl
               exit
            endif
         enddo
      elseif (totalspin==1 .or. totalspin==-1) then
         do j=0,mxl-1
            if (vertexspin(j,i)==-totalspin) then
               legtab(j,0)=0
               legtab(0,1)=j
               legtab(j+mxl,0)=3
               legtab(3,1)=j+mxl

               k=mod(j+1+mxl,mxl)
               l=mod(j-1+mxl,mxl)
               legtab(k,0)=1
               legtab(1,1)=k
               legtab(l,0)=2
               legtab(2,1)=l

               legtab(l+mxl,0)=4
               legtab(4,1)=l+mxl
               legtab(k+mxl,0)=5
               legtab(5,1)=k+mxl
               exit
            endif
         enddo
      endif
   elseif (mod(op,2)==1d0) then
      do j=0,mxl-1
         if (opstfp(i,j)==1) then
            legtab(j,0)=0
            legtab(0,1)=j
            legtab(j+mxl,0)=3
            legtab(3,1)=j+mxl
            
            k=mod(j+1+mxl,mxl)
            l=mod(j-1+mxl,mxl)
            !print*, "ver", vertexspin(k,i),vertexspin(j,i)
            if (vertexspin(k,i)==vertexspin(j,i)) then
               rlmrr=0d0
            elseif (vertexspin(k,i)/=vertexspin(j,i)) then
               rlmrr=1d0
               t=k
               k=l
               l=t
            endif
            legtab(k,0)=1
            legtab(1,1)=k
            legtab(l,0)=2
            legtab(2,1)=l

            legtab(l+mxl,0)=4
            legtab(4,1)=l+mxl
            legtab(k+mxl,0)=5
            legtab(5,1)=k+mxl
            !print*,"check"
            exit
         endif
      enddo
   endif
   if (opstfp(i,legtab(0,1))==-1) then
      print*,"opstfp(i,legtab(0,1))==-1",mod(op,2)
      pause
   endif

end subroutine markleg
!==================================================!

subroutine diagbondchanging(prid,sign)
   use configuration
   use vertexupdate
   implicit none

   integer :: prid,sign
   integer :: i,j,k,l,ml_max0,ml_max1,ml_max_idx0,ml_max_idx1,ml_other_0,ml_other_1
   integer :: w_idx,addornot,c_idx,stot0,stot1,ml_other_2,ml_other_x
   integer :: side,side_opp,totalspin,c_idx_max0,c_idx_max1,c_idx_opp
   integer :: c0,c1,c2,c3,tm0,tm1,tm2,tm3,s0,s1,btmp,optmp,brepl
   integer :: l0_up,l1_up,l2_up,l3_up,l0_dw,l1_dw,l2_dw,l3_dw
   integer :: cur0,cur1,cur2,cur3,s2,s3,mmtmp,maxc,maxc_idx,stmp,typ
   real(8) :: clsiz,pbsum,w0,w1,wc,wn
   integer, allocatable :: opcount(:)
   real(8), external :: ran

   allocate(opcount(0:5))
   opcount(:)=0d0

   do j=0,mm-1
      optmp=opstring(j)
      btmp=optmp/8
      !brepl=btmp
      cur0=0d0
      cur1=0d0
      s2=0d0
      s3=0d0
      if (optmp==0d0) then
         cycle
      elseif (mod(optmp,2)==0) then
         s2=0d0
         do k=0,mxl-1
            s0=bsites(k+1,btmp)
            if (s0==-1) exit
            cur0=cur0+int((spin(s0)+1)*0.5d0)*2**(k)
            s2=s2+spin(s0)
         enddo
         w0=weightable(cur0,cur0,1)
         if (s2==0) then
            opcount(0)=opcount(0)+1
         elseif (s2==2 .or. s2==-2) then
            opcount(1)=opcount(1)+1
         elseif (s2==4 .or. s2==-4) then
            opcount(2)=opcount(2)+1
         endif

         brepl=int(ran()*int(pbAc))+1
         brepl=sambon(bontab(brepl))
         brepl=btmp
         wc=w0
         do
            if (brepl<=pbAc .and. sambon(bontab(brepl))<=nbs) then
               s3=0d0
               cur1=0d0
               do k=0,mxl-1
                  s1=bsites(k+1,brepl)
                  if (s1==-1) exit
                  cur1=cur1+int((spin(s1)+1)*0.5d0)*2**(k)
                  s3=s3+spin(s1)
               enddo
               w1=weightable(cur1,cur1,1)
               exit
            else
               cycle
            endif
         enddo
         if (ran()*w0<=w1) then
            opstring(j)=8*brepl
         else
            s3=s2
         endif
         if (s3==0) then
            opcount(3)=opcount(3)+1
         elseif (s3==2 .or. s3==-2) then
            opcount(4)=opcount(4)+1
         elseif (s3==4 .or. s3==-4) then
            opcount(5)=opcount(5)+1
            !print*, "w0,w1",w0,w1,cur0,cur1
            !pause
         endif
      elseif (mod(optmp,2)==1) then
         typ=int(mod(optmp,8)/2)+1
         if (typ==1 .or. typ==2 .or. typ==4) then
            do k=0,mxl-1
               stmp=bsites(k+1,btmp)
               if (stmp==-1) then
                  exit
               elseif (opstfp(j,k)==-1) then
                  spin(stmp)=-spin(stmp)
               endif
            enddo
         else
            spin(btmp)=-spin(btmp)
         endif
      endif
   enddo
   !print*, "opcount",opcount(0),opcount(1),opcount(2),sum(opcount(0:2))
   !print*, "opcount",opcount(3),opcount(4),opcount(5),sum(opcount(3:5))
end subroutine diagbondchanging

!==================================================!

subroutine clusterupdate(prid,sign)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,k,leg_in,vo,vidx,lengts,clusternum,prid,clustermax,sign,self,build_counter
   integer :: marker_cur,mmtmp,dealtyp_tmp,leg_tmp,bstmp,vertexleg1,vertexleg2
   real(8) :: clsiz,pbsum
   real(8), external :: ran

   if (bondmaker>3) return
   clustermark=0
   update_counter=0d0
   cluster_counter=0d0
   build_counter=0d0
   aclcrr=0d0
   marker=0d0
   clusterflog(0,0)=0d0

   ! clusterupdate note
   ! dealtyp action
   ! 0      one in one out
   ! 1      one in all out
   ! 2      one in one side out
   ! 4      all stop

   if (nh/=0d0) then
      i=0d0
      !print*, "======================================"
      do i=1,nh
         mmtmp=oporder(i)
         dealtyp_tmp=dealtyp(i)
         !print*, dealtyp_tmp
         if (dealtyp_tmp==0) then
            do j=0,dxl-1
               vertexleg1=vertexlist(mmtmp*dxl+j,1)
               if (vertexleg1/=0) then
                  cycle
               elseif (vertexleg1==0) then
                  v0=mmtmp*dxl+j
                  clusterflog(0,0)=clusterflog(0,0)+1
                  marker=marker+1
                  marker_cur=marker
                  clusterflog(marker_cur,0)=0
                  call clusterbuilding()
                  clusterflog(marker_cur,0)=int(2.*ran())+1
                  clusterflog(marker_cur,1)=marker_cur
               endif
            enddo
         elseif (dealtyp_tmp==1) then
         elseif (dealtyp_tmp==2) then
            do j=0,dxl-1
               vertexleg1=vertexlist(mmtmp*dxl,1)
               if (vertexleg1/=0) then
                  cycle
               elseif (vertexleg1==0) then
                  !print*, "vertexleg1",vertexleg1,vertexlist_map(mmtmp*dxl)
                  v0=mmtmp*dxl+j
                  clusterflog(0,0)=clusterflog(0,0)+1
                  marker=marker+1
                  marker_cur=marker
                  clusterflog(marker_cur,0)=0
                  call clusterbuilding()
                  clusterflog(marker_cur,0)=int(2.*ran())+1
                  clusterflog(marker_cur,1)=marker_cur
               endif
            enddo
         elseif (dealtyp_tmp==4) then
            do j=0,dxl-1
               vertexleg1=vertexlist(mmtmp*dxl+j,1)
               if (vertexleg1/=0) then
                  cycle
               elseif (vertexleg1==0) then
                  v0=mmtmp*dxl+j
                  clusterflog(0,0)=clusterflog(0,0)+1
                  marker=marker+1
                  marker_cur=marker
                  clusterflog(marker_cur,0)=0
                  call clusterbuilding()
                  clusterflog(marker_cur,0)=int(2.*ran())+1
                  clusterflog(marker_cur,1)=marker_cur
               endif
            enddo
         endif
      enddo

      call clustercalprob(prid)
      
      clusterdim=clusterdim+clusterflog(0,1)
      clusterdimax=max(clusterflog(0,1),clusterdimax)
      clusterbtm=clusterbtm+1
      !print*, "clusterflog",clusterflog(0,0),offoporder(0),digoporder(0),clusterbtm
      !if (clusterflog(0,1)/=1) then
      !   print*, "clusterflog(0,1)",clusterflog(0,1),prid
      !endif
      !print*, "clustercalprob"
      !call clustercalprob2(prid)

      call clusterfliper()

   endif

end subroutine clusterupdate
!==================================================!

!==================================================!

subroutine clustercalprob(prid)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,k,l,ml_max0,ml_max1,ml_max_idx0,ml_max_idx1,ml_other_0,ml_other_1,prid
   integer :: w_idx,addornot,c_idx,stot0,stot1,ml_other_2,ml_other_x
   integer :: side,side_opp,totalspin,c_idx_max0,c_idx_max1,c_idx_opp
   integer :: c0,c1,c2,c3,tm0,tm1,tm2,tm3,s0,s1,btmp,optmp,brepl
   integer :: l0_up,l1_up,l2_up,l3_up,l0_dw,l1_dw,l2_dw,l3_dw
   integer :: cur0,cur1,cur2,cur3,s2,s3,mmtmp,maxc,maxc_idx
   integer, allocatable :: spincomp(:,:)
   integer, allocatable :: clusterlink(:,:)
   integer, allocatable :: mleg(:)
   integer, allocatable :: off_leg(:)
   integer, allocatable :: dig_leg(:)
   integer, allocatable :: opcount(:)
   real(8) :: clsiz,pbsum,w0,w1,wc,wn
   real(8), external :: ran

   allocate(mleg(0:dxl-1))
   allocate(off_leg(0:3))
   allocate(dig_leg(0:3))
   allocate(clusterlink(0:clusterflog(0,0),0:3))
   allocate(spincomp(nn,0:2))
   allocate(opcount(0:5))

   clusterlink(0,:)=0d0
   clusterlink(0,0)=clusterflog(0,0)
   clusterflog(0,1)=clusterflog(0,0)
   spacevisit(:)=0d0
   spincomp(:,0)=spin(:)
   spincomp(:,1)=spin(:)
   spincomp(:,2)=spin(:)

   if (clusterflog(0,0)/=1) then
      !print*,"clusterflog(0,0)",clusterflog(0,0),prid,clusterdimax,offoporder(0),clusterbtm

      do i=1,offoporder(0)
         j=offoporder(i)
         !print*, "offoporder",j,offoporder(i)
         btmp=opstring(j)/8
         spacevisit(btmp)=spacevisit(btmp)+1
         !spacevisit(btmp)=1

         cur0=0d0
         off_leg(0)=0d0
         dig_leg(0)=0d0
         totalspin=0d0
         do k=0,dxl-1
            mleg(k)=clusterflog(vertexlist(j*dxl+k,1),1)
            if (mleg(k)<=0 .or. mleg(k)>clusterflog(0,0)) then
               print*,"mleg error",mleg(k),clusterflog(0,0),vertexlist(j*dxl+k,1)
               pause
            endif
            clusterlink(mleg(k),:)=0d0
         enddo

         ml_max0=0d0
         ml_max1=0d0
         totalspin=0d0
         do k=0,mxl-1
            clusterlink(mleg(k),0)=clusterlink(mleg(k),0)+1
            clusterlink(mleg(k),1)=clusterlink(mleg(k),1)+vertexspin(k,j)*opstfp(j,k)
            if (ml_max0<clusterlink(mleg(k),0)) then
               ml_max0=max(ml_max0,clusterlink(mleg(k),0))
               ml_max_idx0=k
            endif

            clusterlink(mleg(k+mxl),2)=clusterlink(mleg(k+mxl),2)+1
            clusterlink(mleg(k+mxl),3)=clusterlink(mleg(k+mxl),3)+vertexspin(k,j)
            if (ml_max1<clusterlink(mleg(k+mxl),2)) then
               ml_max1=max(ml_max1,clusterlink(mleg(k+mxl),2))
               ml_max_idx1=k+mxl
            endif

            totalspin=totalspin+vertexspin(k,j)

            if (opstfp(j,k)==-1) then
               off_leg(0)=off_leg(0)+1
               off_leg(off_leg(0))=k
            else
               dig_leg(0)=dig_leg(0)+1
               dig_leg(dig_leg(0))=k
            endif
         enddo
         c_idx_max0=mleg(ml_max_idx0)
         c_idx_max1=mleg(ml_max_idx1)

         !if ((mleg(dig_leg(1))/=c_idx_max0 .and. mleg(dig_leg(1)+mxl)/=c_idx_max1) .or. &
         !&(mleg(dig_leg(2))/=c_idx_max0 .and. mleg(dig_leg(2)+mxl)/=c_idx_max1)) then
         !   print*,vertexlist(j*dxl+4,1),vertexlist(j*dxl+5,1),vertexlist(j*dxl+6,1),vertexlist(j*dxl+7,1)
         !   print*,vertexlist(j*dxl,1),vertexlist(j*dxl+1,1),vertexlist(j*dxl+2,1),vertexlist(j*dxl+3,1)
         !   print*,"-----------------------------------------------------------"
         !   print*,vertexspin(0,j),vertexspin(1,j),vertexspin(2,j),vertexspin(3,j)
         !   print*,vertexspin(0,j)*opstfp(j,0),vertexspin(1,j)*opstfp(j,1)&
         !   &,vertexspin(2,j)*opstfp(j,2),vertexspin(3,j)*opstfp(j,3)
         !   print*,"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\|||"
         !endif

         if ( 1==0 ) then
         !if ( mleg(off_leg(1)+mxl)==mleg(off_leg(2)+mxl) .and. &
         !&mleg(off_leg(1))==mleg(off_leg(2)) ) then
         
            if (ml_max0==4 .and. ml_max1==4) then
               if (c_idx_max0/=c_idx_max1) then
                  call joincluster(c_idx_max0,c_idx_max1)
               endif
            else
               l0_up=off_leg(1)+mxl
               l0_dw=off_leg(1)
               l2_up=off_leg(2)+mxl
               l2_dw=off_leg(2)

               l1_up=dig_leg(1)+mxl
               l1_dw=dig_leg(1)
               l3_up=dig_leg(2)+mxl
               l3_dw=dig_leg(2)

               if (mleg(l0_up)==c_idx_max1) then
                  call joincluster(mleg(l0_dw),mleg(l0_up))
               else
                  call joincluster(mleg(l0_up),mleg(l0_dw))
               endif
               c0=clusterflog(mleg(l0_dw),1)
               if (mleg(l2_up)==c_idx_max1) then
                  call joincluster(mleg(l2_dw),mleg(l2_up))
               else
                  call joincluster(mleg(l2_up),mleg(l2_dw))
               endif
               c2=clusterflog(mleg(l2_dw),1)
               if (c2==c_idx_max1) then
                  call joincluster(c0,c2)
               else
                  call joincluster(c2,c0)
               endif
               c0=clusterflog(mleg(l0_dw),1)

               if (mleg(l1_up)==c_idx_max1) then
                  call joincluster(mleg(l1_dw),mleg(l1_up))
               else
                  call joincluster(mleg(l1_up),mleg(l1_dw))
               endif
               c1=clusterflog(mleg(l1_dw),1)
               if (mleg(l3_up)==c_idx_max1) then
                  call joincluster(mleg(l3_dw),mleg(l3_up))
               else
                  call joincluster(mleg(l3_up),mleg(l3_dw))
               endif
               c3=clusterflog(mleg(l3_dw),1)
            endif
         else
            if (totalspin==0d0) then
               if (ml_max0==4 .and. ml_max1==4) then
               elseif (ml_max0>=3 .and. ml_max1>=3) then
                  do k=0,mxl-1
                     c0=mleg(k+0*mxl)
                     call joincluster(c0,c_idx_max0)
                     c1=mleg(k+1*mxl)
                     call joincluster(c1,c_idx_max1)
                  enddo
               else
                  l0_up=off_leg(1)+mxl
                  l2_up=off_leg(2)+mxl
                  l0_dw=off_leg(2)
                  l2_dw=off_leg(1)

                  if (vertexspin(off_leg(1),j)+vertexspin(dig_leg(1),j)==0) then
                     l1_up=dig_leg(1)+mxl
                     l3_up=dig_leg(2)+mxl
                     l1_dw=dig_leg(1)
                     l3_dw=dig_leg(2)
                  else
                     l1_up=dig_leg(2)+mxl
                     l3_up=dig_leg(1)+mxl
                     l1_dw=dig_leg(2)
                     l3_dw=dig_leg(1)
                  endif
                  
                  if (mleg(l1_up)==c_idx_max1) then
                     call joincluster(mleg(l0_up),mleg(l1_up))
                  else
                     call joincluster(mleg(l1_up),mleg(l0_up))
                  endif
                  c2=clusterflog(mleg(l0_up),1)
                  if (mleg(l3_up)==c_idx_max1) then
                     call joincluster(mleg(l2_up),mleg(l3_up))
                  else
                     call joincluster(mleg(l3_up),mleg(l2_up))
                  endif
                  c3=clusterflog(mleg(l2_up),1)
                  if (mleg(l1_dw)==c_idx_max0) then
                     call joincluster(mleg(l0_dw),mleg(l1_dw))
                  else
                     call joincluster(mleg(l1_dw),mleg(l0_dw))
                  endif
                  c0=clusterflog(mleg(l0_dw),1)
                  if (mleg(l3_dw)==c_idx_max0) then
                     call joincluster(mleg(l2_dw),mleg(l3_dw))
                  else
                     call joincluster(mleg(l3_dw),mleg(l2_dw))
                  endif
                  c1=clusterflog(mleg(l2_dw),1)
                  
                  if (c1==c0 .and. c2==c3) then
                     if (c0/=c2) then
                     endif
                  elseif (c1==c0 .or. c2==c3) then
                  else
                     if (ran()<=0.5d0) then
                        if (c0==c_idx_max0) then
                           call joincluster(c1,c0)
                        else
                           call joincluster(c0,c1)
                        endif
                     else
                        if (c2==c_idx_max1) then
                           call joincluster(c3,c2)
                        else
                           call joincluster(c2,c3)
                        endif
                     endif
                  endif
               endif
               !print*,"c2", c2,l0_up,l1_up
               !print*,"c3", c3,l2_up,l3_up
               !print*,"c0", c0,l0_dw,l1_dw
               !print*,"c1", c1,l2_dw,l3_dw
            elseif (totalspin==2 .or. totalspin==-2) then
               if (ml_max0==4 .and. ml_max1==4) then
                  if (c_idx_max0/=c_idx_max1) then
                     call joincluster(c_idx_max0,c_idx_max1)
                  endif
               elseif (ml_max0>=3 .and. ml_max1>=3) then
                  do k=0,mxl-1
                     c0=mleg(k+0*mxl)
                     call joincluster(c0,c_idx_max0)
                     c1=mleg(k+1*mxl)
                     call joincluster(c1,c_idx_max1)
                  enddo
                  if (c_idx_max0/=c_idx_max1) then
                     call joincluster(c_idx_max0,c_idx_max1)
                  endif
               else
                  if (vertexspin(off_leg(1),j)*2d0+totalspin==0) then
                     l0_up=off_leg(1)+mxl
                     l0_dw=off_leg(2)
                     l2_up=off_leg(2)+mxl
                     l2_dw=off_leg(1)
                  else
                     l0_up=off_leg(2)+mxl
                     l0_dw=off_leg(1)
                     l2_up=off_leg(1)+mxl
                     l2_dw=off_leg(2)
                  endif
                  if (mleg(l0_dw)==mleg(dig_leg(1)) .or. mleg(l0_up)==mleg(dig_leg(2)+mxl)) then
                     l1_up=dig_leg(2)+mxl
                     l1_dw=dig_leg(1)
                     l3_up=dig_leg(1)+mxl
                     l3_dw=dig_leg(2)
                  elseif (mleg(l0_dw)==mleg(dig_leg(2)) .or. mleg(l0_up)==mleg(dig_leg(1)+mxl)) then
                     l1_up=dig_leg(1)+mxl
                     l1_dw=dig_leg(2)
                     l3_up=dig_leg(2)+mxl
                     l3_dw=dig_leg(1)
                  else
                     if (ran()<=0.5d0) then
                        l1_up=dig_leg(2)+mxl
                        l1_dw=dig_leg(1)
                        l3_up=dig_leg(1)+mxl
                        l3_dw=dig_leg(2)
                     else
                        l1_up=dig_leg(1)+mxl
                        l1_dw=dig_leg(2)
                        l3_up=dig_leg(2)+mxl
                        l3_dw=dig_leg(1)
                     endif
                  endif

                  if (mleg(l1_up)==c_idx_max1) then
                     call joincluster(mleg(l0_up),mleg(l1_up))
                  else
                     call joincluster(mleg(l1_up),mleg(l0_up))
                  endif
                  c2=clusterflog(mleg(l0_up),1)
                  if (mleg(l1_dw)==c_idx_max0) then
                     call joincluster(mleg(l0_dw),mleg(l1_dw))
                  else
                     call joincluster(mleg(l1_dw),mleg(l0_dw))
                  endif
                  c0=clusterflog(mleg(l0_dw),1)

                  if (mleg(l2_up)==c_idx_max1 .or. mleg(l3_up)==c_idx_max1) then
                     call joincluster(mleg(l2_up),c_idx_max1)
                     call joincluster(mleg(l3_up),c_idx_max1)
                     call joincluster(mleg(l2_dw),c_idx_max1)
                     call joincluster(mleg(l3_dw),c_idx_max1)
                  elseif (mleg(l2_dw)==c_idx_max0 .or. mleg(l3_dw)==c_idx_max0) then
                     call joincluster(mleg(l2_up),c_idx_max0)
                     call joincluster(mleg(l3_up),c_idx_max0)
                     call joincluster(mleg(l2_dw),c_idx_max0)
                     call joincluster(mleg(l3_dw),c_idx_max0)
                  else
                     call joincluster(mleg(l2_up),mleg(l2_up))
                     call joincluster(mleg(l3_up),mleg(l2_up))
                     call joincluster(mleg(l2_dw),mleg(l2_up))
                     call joincluster(mleg(l3_dw),mleg(l2_up))
                  endif
                  c1=clusterflog(mleg(l2_dw),1)
                  
                  !print*,"c2", c2,l0_up,l1_up
                  !print*,"c0", c0,l0_dw,l1_dw
                  !print*,"c1", c1,l2_dw,l3_dw,l2_up,l3_up
               endif
            endif
         endif
      enddo

      ! c0=clusterflog(1,1)
      ! do i=1,clusterflog(0,0)
      !    clusterflog(i,2)=0d0
      !    if (clusterflog(i,1)==c0) then
      !       clusterflog(i,0)=2
      !    else
      !       clusterflog(i,0)=1
      !    endif
      ! enddo
      !clusterflog(:,0)=2

      maxc=0d0
      do i=1,nh
         mmtmp=oporder(i)
         optmp=opstring(mmtmp)
         do j=0,dxl-1
            c0=clusterflog(vertexlist(mmtmp*dxl+j,1),1)
            clusterflog(c0,2)=clusterflog(c0,2)+1
            if (maxc<clusterflog(c0,2)) then
               maxc=clusterflog(c0,2)
               maxc_idx=c0
            endif
         enddo
      enddo
      !print*, "clusterflog",dble(maxc)/dble(nh*dxl),maxc_idx

   endif

   !print*, "clusterflog",clusterflog(0,0),clusterflog(0,1),offoporder(0),digoporder(0),clusterbtm

end subroutine clustercalprob
!==================================================!


!==================================================!

subroutine joincluster(c_idx_1,c_idx_0)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,k,l,c_idx_0,c_idx_1,c_idx_t,c_idx_t0,c_idx_t1
   integer, allocatable :: test(:)

   !allocate(test(0:clusterflog(0,0)))
   !test(:)=0d0
   
   c_idx_t0=clusterflog(c_idx_0,1)
   c_idx_t1=clusterflog(c_idx_1,1)
   if (c_idx_t0==c_idx_t1) then
   else
      !print*, "joincluster",c_idx_0,c_idx_1,c_idx_t, clusterflog(0,1)
      !print*, "joincluster1",clusterflog(0:clusterflog(0,0),1)
      do i=1,clusterflog(0,0)
         if (clusterflog(i,1)==c_idx_t1) then
            clusterflog(i,1)=c_idx_t0
            clusterflog(i,0)=clusterflog(c_idx_t0,0)
         endif
         !test(clusterflog(i,1))=1
      enddo
      clusterflog(0,1)=clusterflog(0,1)-1
      !print*, "joincluster2",clusterflog(0:clusterflog(0,0),1)
      !print*, "----------------------------------------------"
      !if (clusterflog(0,1)/=sum(test)) then
      !   print*,"clusterflog(0,1)<=0",c_idx_0,c_idx_1
      !   print*,"clusterflog(0,1)<=0",c_idx_t0,c_idx_t1,clusterflog(0,1)
      !   print*, "clusterflog",clusterflog(0:clusterflog(0,0),1)
      !   print*, "test",test(0:clusterflog(0,0))
      !   pause
      !endif
   endif

end subroutine joincluster
!==================================================!

subroutine clusterfliper()
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,k,p,optmp,btmp,sigtmp,typtmp,up,dw,d,prid,c1,c2,leg_tmp,bstmp
   integer :: tmp,mmtmp,phase,dealtyp_tmp,op_per,op_cur,opsum,opsmnew,opsmold
   integer :: cur0,cur1,cur2,cur3,s0,s1,typ,c0
   integer, allocatable :: vertexleg(:,:)
   integer, allocatable :: flipspin(:)
   allocate(vertexleg(0:dxl-1,0:3))
   vertexleg(:,:)=0d0
   allocate(flipspin(nn))
   flipspin(:)=0d0

   !print*, "clusterfliper",clusterflog(0:clusterflog(0),0)

   do i=1, nh
      mmtmp=oporder(i)
      optmp=opstring(mmtmp)
      sigtmp=mod(optmp,2)
      dealtyp_tmp=dealtyp(i)
      leg_tmp=mod(leg_tmp,mxl) 
      bstmp=int(leg_tmp/2)
      typ=int(mod(optmp,8)/2)+1
      !print*, "clusterfliper",optmp,sigtmp

       cur0=0
       cur1=0
       do k=0,mxl-1
          s1=int((vertexspin(k,mmtmp)+1d0)*0.5d0)
          s0=int((vertexspin(k,mmtmp)*opstfp(mmtmp,k)+1d0)*0.5d0)

          cur0=cur0+s0*2**k
          cur1=cur1+s1*2**k
       enddo

      do j=0,dxl-1
         vertexleg(j,0)=mmtmp*dxl+j
         if (vertexlist_map(vertexleg(j,0))<0) cycle

         vertexleg(j,1)=vertexlist(vertexleg(j,0),1)
         c0=vertexleg(j,1)
         clusterflog(c0,2)=clusterflog(c0,2)+1

         if (j>=mxl) then

            !print*, vertexleg(j,1),vertexleg(mod(j,mxl),1)&
            !&, clusterflog(vertexleg(j,1),0),clusterflog(vertexleg(mod(j,mxl),1),0)

            vertexleg(j,2)=vertexspin(mod(j,mxl),mmtmp)
            if (vertexleg(j,1)==0) then
               phase=1d0
            else
               if (mod(clusterflog(vertexleg(j,1),0),2)==0) then
                  phase=1
               else
                  phase=-1
               endif
            endif
            vertexleg(j,3)=vertexspin(mod(j,mxl),mmtmp)*phase

            if (sigtmp==0) then
               vertexleg(mod(j,mxl),2)=vertexleg(j,2)
            else
               vertexleg(mod(j,mxl),2)=opstfp(mmtmp,mod(j,mxl))*vertexleg(j,2)
            endif
            if (vertexleg(mod(j,mxl),1)==0d0) then
               phase=1d0
            else
               if (mod(clusterflog(vertexleg(mod(j,mxl),1),0),2)==0) then
                  phase=1
               else
                  phase=-1
               endif
            endif
            vertexleg(mod(j,mxl),3)=vertexleg(mod(j,mxl),2)*phase

            vertexspin(mod(j,mxl),mmtmp)=vertexleg(j,3)

         endif
      enddo
      
      opsum=0d0
      do j=0,mxl-1
         opstfp(mmtmp,j)=vertexleg(j+mxl,3)*vertexleg(j,3)
         if (opstfp(mmtmp,j)==-1) opsum=opsum+1
      enddo

      if (opsum==0) then
         opsmnew=0d0
      elseif (opsum==2) then
         opsmnew=1d0
      else
         print*,"opsum",opsum
         pause
      endif
      if (sigtmp/=opsmnew) then
         opstring(mmtmp)=ieor(opstring(mmtmp),1)
      else
      endif

       cur2=0
       cur3=0
       do k=0,mxl-1
          s1=int((vertexspin(k,mmtmp)+1d0)*0.5d0)
          s0=int((vertexspin(k,mmtmp)*opstfp(mmtmp,k)+1d0)*0.5d0)

          cur2=cur2+s0*2**k
          cur3=cur3+s1*2**k
       enddo

      if (weightable(cur0,cur1,typ)==weightable(cur2,cur3,typ) .and. weightable(cur0,cur1,typ)/=0d0) then
         !print*,weightable(cur0,cur1,typ),weightable(cur2,cur3,typ)
      else
         print*,weightable(cur0,cur1,typ),cur0,cur1,typ
         print*,weightable(cur2,cur3,typ),cur2,cur3,typ
         pause
      endif

   enddo

   do i=1,nn
      if (frstspinop(i)==-1) then
         if ( ran()*(2)<1 ) then
            spin(i)=-spin(i)
         endif
      else
         tmp=vertexlist(frstspinop(i),1)
         if (mod(clusterflog(tmp,0),2)==1 .and. tmp/=0d0) then
            !print*, "flip spin",i,spin(i)
            spin(i)=-spin(i)
         endif
      endif
   enddo

   !do c0=1,clusterflog(0,0)
   !   if (clusterflog(c0,2)/=0) then
   !      print*, "clusterflog",clusterflog(c0,2)/dble(nh*dxl)
   !   endif
   !enddo
   !print*, "+++++++++++++++++++++++++++++++++++++++++++++"

   !call spinchecker()

end subroutine clusterfliper
!==================================================!

!==================================================!

subroutine clustermaker(legnum,dealsign,tt)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,k,legmax,legnum,dealsign,dv1,dv2,dv3,dv4,tt,udd,legcounter
   integer :: tmp3,sitin,act,test1,test2,testmark1,testmark2
   real(8) :: tmp1,tmp2
   real(8), external :: ran
   integer, allocatable :: legorder(:)
   real(8), allocatable :: legranod(:)
   allocate(legorder(0:dxl-1))
   allocate(legranod(0:dxl-1))

   legorder(:)=-1d0
   legranod(:)=beta
   legcounter=0d0
   legmax=legnum/2-1
   dv1=0d0
   dv2=0d0
   dv3=0d0
   dv4=0d0

   do i=0,mxl-1
      dv1=i
      if (vertexlist(dxl*mmt+dv1,0)==mrk0 .or. vertexlist(dxl*mmt+dv1,0)==mrk1) then
         if (vertexlist_map(dxl*mmt+dv1)==-1) then
            print*,"Error",dv1,typt
            pause
         endif
      endif
      
      dv1=i+mxl
      if (vertexlist(dxl*mmt+dv1,0)==mrk0 .or. vertexlist(dxl*mmt+dv1,0)==mrk1) then
         if (vertexlist_map(dxl*mmt+dv1)==-1) then
            print*,"Error",dv1,typt
            pause
         endif
      endif
   enddo
   dv1=0d0
   !---------------------test----------------------!

   if (dealsign==0) then
      !print*,"dealsign==0",vt,typt,legmax,length,mrk0
      do i=0,legmax
         dv1=i
         call clustermkr1(dv1,dealsign)
         dv1=i+mxl
         call clustermkr1(dv1,dealsign)
      enddo

      update_counter=update_counter+1

   elseif (dealsign==1) then
      !print*,"dealsign==1",vt,typt,legmax,length,mrk0
      do i=0,mxl-1
         if (vertexlist_map(dxl*mmt+i)<0) exit
         if (vertexlist(dxl*mmt+i,0)==mrk0) then
            legorder(legcounter)=i
            legcounter=legcounter+1
         endif

         if (vertexlist(dxl*mmt+i+mxl,0)==mrk0) then
            legorder(legcounter)=i+mxl
            legcounter=legcounter+1
         endif
      enddo
      
      if (legcounter>0) then
         cmplsg(:)=0d0
         selfcest=0d0
         tmp1=0d0
         tmp2=0d0

         do i=0,legnum-1
            dv1=legorder(i)
            !print*,dv1,dv2
            if (dv1==-1) exit
            if (cmplsg(0)==1 .and. cmplsg(1)==1) exit
            if (vertexlist(dxl*mmt+dv1,0)/=mrk0) cycle
            if (dv1>=0 .and. dv1<=mxl-1) then
               udd=0
            elseif (dv1>=mxl .and. dv1<=dxl-1) then
               udd=1
            endif
            if (cmplsg(udd)==1) cycle

            legcounter=dealsign

            !if (typt<=2) then
               !if (dealtyp(tauscale(mmt))==-1) then
                  !if (ran()<slpb) then
                  !if (mmt==mm0) then
                     !dealtyp(tauscale(mmt))=1
                  !else
                     !dealtyp(tauscale(mmt))=0
                  !endif
               !endif
               !legcounter=dealtyp(tauscale(mmt))
            !else
               !legcounter=1
            !endif
            !if (legcounter/=1 .and. legcounter/=0) then
               !print*,"legcounter",legcounter
               !pause
            !endif

            !if (dealtyp(tauscale(mmt))==-1) call initdealtyp(bt,typt,mmt)
            !legcounter=dealtyp(tauscale(mmt))
            
            !if (legcounter==0d0) call clustermkr1(dv1,udd)

            do j=0,legmax
               dv2=mod(j+udd*mxl,dxl)
               if (cmplsg(udd)==0d0) then
                  !print*,"mkr2",udd,j
                  call clustermkr2(dv2,dealsign)
               endif
            enddo
            cmplsg(udd)=1d0

         enddo
      endif
      update_counter=update_counter+1
   elseif (dealsign==2) then
      !print*,"dealsign==2",vt,typt,legmax,length,mrk0
      !print*,"mrk_bef",mmt,vertexlist(mmt*dxl:mmt*dxl+dxl-1,0)
      !print*,"lbl_bef",mmt,vertexlist(mmt*dxl:mmt*dxl+dxl-1,1)
      !print*,"ink_bef",mmt,spingrp(:,mmt,0)
      !print*,"grp_bef",mmt,spingrp(:,mmt,1)
      do i=0,mxl-1
         if (vertexlist_map(dxl*mmt+i)<0) exit
         if (vertexlist(dxl*mmt+i,0)==mrk0) then
            legorder(legcounter)=i
            legcounter=legcounter+1
         endif

         if (vertexlist(dxl*mmt+i+mxl,0)==mrk0) then
            legorder(legcounter)=i+mxl
            legcounter=legcounter+1
         endif

         clustervislog(i,:)=0d0
         clustervislog(i+mxl,:)=0d0
      enddo

      if (legcounter>0) then
         cmplsg(:)=0d0
         selfcest=0d0
         tmp1=0d0
         tmp2=0d0

         do i=0,legnum-1
            dv1=legorder(i)
            if (dv1==-1) exit
            if (cmplsg(0)==1 .and. cmplsg(1)==1) exit
            if (vertexlist(dxl*mmt+dv1,0)/=mrk0) cycle
            if (dv1>=0 .and. dv1<=mxl-1) then
               udd=0
            elseif (dv1>=mxl .and. dv1<=dxl-1) then
               udd=1
            endif
            !sitin=mod(dv1,mxl)
            if (dv1>=mxl) then
               sitin=spingrp(dv1,mmt,0)
            else
               sitin=dv1
            endif
            act=spingrp(dv1,mmt,1)
            !print*,"act",act,mmt,"dv1",dv1,sitin

            call clustermkr1(dv1,dealsign)
            do j=1,dxl-1
               tmp3=mod(sitin+j,dxl)
               if (spingrp(tmp3,mmt,1)==act .and. clustervislog(tmp3,0)==0d0) then
                  !print*,"====",tmp3,spingrp(tmp3,mmt,1),act,mmt
                  !print*,"mrk_mid",mmt,vertexlist(mmt*dxl:mmt*dxl+dxl-1,0)
                  !print*,"lbl_mid",mmt,vertexlist(mmt*dxl:mmt*dxl+dxl-1,1)
                  call clustermkr3(tmp3,dealsign)
                  !print*, "----------------------------------------------"
               endif
            enddo
            !print*, "clustermaker++++++++++++++++++++++++++++++++++++"
         enddo
      endif
      !print*,"mrk_aft",mmt,vertexlist(mmt*dxl:mmt*dxl+dxl-1,0)
      !print*,"lbl_aft",mmt,vertexlist(mmt*dxl:mmt*dxl+dxl-1,1)
      !print*,"ink_aft",mmt,spingrp(:,mmt,0)
      !print*,"grp_aft",mmt,spingrp(:,mmt,1)
      update_counter=update_counter+1
   elseif (dealsign==4) then
      !print*,"clustermkr4"
      do i=0,mxl-1
         dv1=i
         call clustermkr4(dv1,dealsign)
         dv1=i+mxl
         call clustermkr4(dv1,dealsign)
      enddo
   else
      print*,"error",dealsign
      pause
   endif

   !call sppcchecker()

end subroutine clustermaker
!==================================================!

!==================================================!

subroutine clustermkr1(dv1,uds)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,dv1,dv2,tt,uds,ud

   !legcounter=0d0
   !leg=0d0
   !dv1=0d0
   if (uds==0) then
      dv2=spingrp(dv1,mmt,0)
   elseif (uds==2) then
      !dv2=mod(dv1+mxl,dxl)
      dv2=spingrp(dv1,mmt,0)
   else
      pause
   endif
   !tt=int(mod(opstring(mmt),8)/2)+1
   !dv3=0d0
   !dv4=0d0
   clustervislog(dv1,0)=1d0
   clustervislog(dv2,0)=1d0
   
   if (vertexlist(vt+dv1,0)==mrk0) then
      vertexlist(vt+dv1,0)=0
      call clusterbuildtab(mmt,-1,0)
      length=length-1
      !print*,"diagonal clustermaking",vt+dv1,vt+dv2
      if (vertexlist(vt+dv2,0)==mrk0) then
         vertexlist(vt+dv2,0)=0
         call clusterbuildtab(mmt,-1,0)
         length=length-1
      elseif (vertexlist(vt+dv2,0)==mrk1) then
         vertexlist(vt+dv2,0)=0
         call clusterbuildtab(mmt,-1,0)
         length=length-1
      else
         vertexlist(vt+dv2,0)=0
         call vertexlistmarker(vt+dv2)
         call clusterluch(vt,dv2)
         !update_counter=update_counter+1
      endif
   endif

end subroutine clustermkr1
!==================================================!

!==================================================!

subroutine clustermkr2(dv1,uds)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,dv1,tt,uds,mmd

   !dv1=0d0
   !dv2=0d0
   !dv3=0d0
   !dv4=0d0

   mmd=int(vertexlist_map(vt+dv1)/(dxl))
   !cmplsg(uds+2)=cmplsg(uds+2)+1

   if (vertexlist(vt+dv1,0)==mrk0) then
      vertexlist(vt+dv1,0)=0
      call clusterbuildtab(mmt,-1,0)
      length=length-1
      !vertexlist(vt+dv1,1)=vertexlist(vt+dv1,1)+1
   elseif (vertexlist(vt+dv1,0)==mrk1) then
      vertexlist(vt+dv1,0)=0
      call clusterbuildtab(mmt,-1,0)
      length=length-1
      !vertexlist(vt+dv1,1)=vertexlist(vt+dv1,1)+1
   elseif (vertexlist(vt+dv1,0)==0) then
      call vertexlistmarker(vt+dv1)
      call clusterluch(vt,dv1)
   else
      print*,"missing mkr2",vertexlist(vt+dv1,0)
   endif

   !if (int(vertexlist_map(vt+dv1)/(dxl))/=mmt) cmplsg(uds+2)=cmplsg(uds+2)+1

end subroutine clustermkr2
!==================================================!

!==================================================!

subroutine clustermkr3(dv1,uds)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,dv1,dv2,tt,uds,ud

   !print*,"clustermkr3"
   !pause
   !legcounter=0d0
   !leg=0d0
   !dv1=0d0
   !dv2=mod(dv1+mxl,dxl)
   dv2=spingrp(dv1,mmt,0)
   !tt=int(mod(opstring(mmt),8)/2)+1
   !dv3=0d0
   !dv4=0d0
   !print*,"cluster3",vt,dv1,vertexlist(vt+dv1,0),dv2,vertexlist(vt+dv2,0)
   clustervislog(dv1,0)=1d0
   clustervislog(dv2,0)=1d0
   
   if (vertexlist_map(vt+dv1)==vt+dv2) then
      if (vertexlist(vt+dv1,0)==mrk0 .or. vertexlist(vt+dv1,0)==mrk1) then
         if (vertexlist(vt+dv2,0)==mrk0 .or. vertexlist(vt+dv2,0)==mrk1) then
            vertexlist(vt+dv1,0)=0d0
            vertexlist(vt+dv2,0)=0d0
            call clusterbuildtab(mmt,-2,0)
            length=length-2
         else
            print*,"error clustermkr3 a"
            pause
         endif
      elseif (vertexlist(vt+dv1,0)==0) then
         if (vertexlist(vt+dv2,0)==mrk0 .or. vertexlist(vt+dv2,0)==mrk1) then
            print*,"error clustermkr3 b",dv2,dealtyp(tauscale(int(vt/dxl)))
            print*,"error clustermkr3 b",vertexlist(vt+mxl:vt+dxl-1,0)
            print*,"error clustermkr3 b",vertexlist(vt:vt+mxl-1,0)
            pause
         elseif (vertexlist(vt+dv2,0)==0) then
            vertexlist(vt+dv1,0)=0d0
            call vertexlistmarker(vt+dv1)
            vertexlist(vt+dv2,0)=0d0
            call vertexlistmarker(vt+dv2)
         endif
      endif
   else
      !print*,"cluster3",vt,dv1,vertexlist(vt+dv1,0),dv2,vertexlist(vt+dv2,0)

      if (vertexlist(vt+dv1,0)==mrk0) then
         vertexlist(vt+dv1,0)=0
         call clusterbuildtab(mmt,-1,0)
         length=length-1
         !print*,"cluster3_mute",vt,dv1,mrk0
      elseif (vertexlist(vt+dv1,0)==mrk1) then
         vertexlist(vt+dv1,0)=0
         call clusterbuildtab(mmt,-1,0)
         length=length-1
         !print*,"cluster3_mute",vt,dv1,mrk1
      else
         vertexlist(vt+dv1,0)=0
         call vertexlistmarker(vt+dv1)
         call clusterluch(vt,dv1)
         !print*,"cluster3_ove",vt,dv1
         !update_counter=update_counter+1
      endif
   
      !print*,"cluster3",vt,dv1,vertexlist(vt+dv1,0),dv2,vertexlist(vt+dv2,0)

      if (vertexlist(vt+dv2,0)==mrk0) then
         vertexlist(vt+dv2,0)=0
         call clusterbuildtab(mmt,-1,0)
         length=length-1
         !print*,"cluster3_mute",vt,dv2,mrk0
      elseif (vertexlist(vt+dv2,0)==mrk1) then
         vertexlist(vt+dv2,0)=0
         call clusterbuildtab(mmt,-1,0)
         length=length-1
         !print*,"cluster3_mute",vt,dv2,mrk1
      else
         vertexlist(vt+dv2,0)=0
         call vertexlistmarker(vt+dv2)
         call clusterluch(vt,dv2)
         !print*,"cluster3_ove",vt,dv2
         !update_counter=update_counter+1
      endif
   endif

   
end subroutine clustermkr3
!==================================================!


!==================================================!

subroutine clustermkr4(dv1,uds)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,dv1,dv2,tt,uds,ud

   
   if (vertexlist(vt+dv1,0)==mrk0 .or. vertexlist(vt+dv1,0)==mrk1) then
      vertexlist(vt+dv1,0)=0
      call vertexlistmarker(vt+dv1)
      call clusterbuildtab(mmt,-1,0)
      length=length-1
   endif

end subroutine clustermkr4
!==================================================!

!==================================================!

subroutine clusterluch(va,dv2)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,dv1,dv2,dv3,dv4,leg,ud,va,d,tt,bv,demo,sitin,sitcr,m,dv5,dv6
   integer :: cont,lv3,lpidx,lpnum
   integer, allocatable :: sumlog(:)
   integer, allocatable :: dvgrp(:,:)
   allocate(sumlog(0:5))
   allocate(dvgrp(0:mxl-1,0:2))

   dv1=0d0
   !dv2=0d0
   dv3=0d0
   dv4=0d0
   dvgrp(:,:)=-1d0
   !print*,"clusterluch",va,dv2
   vv=vertexlist_map(va+dv2)
   mmv=int(vv/(dxl))
   dealtyp_v=dealtyp(tauscale(mmv))
   dv3=mod(vv,dxl)
   lv3=mod(dv3,mxl)
   vv=vv-dv3
   bv=int(opstring(mmv)/8)
   tt=int(mod(opstring(mmv),8)/2)+1
   !print*, "mmv", mmv,vertexlist(vv+dv3,0)

   demo=0d0
   cluster_lunch=0d0
   do
      if (dv3>=0 .and. dv3<=mxl-1) then
         ud=0
      elseif (dv3>=mxl .and. dv3<=dxl-1) then
         ud=1
      endif
      !tt=int(mod(opstring(mmv),8)/2)+1
      vv=mmv*dxl
      leg=0d0
      !sumlog=sum(vertexlist(dxl*mmv+ud*mxl:dxl*mmv+(ud+1)*mxl-1,1))
      sumlog=0d0
      !if (vertexlist(vertexlist_map(vv+dv4),0)==mrk1) then
      !   if (opertyp(tauscale(int(vertexlist_map(vv+dv4)/(dxl))))==0 .and. opertyp(tauscale(mmv))==0) then
      !      print*,"vertexlist_map(vv+dv4),0)==mrk1 .or. vertexlist_map(vv+dv4),0)==mrk0"
      !      print*,vertexlist(vertexlist_map(vv+dv4),0),mrk0,mrk1
      !      print*,opertyp(tauscale(mmv)),opertyp(tauscale(int(vertexlist_map(vv+dv4)/(dxl))))
      !      pause
      !   endif
      !endif

!--------------------------ready-----------------------------------------------------!
      !print*,"973",d

      if (dealtyp_v==2) then
         leg=legn(tt,1)
         clustervislog(:,1)=0d0

         !do i=0,mxl-1
         !   if (vertexlist_map(dxl*mmv+ud*mxl+i)<0) exit
         !   if (vertexlist(dxl*mmv+ud*mxl+i,0)==mrk0) sumlog(0)=sumlog(0)+1
         !   if (vertexlist(dxl*mmv+ud*mxl+i,0)==mrk1) sumlog(1)=sumlog(1)+1
         !   if (vertexlist(dxl*mmv+ieor(ud,1)*mxl+i,0)==mrk0) sumlog(3)=sumlog(3)+1
         !   if (vertexlist(dxl*mmv+ieor(ud,1)*mxl+i,0)==mrk1) sumlog(4)=sumlog(4)+1
         !   !print*,sumlog
         !enddo
         !sumlog(2)=sumlog(0)+sumlog(1)
         !sumlog(5)=sumlog(3)+sumlog(4)

!--------------------------ready-----------------------------------------------------!

         clustervislog(dv3,1)=1d0
         if (vertexlist(vv+dv3,0)==mrk0) then
            vertexlist(vv+dv3,0)=0
            call vertexlistmarker(vv+dv3)
            call clusterbuildtab(mmv,-1,0)
            length=length-1
         elseif (vertexlist(vv+dv3,0)==mrk1) then
            vertexlist(vv+dv3,0)=0
            call vertexlistmarker(vv+dv3)
            call clusterbuildtab(mmv,-1,0)
            length=length-1
         else
            !sitin=mod(dv3,mxl)
            if (dv3>=mxl) then
               sitin=spingrp(dv3,mmv,0)
            else
               sitin=dv3
            endif
            lpidx=spingrp(dv3,mmv,1)
            lpnum=spingrp(lpidx,mmv,2)
            !dv4=mod(dv3+mxl,dxl)
            dv4=spingrp(dv3,mmv,0)
            clustervislog(dv4,1)=1d0
            !print*,lpidx,lpnum

            if (lpnum==1) then
               if (vertexlist(vv+dv4,0)==mrk0 .or. vertexlist(vv+dv4,0)==mrk1) then
                  vertexlist(vv+dv4,0)=0
                  call vertexlistmarker(vv+dv3)
                  call clusterbuildtab(mmv,-1,0)
                  length=length-1
               else
                  vertexlist(vv+dv3,0)=mrk1
                  call vertexlistmarker(vv+dv3)
                  call clusterbuildtab(mmv,1,1)
                  length=length+1
               endif
            else
               cont=0d0
               dvgrp(:,:)=-1d0
               if (vertexlist(vv+dv4,0)==mrk0 .or. vertexlist(vv+dv4,0)==mrk1) then
                  cont=cont+1
                  dvgrp(0,0)=dv3
                  dvgrp(0,1)=dv4
               endif

               do m=1,dxl-1
                  sitcr=mod(sitin+m,mxl)
                  if (spingrp(sitcr,mmv,1)==lpidx .and. clustervislog(sitcr,1)==0d0) then
                     dv5=sitcr
                     dv6=spingrp(dv5,mmv,0)
                     clustervislog(dv5,1)=1d0
                     clustervislog(dv6,1)=1d0
                     if (vertexlist(vv+dv5,0)==mrk0 .or. vertexlist(vv+dv5,0)==mrk1) then
                        cont=cont+1
                        dvgrp(m,0)=dv5
                     endif
                     if (vertexlist(vv+dv6,0)==mrk0 .or. vertexlist(vv+dv6,0)==mrk1) then
                        cont=cont+1
                        dvgrp(m,1)=dv6
                     endif
                  endif
               enddo

               if (cont==2*lpnum-1) then
                  !print*,cont
                  !pause
                  !vertexlist(vv+dv3,0)=0
                  !vertexlist(vv+dv4,0)=0
                  !vertexlist(vv+dv5,0)=0
                  !vertexlist(vv+dv6,0)=0
                  !vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1

                  call vertexlistmarker(vv+dv3)
                  do m=0,mxl-1
                     if (dvgrp(m,0)==-1 .and. dvgrp(m,1)==-1) cycle
                     dv5=dvgrp(m,0)
                     if (vertexlist(vv+dv5,0)/=0) then
                        vertexlist(vv+dv5,0)=0
                        call clusterbuildtab(mmv,-1,0)
                        length=length-1
                     endif
                     dv6=dvgrp(m,1)
                     if (vertexlist(vv+dv6,0)/=0) then
                        vertexlist(vv+dv6,0)=0
                        call clusterbuildtab(mmv,-1,0)
                        length=length-1
                     endif
                  enddo
                  !print*,"singularity"
               else
                  vertexlist(vv+dv3,0)=mrk1
                  call vertexlistmarker(vv+dv3)
                  call clusterbuildtab(mmv,1,1)
                  length=length+1
               endif
            endif
         endif
         if (mmv==mmt) selfcest=selfcest+1d0
         exit
      elseif (dealtyp_v==1) then
         leg=legn(tt,1)
         do i=0,mxl-1
            if (vertexlist_map(dxl*mmv+ud*mxl+i)<0) exit
            if (vertexlist(dxl*mmv+ud*mxl+i,0)==mrk0) sumlog(0)=sumlog(0)+1
            if (vertexlist(dxl*mmv+ud*mxl+i,0)==mrk1) sumlog(1)=sumlog(1)+1
         enddo
         sumlog(2)=sumlog(0)+sumlog(1)
!--------------------------ready-----------------------------------------------------!
         if (vertexlist(vv+dv3,0)==mrk0) then
            vertexlist(vv+dv3,0)=0
            call vertexlistmarker(vv+dv3)
            call clusterbuildtab(mmv,-1,0)
            length=length-1
         elseif (vertexlist(vv+dv3,0)==mrk1) then
            vertexlist(vv+dv3,0)=0
            call vertexlistmarker(vv+dv3)
            call clusterbuildtab(mmv,-1,0)
            length=length-1
         else
            if (mmt==mmv) then
               if (sumlog(2)+1==leg) then
                  vertexlist(vv+ud*mxl:vv+ud*mxl+mxl-1,0)=0
                  call vertexlistmarker(vv+dv3)
                  call clusterbuildtab(mmv,-leg+1,0)
                  length=length-leg+1
                  update_counter=update_counter+1
               else
                  vertexlist(vv+dv3,0)=mrk1
                  call vertexlistmarker(vv+dv3)
                  call clusterbuildtab(mmv,1,1)
                  length=length+1
                  !if (vertexlist(vv+dv4,0)==mrk0) then
                  !   vertexlist(vv+dv3,0)=0
                  !   vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
                  !   vertexlist(vv+dv4,0)=0
                  !   length=length-1
                  !elseif (vertexlist(vv+dv4,0)==mrk1) then
                  !   vertexlist(vv+dv3,0)=0
                  !   vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
                  !   vertexlist(vv+dv4,0)=0
                  !   length=length-1
                  !elseif (vertexlist(vv+dv4,0)==0) then
                  !   vertexlist(vv+dv3,0)=mrk1
                  !   vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
                  !   length=length+1
                  !else
                  !endif
               endif
            else
               if (sumlog(2)+1==leg) then
                  vertexlist(vv+ud*mxl:vv+ud*mxl+mxl-1,0)=0
                  call vertexlistmarker(vv+dv3)
                  call clusterbuildtab(mmv,-leg+1,0)
                  length=length-leg+1
                  update_counter=update_counter+1
               else
                  vertexlist(vv+dv3,0)=mrk1
                  call vertexlistmarker(vv+dv3)
                  call clusterbuildtab(mmv,1,1)
                  length=length+1
                  
                  !if (vertexlist(vv+dv4,0)==mrk0) then
                  !   vertexlist(vv+dv3,0)=0
                  !   vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
                  !   vertexlist(vv+dv4,0)=0
                  !   length=length-1
                  !elseif (vertexlist(vv+dv4,0)==mrk1) then
                  !   vertexlist(vv+dv3,0)=0
                  !   vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
                  !   vertexlist(vv+dv4,0)=0
                  !   length=length-1
                  !elseif (vertexlist(vv+dv4,0)==0) then
                  !   vertexlist(vv+dv3,0)=mrk1
                  !   vertexlist(vv+dv3,1)=vertexlist(vv+dv3,1)+1
                  !   length=length+1
                  !else
                  !endif
               endif
            endif
         endif
         if (mmv==mmt) selfcest=selfcest+1d0
         exit
      elseif (dealtyp_v==0) then
         call clusterluch_1in1out(dv3)
         if (cluster_lunch==1) then
            exit
         elseif (cluster_lunch==0) then
            cycle
         endif
      elseif (dealtyp_v==4) then
         !print*,"cluster dealtyp_v",vv+dv3,vv,dv3
         call vertexlistmarker(vv+dv3)
         exit
      endif
   enddo

end subroutine clusterluch
!==================================================!

subroutine clusterluch_1in1out(dv1)
   use configuration
   use vertexupdate
   implicit none
   integer :: i,dv1,dv2,tt,uds,ud,bv

   dv2=spingrp(dv1,mmv,0)
   if (vertexlist(vv+dv1,0)==mrk0) then
      vertexlist(vv+dv1,0)=0
      call vertexlistmarker(vv+dv1)
      call clusterbuildtab(mmv,-1,0)
      length=length-1
      cluster_lunch=1
   elseif (vertexlist(vv+dv1,0)==mrk1) then
      vertexlist(vv+dv1,0)=0
      call vertexlistmarker(vv+dv1)
      call clusterbuildtab(mmv,-1,0)
      length=length-1
      cluster_lunch=1
   else
      if (vertexlist(vv+dv2,0)==mrk0) then
         vertexlist(vv+dv1,0)=0
         call vertexlistmarker(vv+dv1)
         vertexlist(vv+dv2,0)=0
         call clusterbuildtab(mmv,-1,0)
         length=length-1
         cluster_lunch=1
      elseif (vertexlist(vv+dv2,0)==mrk1) then
         vertexlist(vv+dv1,0)=0
         call vertexlistmarker(vv+dv1)
         vertexlist(vv+dv2,0)=0
         call clusterbuildtab(mmv,-1,0)
         length=length-1
         cluster_lunch=1
      elseif (vertexlist(vv+dv2,0)==0) then
         vertexlist(vv+dv1,0)=mrk1
         call vertexlistmarker(vv+dv1)
         call clusterbuildtab(mmv,1,1)
         length=length+1
         cluster_lunch=1
      endif
   endif

end subroutine clusterluch_1in1out

!==================================================!

!==================================================!

subroutine clusterflbprb(prid)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,p,up,dw,ty,legmax,l,d,prid,k,sjaft,sjbef,skaft,skbef
   integer :: optmp,btmp,sigtmp,typtmp
   integer :: dnum,afts,bfrs,aftop,bfrop
   integer :: sigaft, sigbfr
   integer, allocatable :: spacecnt(:)

   clustersize=0d0
   allocate(spacecnt(nn))
   spacecnt=0d0

   pbcgcnt(:,:)=0d0

   dnum=0d0
   probnum=0d0
   wgtaft=1d0
   wgtbfr=1d0
   !nhtp(:)=0d0

   do i=1, nh
   enddo
   
end subroutine clusterflbprb
!==================================================!


!==================================================!

subroutine clusterbuilding()
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,k,l,leg_in,vo,vidx,lengts,clusternum,test,test2,dv,dtmp2,btmp2,typtmp2,mmtmp1,mmtmp2,optmp2
   integer :: st
   real(8) :: tautmp,tmp1,tmp2,tmp3,tmp4
   integer, allocatable :: space(:)
   real(8), external :: ran

   allocate(space(nn))
   space(:)=0d0
   clustermark=1
   mrk0=clustermark
   mrk1=mrk0+1
   length=0d0
   legcon=0d0

   mm0=int(v0/(dxl))
   op0=opstring(mm0)
   b0=int(op0/8)
   typ0=int(mod(op0,8)/2)+1
   dltyp0=dealtyp(tauscale(mm0))

   opvlog(0,:)=0d0
   opvlog(:,2:3)=0d0
   clb_cur=0
   clb_nxt=mod(clb_cur+1,2)
   !_____________________________________________________________
   !print*,"checker a"
   call clusterstarter(v0,vertexlist_map(v0))
   !print*,"checker b"
   call clusterstarter(vertexlist_map(v0),v0)
   !print*,"checker c"
   tmp1=vertexlist_map(v0)
   tmp3=int(opstring(int(vertexlist_map(v0)/(dxl)))/8)
   tmp2=v0
   tmp4=int(opstring(int(v0/(dxl)))/8)

   space(:)=0d0
   !call clusterbuildchecker(1)

   !print*,"length start",length,tmp1,tmp3,dltyp0
   !print*,"b0",b0,tmp2,tmp4
   !print*,"========================================="
   do while(length>0)

      if (length<0) then
         print*,"WARNING++++++++++length=",length,"+++++++++++++++++++++++"
      endif

      lengts=length

      !print*,"length",length

      clustermark=clustermark+1
      mrk0=clustermark
      mrk1=mrk0+1
      !call clusterbuildchecker(1)
      clb_cur=clb_nxt
      clb_nxt=mod(clb_cur+1,2)
      opvlog(0,clb_nxt)=0d0

      do i=1,opvlog(0,clb_cur)
         mmt=opvlog(i,clb_cur)

         vt=dxl*mmt
         opt=opstring(mmt)
         bt=int(opt/8)
         typt=int(mod(opt,8)/2)+1
         sigt=mod(opt,2)
         !if (dealtyp(tauscale(mmt))==-1) call initdealtyp(bt,typt,mmt)
         !dealtyp_t=opertyp(tauscale(mmt))
         dealtyp_t=dealtyp(tauscale(mmt))
         !print*,"mmt",mmt,dealtyp_t,opvlog(0,clb_cur)

         !print*,i,sigt,typt,vt,dealtyp_t,length

         call clustermaker(2*legn(typt,1),dealtyp_t,typt)
         !call clusterbuildchecker(0)
         !print*, "one step++++++++++++++++++++++++++++++++++++"
      enddo
      !print*,"one"
   enddo
   !call clusterbuildchecker(2)
   !print*,"========================================="

end subroutine clusterbuilding
!==================================================!

subroutine clusterstarter(vv1,vv2)
use configuration
use vertexupdate
integer :: i,j,k,l,leg_in,vo,vidx,lengts,clusternum,test,test2,dv,dtmp2,btmp2,typtmp2,mmtmp1,mmtmp2,optmp2
integer :: vv1,vv2

   mmtmp1=int(vv1/(dxl))
   dv=mod(vv1,dxl)
   mmtmp2=int(vv2/(dxl))
   optmp2=opstring(mmtmp2)
   btmp2=int(optmp2/8)
   typtmp2=int(mod(optmp2,8)/2)+1
   !if (dealtyp(tauscale(mmtmp2))==-1) call initdealtyp(btmp2,typtmp2,mmtmp2)
   !dtmp2=dealtyp(tauscale(mmtmp2))

   dtmp2=dealtyp(tauscale(mmtmp2))
   !print*,"starter", dtmp2, vv1,vv2,dealtyp(tauscale(mmtmp1)),dealtyp(tauscale(mmtmp2))
   !print*,"starter", dtmp2, vertexlist(vv1,1),vertexlist(vv2,1)

   !print*, "clusterstarter0",vv1,vv2
   !print*, "clusterstarter0",vertexlist(vv1,1),vertexlist(vv2,1)
   if (dtmp2>=1) then
      call clusterluch(dxl*mmtmp1,dv)
   else
      vertexlist(vv2,0)=mrk1
      call vertexlistmarker(vv2)
      call clusterbuildtab(mmtmp2,1,1)
      length=length+1
   endif
   !print*, "clusterstarter1",vv1,vv2
   !print*, "clusterstarter1",vertexlist(vv1,1),vertexlist(vv2,1)
   !print*, "clusterstarter1",vertexlist(dxl*mmtmp1:dxl*mmtmp1+dxl-1,0)
   !print*, "clusterstarter1",vertexlist(vv1,0),vertexlist(vertexlist_map(vv1),0)
   !print*, "clusterstarter2",vertexlist(dxl*mmtmp2:dxl*mmtmp2+dxl-1,0)
   !print*, "clusterstarter2",vertexlist(vv2,0),vertexlist(vertexlist_map(vv2),0)

end subroutine clusterstarter
!==================================================!
!==================================================!
subroutine vertexlistmarker(v_tmp)
   use configuration
   use vertexupdate
   implicit none

   integer :: v_tmp
   !vertexlist(v_tmp,1)=vertexlist(v_tmp,1)+1
   !print*,"vertexlistmarker",v_tmp,vertexlist(v_tmp,1)
   !if (vertexlist(v_tmp,1)>1) then
   !   pause
   !endif
   if (vertexlist(v_tmp,1)==0d0) then
      vertexlist(v_tmp,1)=marker
   else
      print*,"============================================"
      print*,"vertexlistmarker error",marker,v_tmp,vertexlist(v_tmp,1)
      print*,"vertexlistmarker error","mm=",int(vertexlist_map(v_tmp)/dxl),"leg=",mod(v_tmp,dxl)
      print*, int(v_tmp/dxl),int(vertexlist_map(v_tmp)/dxl)
      print*, mod(v_tmp,dxl), spingrp(mod(v_tmp,dxl),int(v_tmp/dxl),:),int(v_tmp/dxl),dealtyp(tauscale(int(v_tmp/dxl)))
      print*,"smt error",mrk0,mrk1,mmt,mmv,mod(v_tmp,dxl),mod(vertexlist(v_tmp,1),dxl)
      print*,"============================================"
      print*,"smt error",vertexlist(mmt*dxl+mxl:mmt*dxl+dxl-1,0)
      print*,"smt error",vertexlist(mmt*dxl+mxl:mmt*dxl+dxl-1,1)
      print*,"smt error",spingrp(mxl:dxl-1,mmt,1)
      print*,"smt error",spingrp(mxl:dxl-1,mmt,0)
      print*,"++++++++++++++++++++++++++++++++++++++++++++"
      print*,"smt error",vertexlist(mmt*dxl:mmt*dxl+mxl-1,0)
      print*,"smt error",vertexlist(mmt*dxl:mmt*dxl+mxl-1,1)
      print*,"smt error",spingrp(0:mxl-1,mmt,1)
      print*,"smt error",spingrp(0:mxl-1,mmt,0)
      print*,"============================================"
      print*,"smt error",vertexlist(mmv*dxl+mxl:mmv*dxl+dxl-1,0)
      print*,"smt error",vertexlist(mmv*dxl+mxl:mmv*dxl+dxl-1,1)
      print*,"smt error",spingrp(mxl:dxl-1,mmv,1)
      print*,"smt error",spingrp(mxl:dxl-1,mmv,0)
      print*,"++++++++++++++++++++++++++++++++++++++++++++"
      print*,"smt error",vertexlist(mmv*dxl:mmv*dxl+mxl-1,0)
      print*,"smt error",vertexlist(mmv*dxl:mmv*dxl+mxl-1,1)
      print*,"smt error",spingrp(0:mxl-1,mmv,1)
      print*,"smt error",spingrp(0:mxl-1,mmv,0)
      print*,"============================================"
      pause
   endif

end subroutine vertexlistmarker
!==================================================!
!==================================================!
subroutine clusterbuildtab(mmx,num,record_sign)
   use configuration
   use vertexupdate
   implicit none

   integer :: mmx,num,record_sign
   
   if (record_sign==1) then
      !print*, "clb_nxt",clb_nxt
      if (num>0 .and. opvlog(tauscale(mmx),3)/=mrk1) then
         opvlog(0,clb_nxt)=opvlog(0,clb_nxt)+1
         opvlog(opvlog(0,clb_nxt),clb_nxt)=mmx
         opvlog(tauscale(mmx),3)=mrk1
      else
      endif
   endif
   opvlog(tauscale(mmx),2)=opvlog(tauscale(mmx),2)+num

end subroutine clusterbuildtab
!==================================================!

!==================================================!

subroutine clusterbuildchecker(s)
   use configuration
   use vertexupdate
   implicit none

   integer :: i,j,k,l,checkcounter,checkcounter2,checkcounter3,s,test
   integer :: test1,test2

   checkcounter=0
   checkcounter2=0
   checkcounter3=0
   do j=0,mm-1
      if (opvlog(j,2)<0 .and. j<=nh) then
         print*,"ERROR","opvlog(j,2)<0",oporder(j),opvlog(j,2)
         pause
      elseif (opvlog(j,2)>0) then
         !if (s==1) print*,"non-zero",oporder(j),opvlog(j,2),dealtyp(oporder(j))
         checkcounter2=checkcounter2+1
      endif
      do k=0,dxl-1
         i=dxl*j+k
         if (vertexlist_map(i)<0) cycle
         !if (vertexlist(i,1)/=vertexlist(vertexlist_map(i),1) .or. vertexlist(i,1)>1) then
         if (vertexlist(i,1)/=vertexlist(vertexlist_map(i),1)) then
            print*,"Building ERROR",vertexlist(i,1),vertexlist(vertexlist_map(i),1),j,k,i,vertexlist_map(i)
            print*,"Building ERROR",dealtyp(tauscale(j)),dealtyp(tauscale(int(vertexlist_map(i)/dxl)))
            pause
         endif
         if (vertexlist(i,0)==mrk1) then
            checkcounter=checkcounter+1
         elseif (vertexlist(i,0)==mrk0) then
            checkcounter=checkcounter+1
         endif

         if (dealtyp(tauscale(j))==2 .and. s==2) then
            test=vertexlist(i,1)
            if (test/=vertexlist(dxl*j,1) .or. &
               &test/=vertexlist(dxl*j+1,1) .or. &
               &test/=vertexlist(dxl*j+2,1) .or. &
               &test/=vertexlist(dxl*j+3,1)&
            &) then
               print*,"ERROR","dealtyp(tauscale(j))==2",dxl*j,dxl*j+1,dxl*j+2,dxl*j+3,j
               print*,"ERROR","dealtyp(tauscale(j))==2",vertexlist(dxl*j:dxl*j+dxl-1,1)
               pause
            endif
         endif
         

      enddo

      if (opstring(j)/=0d0 .and. sum(vertexlist(j*dxl:j*dxl+dxl-1,0))==0d0 .and. &
      &dealtyp(tauscale(j))==2) then
         !if (s==0) print*,"check",j
         test1=-2
         test2=-2
         do i=0,dxl-1
            if (spingrp(i,j,1)==1 .and. test1==-2) then
               test1=vertexlist(j*dxl+i,1)
            endif
            if (spingrp(i,j,1)==2 .and. test2==-2) then
               test2=vertexlist(j*dxl+i,1)
            endif
         enddo
         !if (s==0) print*,"check",j,test1,test2
         do i=0,dxl-1
            if (test1/=-2 .and. spingrp(i,j,1)==1) then
               if (test1/=vertexlist(j*dxl+i,1)) then
                  print*,"smt error t1",mrk0,mrk1
                  print*,"smt error t1",test1,j
                  print*,"smt error t1",vertexlist(j*dxl+mxl:j*dxl+dxl-1,0)
                  print*,"smt error t1",vertexlist(j*dxl+mxl:j*dxl+dxl-1,1)
                  print*,"smt error t1",spingrp(mxl:dxl-1,j,1)
                  print*,"smt error t1",spingrp(mxl:dxl-1,j,0)
                  print*,"++++++++++++++++++++++++++++++++++++++++++++"
                  print*,"smt error t1",vertexlist(j*dxl:j*dxl+mxl-1,0)
                  print*,"smt error t1",vertexlist(j*dxl:j*dxl+mxl-1,1)
                  print*,"smt error t1",spingrp(0:mxl-1,j,1)
                  print*,"smt error t1",spingrp(0:mxl-1,j,0)
                  pause
               endif
            endif
            if (test2/=-2 .and. spingrp(i,j,1)==2) then
               if (test2/=vertexlist(j*dxl+i,1)) then
                  print*,"smt error t2",mrk0,mrk1
                  print*,"smt error t2",test2,j
                  print*,"smt error t2",vertexlist(j*dxl+mxl:j*dxl+dxl-1,0)
                  print*,"smt error t2",vertexlist(j*dxl+mxl:j*dxl+dxl-1,1)
                  print*,"smt error t2",spingrp(mxl:dxl-1,j,1)
                  print*,"smt error t2",spingrp(mxl:dxl-1,j,0)
                  print*,"++++++++++++++++++++++++++++++++++++++++++++"
                  print*,"smt error t2",vertexlist(j*dxl:j*dxl+mxl-1,0)
                  print*,"smt error t2",vertexlist(j*dxl:j*dxl+mxl-1,1)
                  print*,"smt error t2",spingrp(0:mxl-1,j,1)
                  print*,"smt error t2",spingrp(0:mxl-1,j,0)
                  pause
               endif
            endif
         enddo
      endif

   enddo
   if (checkcounter/=length .or. sum(opvlog(:,2))/=length) then
      print*,"ERROR","checkcounter/=length",checkcounter,length,mrk0,mrk1,sum(opvlog(:,2)),checkcounter3
      pause
   endif
   if (s==1) then
      if (opvlog(0,clb_nxt)>=1) then
      !print*,"===================================nxt"
         do j=1,opvlog(0,clb_nxt)
            !print*,opvlog(j,clb_nxt),opvlog(tauscale(opvlog(j,clb_nxt)),2)
            if (opvlog(tauscale(opvlog(j,clb_nxt)),2)>0) then
               checkcounter3=checkcounter3+opvlog(tauscale(opvlog(j,clb_nxt)),2)
            endif
         enddo
         !print*,checkcounter3,length
      !print*,"===================================nxt"
      endif
      print*,checkcounter3/=length,checkcounter3,length
      if (checkcounter3/=length) then
         print*,"ERROR2","checkcounter/=length",clb_nxt,clb_cur
         print*,"ERROR2","checkcounter/=length",checkcounter2,opvlog(0,clb_nxt),opvlog(0,clb_cur)
         print*,"ERROR2","checkcounter/=length",length,sum(opvlog(:,2)),checkcounter3
         print*,"ERROR2","checkcounter/=length",opvlog(0,0:1),clb_nxt
         pause
      endif
   endif

end subroutine clusterbuildchecker
!==================================================!

!==================================================!

subroutine adjustcutoff(step)
   use configuration
   implicit none

   integer, allocatable :: stringcopy(:)
   integer, allocatable :: opstfpcopy(:,:)
   integer :: mmnew,step

   mmnew=nh+nh/3
   if (mmnew<=mm) return

   allocate(stringcopy(0:mm-1))
   stringcopy(:)=opstring(:)

   !print*,"1"

   deallocate(opstring)
   allocate(opstring(0:mmnew-1))
   opstring(:)=0

   !print*,"1.2"

   allocate(opstfpcopy(0:mm-1,0:mxl-1))
   opstfpcopy(:,:)=opstfp(:,:)
   deallocate(opstfp)
   allocate(opstfp(0:mmnew-1,0:mxl-1))
   opstfp(:,:)=1d0

   !print*,"2"

   deallocate(tauscale)
   allocate(tauscale(0:mmnew-1))
   tauscale(:)=0

   !print*,"3"

   deallocate(vertexspin)
   allocate(vertexspin(0:mxl-1,0:mmnew-1))
   vertexspin(:,:)=-2

   deallocate(spingrp)
   allocate(spingrp(0:dxl-1,0:mmnew-1,0:2))
   spingrp(:,:,:)=0d0

   !print*,"4"

   opstfp(0:mm-1,:)=opstfpcopy(:,:)
   opstfp(mm:mmnew-1,:)=1
   deallocate(opstfpcopy)
   opstring(0:mm-1)=stringcopy(:)
   opstring(mm:mmnew-1)=0
   deallocate(stringcopy)

   !print*,"5"

   mm=mmnew
   !print*,"5.1"
   deallocate(vertexlist)
   allocate(vertexlist(0:dxl*mm-1,0:2))
   !print*,"5.2"
   deallocate(vertexlist_map)
   allocate(vertexlist_map(0:dxl*mm-1))

   !print*,"6"

   open(unit=10,file='info.dat',position='append')
   write(10,*)' Step: ',step,'  Cut-off L: ',mm,'  Current nh: ',nh
   close(10)
   !print*, "adjust"

 end subroutine adjustcutoff
!==================================================!

!==================================================!

 subroutine SpinFlippingRecorder(i,leg_type)
!---------------------------------------------!
!Recording the spin flipping
!---------------------------------------------!
 use configuration
 use measurementdata
 use vertexupdate
 implicit none

 integer :: t,j,i,sizevr,leg_type
 integer :: site,rx,ry
 integer :: vxw
 integer :: taumark1,taumark2

 call OperatorType(vh2,1)
 site=site1
 j=1
 OpTy1=-1
 site1=-1

 if ( mod(vh2,dxl)<=mxl-1 ) then 
   taumark2=tauscale(vh2/dxl)-1
 else
   taumark2=tauscale(vh2/dxl)
 endif
 if ( taumark2==0 ) taumark2=nh+1 

 if ( mod(vh1,dxl)<=mxl-1 ) then 
   taumark1=tauscale(vh1/dxl)-1
 else
   taumark1=tauscale(vh1/dxl)
 endif
 if ( taumark1==0 ) taumark1=nh+1 

if ( mod(vh2,dxl)>=mxl ) then
   if ( taumark1 >= taumark2 ) then 
      do t=taumark2,taumark1
         recorder(site,t)=recorder(site,t)+1
      enddo
   else
      do t=taumark2,nh+1
         recorder(site,t)=recorder(site,t)+1
      enddo
      do t=1,taumark1
         recorder(site,t)=recorder(site,t)+1
      enddo
   endif
 elseif( mod(vh2,dxl)<=mxl-1 ) then
   if ( taumark1 <= taumark2 ) then 
      do t=taumark1,taumark2
         recorder(site,t)=recorder(site,t)+1
      enddo
   else
      do t=taumark1,nh+1
         recorder(site,t)=recorder(site,t)+1
      enddo
      do t=1,taumark2
         recorder(site,t)=recorder(site,t)+1
      enddo
   endif
 endif

 end subroutine SpinFlippingRecorder
!==================================================!

!==================================================!

subroutine measure(rank)
   use configuration
   use measurementdata
   implicit none

   integer :: i,j,b,op,typ,s1,s2,rx,ry,rz,x,y,z,check,stmp,opoff,opp,opm
   integer :: x1,y1,z1,dl,s3,s4,st,dir,rank,nh1o,s,bondax,sstemp
   real(8) :: am1,am2,tmp,tm,tg,htcp
   real(8), allocatable :: ss(:)
   real(8), allocatable :: tptm(:,:)
   real(8), allocatable :: saft(:)
   real(8), external :: ran
   integer, allocatable :: am(:)
   allocate(ss(3))
   allocate(am(2))
   allocate(saft(2))
   check=0d0
   am(:)=0d0
   saft(:)=0d0
   nh1o=0d0
   opoff=0d0
   opp=0d0
   opm=0d0
   ss(:)=0d0

   allocate(tptm(0:lx-1,2))
   tptm(:,:)=1d0

   am=0
   tm=0
   do i = 1, nn
      am(1)=am(1)+spin(i)
   enddo 

    am1=0.d0
    am2=am(1)

    do i = 0, mm-1
      op=opstring(i)
      saft=0d0

      if ( mod(op,2)==1 ) then
         typ=int(mod(op,8)/2)+1
         b=int(op/8)
         if (typ<=2 .or. typ==4) then
            do j=1,mxl
               stmp=bsites(j,b)
               if (stmp==-1) then
                  exit
               else
                  spin(stmp)=opstfp(i,j-1)*spin(stmp)
                  saft(1)=saft(1)+spin(stmp)
               endif
            enddo

            if (typ==1) then
               bondax=int((b-1)/sitnum)
               stmp=bsites(1,b)
               sstemp=spin(stmp)
               !print*,"bondax",bondax,axie(1,bondax),axie(2,bondax),axie(3,bondax)
               do j=1,3
                  ss(j)=ss(j)+axie(j,bondax)*sstemp
                  !ss(j)=ss(j)+axie(j,bondax)
                  !ss(j)=ss(j)+sstemp
               enddo
               if (sstemp==-1) then
                  opm=opm+1
               else
                  opp=opp+1
               endif
            endif
         opoff=opoff+1
         else
            !if (basis==0d0) then
            !   if (typ==3d0) then
            !      nh1o=nh1o+1
            !      spin(b)=-spin(b)
            !      saft(1)=saft(1)+spin(b)
            !   endif
            !elseif (basis==1d0) then
            !   if (typ==4d0) then
            !      spin(b)=-spin(b)
            !      saft(1)=saft(1)+spin(b)
            !   endif
            !endif
         endif

         am(:)=am(:)+2d0*saft(:)
         check=check+1
        endif

        !am1=am1+dfloat(abs(am))
        !am2=am2+dfloat(am)**2

        am1=am1+dfloat(am(1))
        !am2=am2+dfloat(abs(am(2)))

    end do

    !print*,"op off",opoff,opp,opm,opp-opm,ss(1)
    
    if (mm/=0) then
      am1=am1/dble(mm)
      !am2=am2/dble(mm)
   else
      !am1=dfloat(abs(am))
      !am2=dfloat(am)**2
      am1=dfloat(am(1))
      !am2=dfloat(abs(am(2)))
   endif
   !if (jp/=0) am2=nh1o/dble(jp*beta)

   !print*,am1,am(1),nn

   
   do x1=0,lx-1
      do y1=0,ly-1
         do z1=0,lz-1
            s=1+x1+y1*lx+z1*lx*ly
            s1=1+mod(x1,lx)+mod(y1,ly)*lx+mod(z1,lz)*lx*ly
            s2=1+mod(x1,lx)+mod(y1,ly)*lx+mod(z1+1,lz)*lx*ly
            s3=1+mod(x1-1,lx)+mod(y1,ly)*lx+mod(z1+1,lz)*lx*ly
            s4=1+mod(x1,lx)+mod(y1-1,ly)*lx+mod(z1+1,lz)*lx*ly
            tg=0d0
            tg=spin(s1+0*sitnum)+spin(s1+1*sitnum)+spin(s1+2*sitnum)+spin(s1+3*sitnum)
            tm=tm+abs(tg)
            tg=0d0
            tg=spin(s2+0*sitnum)+spin(s3+1*sitnum)+spin(s4+2*sitnum)+spin(s1+3*sitnum)
            tm=tm+abs(tg)
         enddo
      enddo
   enddo
   !print*,tm
   !print*,ss(1),ss(2),ss(3)
    enrg1=enrg1+dble(nh)
    enrg2=enrg2+dble(nh)**2
    stiff(1)=stiff(1)+(ss(1))**2
    stiff(2)=stiff(2)+(ss(2))**2
    stiff(3)=stiff(3)+(ss(3))**2
    stiff(0)=stiff(0)+ss(1)**2+ss(2)**2+ss(3)**2
   !if (nnn==1) then
   !   htcp=dble(nh)/(beta*dble(nn))
   !   htcp=htcp+((nn*(jp))+pbAc*(Ac+hz/3d0+0.01d0)+pbBs*Ac*(1d0/dble(2**6))+pbCn*Ac*(1d0/dble(3**3)))/dble(nn)
   !   enrg2=enrg2+dble(htcp)**2
   !else
   !   htcp=dble(nh)/(beta*dble(nn))
   !   htcp=htcp+((nn*(jp))+pbAc*(Ac+hz/3d0+0.01d0))/dble(nn)
   !   enrg2=enrg2+dble(htcp)**2
   !endif
    amag1=amag1+am1
    amag2=amag2+am2
    bind1(1)=bind1(1)+(am1/dble(nn))**2
    bind2(1)=bind2(1)+(am2/dble(nn))**2
    bind1(2)=bind1(2)+(am1/dble(nn))**4
    bind2(2)=bind2(2)+(am2/dble(nn))**4
    tmag1=tmag1+tm

    !if ( check==0 ) print*,"warning",ss(:) 

   do s1=1, sitnum
      x=mod(s1-1,lx)
      y=mod(int((s1-1)/lx),ly)
      z=int((s1-1)/(lx*ly))
      do rx=0, lx-1
         do ry=0, ly-1
            do rz=0, lz-1
               s2=mod(x+rx,lx)+mod(y+ry,ly)*lx+mod(z+rz,lz)*lx*ly+1
               do i=1, 4
                  crr(rx,ry,rz,i)=crr(rx,ry,rz,i)+spin(s1+(i-1)*sitnum)*spin(s2+(i-1)*sitnum)
                  !if (rx/=0 .and. ry/=0 .and. rz/=0) then
                     !if ((s1+(i-1)*sitnum)==(s2+(i-1)*sitnum)) print*, (s1+(i-1)*sitnum),(s2+(i-1)*sitnum)
                  !endif
                  !print*, (s1+(i-1)*sitnum),(s2+(i-1)*sitnum)
               enddo
            enddo
         enddo
      enddo
   enddo

   dir=2*basis-1
   !s1=int(ran()*sitnum)+1
   

   !print*,"+++++++++++++++++++++++++++++++++"
   !print*,spin(1),spin(9),spin(17)
   !print*,spin(2),spin(mxl-1),spin(21)
   nms1=nms1+1

end subroutine measure
!==================================================!


!==================================================!


 subroutine automeasure()
!---------------------------------------------!
! time dependent q-space correlation functions
!---------------------------------------------!
 use configuration
 use measurementdata
 implicit none

 integer :: i,j,rx,ry,rz,r,s,q,b,op,s1,s2,t1,t2,dt,dd,s0,taumark,dv,k,sig,l
 integer :: typ,stmp,nsig,ni
 real(8) :: en_auto
 integer, allocatable :: spin_config(:,:,:)
 integer, allocatable :: spin_cor(:,:,:,:)
 real(8), allocatable :: spin_space(:,:)
 integer, allocatable :: spin_back(:,:)
 allocate(spin_config(ns,nn,0:3))
 allocate(spin_space(nn,0:ntau))
 allocate(spin_cor(sitnum,0:ntau,0:3,0:3))
 allocate(spin_back(0:3,2))
 spin_cor=0d0

 i=0
 s0=1
 spin_back(:,:)=0d0
 nsig=0d0
 do i=0,mm-1
   op=opstring(i)
   if (op/=0) then
      do q=1,nn
         ni=int((q-1)/sitnum)
         !print*,ni,spin(q)
         r=mod((q-1),sitnum)+1
         spin_back(ni,1)=spin_back(ni,1)+spin(q)
         spin_back(ni,2)=spin_back(ni,2)+1
      enddo
      !print*, "check2"

      if(mod(op,2)==1) then
         typ=int(mod(op,8)/2)+1
         b=int(op/8)
         if (typ==1 .or. typ==2 .or. typ==4) then
            do j=1,mxl
               stmp=bsites(j,b)
               if (stmp==-1) then
                  exit
               else
                  spin(stmp)=opstfp(i,j-1)*spin(stmp)
               endif
            enddo
         else
            spin(b)=-spin(b)
         endif
      endif
   endif
 enddo

 en_auto=-(nh/(beta*dble(nn)))
      if (nnn==1d0) then
         en_auto=en_auto+(pbAc*(addele)+pbBs*Ac*(1d0/dble(2**6))+pbCn*Ac*(1d0/dble(3**3)))/dble(nn)
      else
         en_auto=en_auto+(pbAc*(addele))/dble(nn)
      endif

 open(10,file=culgname,position='append')
 write(10,*)dble(spin_back(0,1)*0.5d0)/dble(spin_back(0,2))&
               &,dble(spin_back(1,1)*0.5d0)/dble(spin_back(1,2))&
               &,dble(spin_back(2,1)*0.5d0)/dble(spin_back(2,2))&
               &,dble(spin_back(3,1)*0.5d0)/dble(spin_back(3,2)),en_auto
 close(10)

 end subroutine automeasure
!==================================================!

!==================================================!


 subroutine measure2()
!---------------------------------------------!
! time dependent q-space correlation functions
!---------------------------------------------!
 use configuration
 use measurementdata
 implicit none

 integer :: i,j,rx,ry,rz,r,s,q,b,op,s1,s2,t1,t2,dt,dd,s0,taumark,dv,k,sig,l
 integer :: typ,stmp,nsig,ni
 integer, allocatable :: spin_config(:,:,:)
 integer, allocatable :: spin_cor(:,:,:,:)
 real(8), allocatable :: spin_space(:,:)
 integer, allocatable :: spin_back(:,:)
 allocate(spin_config(ns,nn,0:3))
 allocate(spin_space(nn,0:ntau))
 allocate(spin_cor(sitnum,0:ntau,0:3,0:3))
 allocate(spin_back(0:3,2))
 spin_cor=0d0

 i=0
 s0=1
 spin_back(:,:)=0d0
 nsig=0d0
 do i=0,mm-1
   op=opstring(i)
   taumark=tauscale(i)
   if (nsig==0) then
      do s=s0,ns
         if (taumark/=nh) then
            if ( dble(s)/dble(ns)*beta > rantau(mod(taumark,nh)+1) ) then
               s0=s
               exit 
            endif 
         else 
            if ( dble(s)/dble(ns)*beta>rantau(mod(taumark,nh)+1) .and. dble(s)/dble(ns)*beta<=rantau(taumark) ) then
               s0=s
               exit 
            endif 
         endif
         if (s==ns) nsig=1

         !do q=1,nq_all  
         !   do j=0,3
         !      do r=1,sitnum
         !         ref(s,q)=ref(s,q)+phi(1,r,q)*dble(spin(r+j*sitnum))  ! real part of the ft at slice s
         !         imf(s,q)=imf(s,q)+phi(2,r,q)*dble(spin(r+j*sitnum))  ! imag part of the ft at slice s
         !         !ref(s,q)=ref(s,q)+phi(1,r,q)*dble(0.25d0)  ! real part of the ft at slice s
         !         !imf(s,q)=imf(s,q)+phi(2,r,q)*dble(0.25d0)  ! imag part of the ft at slice s
         !      enddo
         !   enddo 
         !enddo
         !print*, "check2"
         do q=1,nn
            ni=int((q-1)/sitnum)
            !print*,ni,spin(q)
            r=mod((q-1),sitnum)+1
            spin_config(s,r,ni)=spin(q)
            spin_back(ni,1)=spin_back(ni,1)+spin(q)
            spin_back(ni,2)=spin_back(ni,2)+1
         enddo
         !print*, "check2"

      enddo
   endif

   if(mod(op,2)==1) then
      typ=int(mod(op,8)/2)+1
      b=int(op/8)
      if (typ==1 .or. typ==2 .or. typ==4) then
         do j=1,mxl
            stmp=bsites(j,b)
            if (stmp==-1) then
               exit
            else
               spin(stmp)=opstfp(i,j-1)*spin(stmp)
            endif
         enddo
      else
         spin(b)=-spin(b)
      endif
   endif
 enddo

 !do q=1,nq_all           ! loop over q points
 !   dd=0
 !   tc=0d0
 !   do t1=1,ns,tstp   ! average time point t1 over time slices
 !        do dt=0,ntau
 !           t2=mod(t1+tgrd(dt)-1,ns)+1   ! add time difference in tgrd(dt) to get time t2
 !           tc(dt)=tc(dt)+ref(t1,q)*ref(t2,q)+imf(t1,q)*imf(t2,q)  ! the real part of the correlation
 !        enddo
 !        dd=dd+1        ! count the number of measurements for t-averages
 !   enddo
 !   tcor(:,q)=tcor(:,q)+0.25d0*tc(:)/dble(dd)  
 !   !tcor(:,q)=tcor(:,q)+tc(:)/dble(dd)  
 !enddo


 dd=0
 do t1=1,ns,tstp   
    do dt=0,ntau
        t2=mod(t1+tgrd(dt)-1,ns)+1   
        !do i=1,sitnum 
        i=int(ran()*sitnum)+1
         do j = 1,sitnum
            rz=(i-1)/(lx*ly)-(j-1)/(lx*ly)
            if ( rz<0 ) rz=rz+lz
            ry=mod((i-1)/lx,ly)-mod((j-1)/lx,ly)
            if ( ry<0 ) ry=ry+ly
            rx=mod((i-1),lx)-mod((j-1),lx)
            if ( rx<0 ) rx=rx+lx 
            r=rz*lx*ly+ry*lx+rx+1
            do k=0,3
               do l=0,3
                  spin_cor(r,dt,k,l)=spin_cor(r,dt,k,l)+spin_config(t1,i,k)*spin_config(t2,j,l)
               enddo
            enddo
         enddo
        !enddo
     enddo
   dd=dd+1        ! count the number of measurements for t-averages
 enddo

 
 
 do dt=0,ntau
    do q=1,sitnum
      !print*,q
      do i=0,3
         do j=0,3
            RealSpace(q,dt,i,j)=RealSpace(q,dt,i,j)+0.25d0*(spin_cor(q,dt,i,j))/dble(dd)
         enddo
         !print*,demo_or(q,dt),0.25d0*(spin_cor(q,dt,i,i))/dble(dd*nn)
      enddo
   enddo      
 enddo
 !print*,"check"
 do i=0,3
   cbbkgd(i)=cbbkgd(i)+dble(spin_back(i,1)*0.5d0)/dble(spin_back(i,2))
 enddo
 !print*,"check",spin_back(0,1),spin_back(1,1),spin_back(2,1),spin_back(3,1)
 !open(10,file=culgname,position='append')
 !write(10,*)dble(spin_back(0,1)*0.5d0)/dble(spin_back(0,2))&
 !              &,dble(spin_back(1,1)*0.5d0)/dble(spin_back(1,2))&
 !              &,dble(spin_back(2,1)*0.5d0)/dble(spin_back(2,2))&
 !              &,dble(spin_back(3,1)*0.5d0)/dble(spin_back(3,2))
 !close(10)

 nms2=nms2+1

 end subroutine measure2
!==================================================!

!==================================================!

subroutine writeresult(control,rank)
   use configuration
   use measurementdata
   use vertexupdate
   implicit none

   integer :: msteps,rx,ry,rz,q,t,i1,i2,i3,rank,i,control,k,l,nme
   character(len=2) :: ind

   real(8), external :: qx
   real(8), external :: qy
   real(8), external :: qz

    resname='res000.dat'
    sffname='sff000.dat'
    bidname='bid000.dat'
    crrname='crr000.dat'
    backname='back000.dat'
    tcAcname='tcAc000.dat'
    tcorname='tcor000.dat'
    tcpmname='tcpm000.dat'
    deorname='deor000.dat'
    depmname='dmpm000.dat'

    i3=rank/100
    i2=mod(rank,100)/10
    i1=mod(rank,10)
    resname(6:6)=achar(48+i1)
    resname(5:5)=achar(48+i2)
    resname(4:4)=achar(48+i3)

    sffname(6:6)=achar(48+i1)
    sffname(5:5)=achar(48+i2)
    sffname(4:4)=achar(48+i3)

    bidname(6:6)=achar(48+i1)
    bidname(5:5)=achar(48+i2)
    bidname(4:4)=achar(48+i3)

    crrname(6:6)=achar(48+i1)
    crrname(5:5)=achar(48+i2)
    crrname(4:4)=achar(48+i3)

    tcAcname(7:7)=achar(48+i1)
    tcAcname(6:6)=achar(48+i2)
    tcAcname(5:5)=achar(48+i3)

    backname(7:7)=achar(48+i1)
    backname(6:6)=achar(48+i2)
    backname(5:5)=achar(48+i3)

    tcorname(7:7)=achar(48+i1)
    tcorname(6:6)=achar(48+i2)
    tcorname(5:5)=achar(48+i3)

    tcpmname(7:7)=achar(48+i1)
    tcpmname(6:6)=achar(48+i2)
    tcpmname(5:5)=achar(48+i3)

    deorname(7:7)=achar(48+i1)
    deorname(6:6)=achar(48+i2)
    deorname(5:5)=achar(48+i3)

    depmname(7:7)=achar(48+i1)
    depmname(6:6)=achar(48+i2)
    depmname(5:5)=achar(48+i3)

    !open(10,file=resname,status='replace')
    !close(10)     
    !open(10,file=bidname,status='replace')
    !close(10) 
    !open(10,file=crrname,status='replace')
    !close(10)  
    !open(10,file=backname,status='replace')
    !close(10)  
    !open(10,file=tcAcname,status='replace')
    !close(10) 


    if ( control==0 ) then 
      enrg1=enrg1/dble(nms1)
      enrg2=enrg2/dble(nms1)
      amag1=amag1/dble(nms1)
      amag2=amag2/dble(nms1)
      bind1=bind1/dble(nms1)
      bind2=bind2/dble(nms1)
      tmag1=tmag1/dble(nms1)
      stiff=stiff/dble(nms1)

      enrg2=(enrg2-enrg1*(enrg1+1.d0))/(beta*dble(nn))
      !enrg1=-(enrg1/(beta*dble(nn)))+((nn*(jp))+2d0*(nn*hz0)+0.5d0*3d0*pbAc*Ac)/dble(nn)
      enrg1=-(enrg1/(beta*dble(nn)))
      if (nnn==1d0) then
         enrg1=enrg1+(pbAc*(addele)+pbBs*Ac*(1d0/dble(2**6))+pbCn*Ac*(1d0/dble(3**3)))/dble(nn)
      else
         enrg1=enrg1+(pbAc*(addele))/dble(nn)
      endif

      amag1=amag1/dble(nn)
      amag2=amag2/dble(nn)
      !amag2=(amag1+1d0)*0.5d0
      tmag1=tmag1/dble(4*2*sitnum)
   endif

   open(10,file=resname,position='append')
   write(10,*)beta,hz,jp,enrg1,enrg2,amag1,amag2,tmag1
   close(10)

   if (jp/=0d0) then
      stiff(:)=stiff(:)/(3*jp*lx*beta)
   else
      stiff(:)=0d0
   endif
   open(10,file=sffname,position='append')
   write(10,*)beta,hz,jp,stiff(:)
   close(10)

   open(10,file=bidname,position='append')
   write(10,*)beta,hz,jp,bind1(2)/dble(bind1(1)**2),bind2(2)/dble(bind2(1)**2)
   close(10)

   crr=crr/dble(sitnum)/dble(nms1)
   open(20,file=crrname,position='append')
   do rx=0,lx-1
      do ry=0,ly-1
         do rz=0,lz-1
            write(20,*)rx,ry,rz,beta,hz,jp,crr(rx,ry,rz,:)
         enddo
      enddo
   end do
   close(20)
   crr=crr*dble(sitnum)*dble(nms1)
   cbbkgd=cbbkgd/dble(nms2)   

   open(10,file=backname,position='append')
   write(10,*)beta,hz,jp,cbbkgd(0:3)
   close(10) 
   cbbkgd=cbbkgd*dble(nms2)

   do i=0,3
      demo_pm(:,:,i,:)=dble(demo_pm(:,:,i,:)*0.5d0)/dble(dmweight(i))
   enddo
   do k=0,3
      do l=0,3
         nme=k*10+l
         write (ind,fmt='(i2.2)') nme
         depmname='pm'//ind//'000.dat'
         depmname(7:7)=achar(48+i1)
         depmname(6:6)=achar(48+i2)
         depmname(5:5)=achar(48+i3)
         open(10,file=depmname,status='replace')
         do q=1,sitnum
            write(10,'(2i8)')q
            do t=0,ntau
               write(10,'(f20.12)')(demo_pm(q,t,k,l))
            enddo
         enddo
         close(10)
      enddo
   enddo
   demo_pm=0.d0

   demo_or=demo_or/dble(nms3)
   do k=0,3
      do l=0,3
         nme=k*10+l
         write (ind,fmt='(i2.2)') nme
         depmname='de'//ind//'000.dat'
         depmname(7:7)=achar(48+i1)
         depmname(6:6)=achar(48+i2)
         depmname(5:5)=achar(48+i3)
         open(10,file=depmname,status='replace')
         do q=1,sitnum
            write(10,'(2i8)')q
            do t=0,ntau
               write(10,'(f20.12)')(demo_or(q,t,k,l))
            enddo
         enddo
         close(10)
      enddo
   enddo
   demo_or=0.d0
   nms2=0
   nms3=0

   if ( control==0 ) then
      enrg1=0.d0
      enrg2=0.d0
      amag1=0.d0
      amag2=0.d0
      crr=0d0
      nms1=0
      cbbkgd=0d0
      nms2=0
   endif

end subroutine writeresult
!==================================================!

!==================================================!

real(8) function ran()
!----------------------------------------------!
! 64-bit congruental generator                 !
! iran64=oran64*2862933555777941757+1013904243 !
!----------------------------------------------!
 implicit none

 real(8) :: dmu64
 integer(8) :: ran64,mul64,add64
 common/bran64/dmu64,ran64,mul64,add64

 ran64=ran64*mul64+add64
 ran=0.5d0+dmu64*dble(ran64)

 end function ran


Subroutine initran(w,rank)
!--------------------------------------------------!
 implicit none
 integer(8) :: irmax
 integer(4) :: w,b
 integer :: rank,system_time
 real(8) :: dmu64
 integer(8) :: ran64,mul64,add64
 common/bran64/dmu64,ran64,mul64,add64
 
irmax=2_8**31
irmax=2*(irmax**2-1)+1
mul64=2862933555777941757_8
add64=1013904243
dmu64=0.5d0/dble(irmax)
call system_clock(system_time)
ran64=abs(system_time-(rank*1993+2018)*20160514)  

end Subroutine initran
!==================================================!


!==================================================!

subroutine deallocateall()
   use configuration
   use measurementdata
   implicit none

   deallocate(spin)
   !print*,"spin"
   deallocate(bsites)
   !print*,"sites"
   deallocate(opstring)
   !print*,"opstring"
   deallocate(tauscale)
   !print*,"tauscale"
   deallocate(frstspinop)
   !print*,"frstspinop"
   deallocate(lastspinop)
   !print*,"lastspinop"
   deallocate(vertexlist)
   !print*,"vertexlist"
   deallocate(vertexlist_map)
   !print*,"vertexlist_map"
   deallocate(rantau)
   !print*,"rantau"
   deallocate(crr)
   !print*,"crr"
   deallocate(vertexspin)
   !print*,"vertexspin"
   deallocate(spingrp)
   !print*,"spingrp"
   deallocate(tc)
   !print*,"tc"
   !deallocate(tcAc)

end subroutine deallocateall
!==================================================!

!==================================================!     
subroutine taugrid(gtype,tmax)
!-------------------------------------------------------------------------!
!-constructs array tgrd(0,...,ntau) of time separations (in units of dtau)!
!-gtype = 1 for uniform grid of all separatiins up to tmax
!-        2 for quadratic grid t=dtau*n^2/4 up to beta/2
!-        3 for uniform grid up to tmax followed by quadratic to beta/2
!-actual time points including dtau factor are written to 'tgrid.dat'
!--------------------------------------------------------------------------!
 use configuration
 use measurementdata
 use vertexupdate
 implicit none

 integer :: i,t1,t2,gtype,nsm
 real(8) :: tmax

 nsm=int((tmax+1.d-5)/dtau)
 open(10,file='tgrid.dat',status='replace')

 if (gtype==1) then
    ntau=nsm
    write(10,'(i4)')ntau
    allocate(tgrd(0:ntau)) 
    do i=0,ntau
       tgrd(i)=i
       write(10,'(f15.8)')tgrd(i)*dtau
    enddo

 elseif (gtype==2) then    
    ntau=0
    t1=0
    do
       t2=((ntau+1)**2)/4
       if (t2==t1) t2=t1+1
       if (t2.le.nsm) then
          ntau=ntau+1
          t1=t2
       else
          exit
       endif
    enddo
    write(10,'(i4)')ntau
    allocate(tgrd(0:ntau)) 
    tgrd(0)=0
    write(10,'(f15.8)')0.d0
    do i=1,ntau
       tgrd(i)=(i**2)/4
       if (tgrd(i)==tgrd(i-1)) tgrd(i)=tgrd(i-1)+1       
       write(10,'(f15.8)')tgrd(i)*dtau
    enddo

 elseif (gtype==3) then  
    ntau=nsm
    t1=0
    i=0
    do
       t2=((i+1)**2)/4
       if (t2==t1) t2=t1+1
       if (t2.gt.nsm.and.t2.le.ns/2) then
          ntau=ntau+1
          t1=t2
       elseif (t2.gt.ns/2) then
          exit
       endif
       i=i+1
    enddo
    write(10,'(i4)')ntau
    allocate(tgrd(0:ntau)) 
    tgrd(0)=0
    do i=0,nsm
       tgrd(i)=i
       write(10,'(f15.8)')tgrd(i)*dtau
    enddo
    ntau=nsm
    t1=0
    i=0
    do
       t2=((i+1)**2)/4
       if (t2==t1) t2=t1+1
       if (t2.gt.nsm.and.t2.le.ns/2) then
          ntau=ntau+1
          tgrd(ntau)=t2
          write(10,'(f15.8)')tgrd(ntau)*dtau
          t1=t2
       elseif (t2.gt.ns/2) then
          exit
       endif
       i=i+1
    enddo
 endif 
 close(10)

 allocate(tc(0:ntau)) 
 allocate(tcAc(0:ntau,ly))
 allocate(cbbkgd(0:3)) 
 !allocate(tcor(0:ntau,nq_all)) 
 !allocate(tcorpm(0:ntau,nq_all))
 allocate(RealSpace(sitnum,0:ntau,0:3,0:3))
 allocate(PMinRealSpace(sitnum,0:ntau,0:3,0:3))
 allocate(PMRS_temp(sitnum,0:ntau,0:3,0:3))
 allocate(demo_pm(sitnum,0:ntau,0:3,0:3))
 allocate(demo_or(sitnum,0:ntau,0:3,0:3))
 allocate(dmweight(0:3))

 !tcorpm=0d0
 !tcor=0d0
 PMRS_temp=0d0
 RealSpace=0d0
 PMinRealSpace=0d0
 demo_or=0d0
 demo_pm=0d0 

 tcAc=0.d0
 cbbkgd(:)=0d0
 nc=0d0

 allocate(pbcgcnt(4,0:3))
 pbcgcnt=0d0

 allocate(cmplsg(0:3))
 cmplsg(:)=0d0
 selfcest=0d0

 end subroutine taugrid
 !==================================================!    

 !==================================================!
   
subroutine qarrays()
!-----------------------------------------------------------!
! phase factors for fourier transforms of spin configuration
!-----------------------------------------------------------!
 use configuration
 use measurementdata
 implicit none

 integer :: r,q
 real(8), external :: qx
 real(8), external :: qy
 real(8), external :: qz
 real(8) :: qqx,qqy,qqz
 integer :: x,y,z
 integer :: rx,ry,rz

 allocate(phi(2,sitnum,nq_all))
 allocate(ref(ns,nq_all))
 allocate(imf(ns,nq_all))
 !s=1+x1+y1*lx+z1*lx*ly

 !x=mod(s1-1,lx)
 !y=mod(int((s1-1)/lx),ly)
 !z=int((s1-1)/(lx*ly))

 do q=1, nq_all
    qqx=2.d0*pi*dble(qx(q-1)*0d0+qy(q-1)/sqrt(3d0)-qz(q-1)*0.5d0/sqrt(6d0))/dble(lx)
    qqy=2.d0*pi*dble(qx(q-1)*0.5d0-qy(q-1)*0.5d0/sqrt(3d0)-qz(q-1)*0.5d0/sqrt(6d0))/dble(ly)
    qqz=2.d0*pi*dble(qx(q-1)*0d0+qy(q-1)*0d0+qz(q-1)*0.5d0*sqrt(1.5d0))/dble(lz)

    do r=1,sitnum
      x=mod(r-1,lx)
      y=mod(int((r-1)/lx),ly)
      z=int((r-1)/(lx*ly))
      rx=x*1d0+y*2d0+z*1d0
      ry=x*sqrt(3d0)+y*0d0+z*1d0/sqrt(3d0)
      rz=x*0d0+y*0d0+z*2d0*(sqrt(2d0/3d0))
      phi(1,r,q)=cos(rx*qqx+ry*qqy+rz*qqz)/sqrt(dble(sitnum))       
      phi(2,r,q)=sin(rx*qqx+ry*qqy+rz*qqz)/sqrt(dble(sitnum)) 
    enddo
 enddo
 
 end subroutine qarrays
!----------------------!



real(8) function qx(q)
!----------------------------------------------!
!-find qx point-!
!----------------------------------------------!
 use configuration
 use measurementdata

 implicit none

 integer :: q

 if ( int(q/nq) == 0 ) then
   qx=0
 elseif(int(q/nq) == 1) then
   qx=mod(q,nq)
 endif

 end function qx

 !----------------------------------------------!
 !----------------------------------------------!
 !----------------------------------------------!

 real(8) function qy(q)
!----------------------------------------------!
!-find qy point-!
!----------------------------------------------!
 use configuration
 use measurementdata

 implicit none

 integer :: q

 if ( int(q/nq) == 0 ) then
   qy=2*mod(q,nq)
 elseif(int(q/nq) == 1) then
   qy=mod(q,nq)
 endif

 end function qy

 real(8) function qz(q)
!----------------------------------------------!
!-find qy point-!
!----------------------------------------------!
 use configuration
 use measurementdata

 implicit none

 integer :: q

 if ( int(q/nq) == 0 ) then
   qz=0
 elseif(int(q/nq) == 1) then
   qz=mod(q,nq)
 endif

 end function qz

!==================================================!

 subroutine measure3()
!---------------------------------------------!
!-time dependent q-space correlation functions S+S-
!---------------------------------------------!
 use configuration
 use measurementdata
 use vertexupdate
 implicit none

 integer :: i,j,k,s,q,t1,t2,dt,taumark
 real(8), allocatable :: PMinRealSpaceSum(:,:)
 allocate(PMinRealSpaceSum(sitnum,0:ntau))

 !print*,"+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
 !do dt=0,ntau
    !print*,dt,demo(2,dt)
 !enddo
 !print*,"+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"

if ( nc/=0 ) then
  do dt=0,ntau
      do i=0,3
         do j=0,3
            demo_or(:,dt,i,j)=demo_or(:,dt,i,j)+RealSpace(:,dt,i,j)
            demo_pm(:,dt,i,j)=demo_pm(:,dt,i,j)+PMinRealSpace(:,dt,i,j)
         enddo 
      enddo 
   enddo
endif 
 !print*,PMinRealSpaceSum(1,0)/dble(nc)

 !PMinRealSpaceSum=0d0
 !do i=1,sitnum
   !do j=0,3
      !PMinRealSpaceSum(i,:)=PMinRealSpace(i,:,j,j)*(-1d0)**(mod(i-1,lx)+int((i-1)/lx))
      !PMinRealSpaceSum(i,:)=PMinRealSpaceSum(i,:)+PMinRealSpace(i,:,j,j)
   !enddo
 !enddo  

!if ( nc/=0 ) then
!  do dt=0,ntau  
!      do i=0,3
!         do j=0,3
!            demo_pm(:,dt,i,j)=demo_pm(:,dt,i,j)+PMinRealSpace(:,dt,i,j)/dble(nc)      
!         enddo 
!      enddo 
!   enddo
!endif

 !PMinRealSpaceSum=1d0
 !if ( nc/=0 ) then 
 !  do dt=0,ntau
 !     do q=1,nq_all
 !        do i=0,3
 !           !do j=0,3
 !              !tcorpm(dt,q,i,j)=tcorpm(dt,q,i,j)&
 !              !&+sum(phi(1,:,q)*(sqrt(dble(sitnum))/2d0)*dble(PMinRealSpace(:,dt,i,j)/dble(nc)))
 !           !enddo    
 !           tcorpm(dt,q)=tcorpm(dt,q)+sum(phi(1,:,q)*(sqrt(dble(sitnum))/2d0)*dble(PMinRealSpaceSum(:,dt)))
 !        enddo   
 !     enddo    
 !  enddo
 !endif
 nms3=nms3+1 

 call initCollection()

 end subroutine measure3
!==================================================!  
!==================================================!

 subroutine random_tau()
!---------------------------------------------!
!time dependent q-space correlation functions S+S-
!---------------------------------------------!
 use configuration
 use measurementdata
 implicit none

 integer :: i,j,k
 real(8), external :: ran

 if ( size(rantau, dim=1)/=nh ) then
   deallocate(rantau)
   allocate(rantau(nh))
 endif 

 do i=1,nh
   rantau(i)=ran()*beta
 enddo

 call quick_sort(rantau,nh,1,nh)
 
 end subroutine random_tau
!==================================================!

  
!==================================================!

 subroutine random_bond()
!---------------------------------------------!
!time dependent q-space correlation functions S+S-
!---------------------------------------------!
 use configuration
 use measurementdata
 implicit none

 integer :: i,j,k,na
 integer, allocatable :: bondchain2(:)
 real(8), allocatable :: bondchain3(:)
 real(8), external :: ran
 
 na=int(pbAc)
 allocate(bondchain2(na))
 allocate(bondchain3(na))
 do i=1,na
   bondchain2(i)=i
   bondchain3(i)=ran()
 enddo

 call random_range(bondchain3,bondchain2,na,1,na)

 do i=1,na
   bondchain(bondchain2(i),0)=bondchain2(i)
   bondchain(bondchain2(i),1)=bondchain2(mod(i,na)+1)
   bondchain(bondchain2(i),2)=bondchain2(mod(i-2+na,na)+1)
   !print*, na,mod(i-2+na,na)+1,i,mod(i,na)+1
   !print*, bondchain(bondchain2(i),:)
enddo
 
 end subroutine random_bond
!==================================================!

!==================================================!

recursive subroutine random_range(a,b,n,s,e)
implicit none
integer :: n      
real(8) :: a(1:n+1)
integer :: b(1:n+1)
integer :: s      
integer :: e      
integer :: l,r    
real(8) :: k      
real(8) :: temp   
integer :: temp2  
l=s
r=e+1
if ( r<=l ) return

k=a(s)
do while(.true.)

   do while( .true. )
      l=l+1
      if ( (a(l) > k) .or. (l>=e) ) exit
   end do

   do while( .true. )
      r=r-1
      if ( (a(r) < k) .or. (r<=s) ) exit
   end do
   if ( r <= l ) exit

   temp=a(l)
   temp2=b(l)
   a(l)=a(r)
   b(l)=b(r)
   a(r)=temp
   b(r)=temp2
end do
 
temp=a(s)
temp2=b(s)
a(s)=a(r)
b(s)=b(r)
a(r)=temp
b(r)=temp2

call random_range(a,b,n,s,r-1) 
call random_range(a,b,n,r+1,e)
return
end subroutine random_range
!==================================================!

!==================================================!

recursive subroutine quick_sort(a,n,s,e)
implicit none
integer :: n      
real(8) :: a(1:n+1) 
integer :: s      
integer :: e      
integer :: l,r    
real(8) :: k      
real(8) :: temp   
l=s
r=e+1
if ( r<=l ) return

k=a(s) 
do while(.true.)

   do while( .true. )
      l=l+1
      if ( (a(l) > k) .or. (l>=e) ) exit
   end do

   do while( .true. )
      r=r-1
      if ( (a(r) < k) .or. (r<=s) ) exit
   end do
   if ( r <= l ) exit

   temp=a(l)
   a(l)=a(r)
   a(r)=temp
end do
 
temp=a(s)
a(s)=a(r)
a(r)=temp

call quick_sort(a,n,s,r-1) 
call quick_sort(a,n,r+1,e)
return
end subroutine quick_sort
!==================================================!

 subroutine OperatorType(v,type_01)
!---------------------------------------------!
!-Finding the operator type
!-type=0 for the v0 type=1 for the other
!-IMPORTANT: the vertexspin is the spin "after" update
!---------------------------------------------!
 use configuration
 use vertexupdate
 implicit none

 integer :: v,i,b_temp,op_temp,type_01
 integer :: site_temp,OpTy_temp

 i=v/dxl
 op_temp=opstring(i)
 b_temp=op_temp/8

 site_temp=bsites(mod(v,mxl)+1,b_temp)
 if ( type_01==0 ) then
   site0=site_temp
   OpTy0=1 
 elseif ( type_01==1 ) then
   site1=site_temp
   OpTy1=1
 endif 

 end subroutine OperatorType
!==================================================!

subroutine initRecorder()
!---------------------------------------------!
!-initialize recorder
!---------------------------------------------!
 use configuration
 use vertexupdate
 use measurementdata
 implicit none

 integer :: i,j,k

 if ( size(recorder, dim=2)/=nh+1 ) then 
   deallocate(recorder)
   allocate(recorder(nn,nh+1))
 endif
 recorder=0d0

 end subroutine initRecorder
!==================================================!
!==================================================!

subroutine RelativeSpace(v_o,taumark,dt,taumark0)
!---------------------------------------------!
!-Turing into relative space
!---------------------------------------------!
 use configuration
 use vertexupdate
 use measurementdata
 implicit none

 integer :: dt,taumark,taumark0
 integer :: v_o,site_o,OpTy_o
 integer :: v_r,site_r,OpTy_r
 integer :: i,ot,r,rr,rx,ry,rz
 integer :: x,y,z,ni,test
 integer :: x_0,y_0,z_0,ni_0

 call OperatorType(v_o,1)
 site_o=site1
 OpTy_o=OpTy1
 OpTy_r=1-OpTy_o
 site1=-1
 OpTy1=-1

 if ( recorder(site_o,taumark0)==0 ) then
    print*, "error", recorder(site_o,taumark0),site_o,taumark0,mod(v0,dxl)
    pause
 endif
 
 ni_0=int((site_o-1)/sitnum)
 site_o=mod((site_o-1),sitnum)+1
 x_0=mod(site_o-1,lx)
 y_0=mod(int((site_o-1)/lx),ly)
 z_0=int((site_o-1)/(lx*ly))

 do rr=1,nn

   ni=int((rr-1)/sitnum)
   r=mod((rr-1),sitnum)+1
   x=mod(r-1,lx)
   y=mod(int((r-1)/lx),ly)
   z=int((r-1)/(lx*ly))

   rx=x-x_0
   if ( rx<0 ) rx=rx+lx 
   ry=y-y_0
   if ( ry<0 ) ry=ry+ly
   rz=z-z_0
   if ( rz<0 ) rz=rz+lz
   
   
   site_r=1+rx+ry*lx+rz*lx*ly
   !print*,site_r,r,sitnum,rr,nn

   PMRS_temp(site_r,dt,ni_0,ni)=PMRS_temp(site_r,dt,ni_0,ni)+dble(recorder(rr,taumark))!/dble(recorder(site_o,taumark0))!
 enddo
 !if (dt==0 .and. site_r==1) then
 !  test=0d0
 !  do i=0,3
 !     test=test+PMRS_temp(1,0,i,i)
 !  enddo
 !  if (test/=1) then
 !     print*,PMRS_temp(1,0,0,0),PMRS_temp(1,0,1,1),PMRS_temp(1,0,2,2),PMRS_temp(1,0,3,3),"RelativeSpace"
 !     pause
 !  endif
 !endif


 end subroutine RelativeSpace
!==================================================!

subroutine initCollection()
!---------------------------------------------!
!-initialize Collection
!---------------------------------------------!
 use configuration
 use measurementdata
 implicit none

 nc=0
 RealSpace(:,:,:,:)=0d0
 PMinRealSpace(:,:,:,:)=0d0

 end subroutine initCollection
!==================================================!

subroutine CollectRecorder()
!---------------------------------------------!
!-initialize recorder
!---------------------------------------------!
 use configuration
 use vertexupdate
 use measurementdata
 implicit none

 integer :: dt,taumark,taumark0,bilibili,v_temp,OpTy_temp,sizevr,taumark_temp,dt_temp,i
 integer :: taumark1,s_temp,ni_temp
 integer :: AcFun
 real(8) :: tau_temp,test
 real(8), external :: ran

 PMRS_temp=0
 !AcFun=0

 v_temp=v0
 call OperatorType(v_temp,1)
 s_temp=site1
 OpTy1=-1
 site1=-1
 ni_temp=int((s_temp-1)/sitnum)
 nia=ni_temp

 if ( v_temp==-1 ) print*,"error" 

 if ( mod(v_temp,dxl)<=mxl-1 ) then
      v_temp=vertexlist_map(v_temp)
 endif

 taumark0=tauscale(v_temp/dxl)
 taumark1=tauscale(vertexlist_map(v_temp)/dxl)
 if ( rantau(taumark1)>rantau(taumark0) ) then
    delta_tau=rantau(taumark1)-rantau(taumark0)
    tau0=delta_tau*ran()+rantau(taumark0) !may cause error
    taumark_temp=taumark0
 else
    delta_tau=rantau(taumark1)+beta-rantau(taumark0)
    tau0=mod(delta_tau*ran()+rantau(taumark0),beta)
    taumark_temp=taumark1
 endif
 dmweight(ni_temp)=dmweight(ni_temp)+delta_tau

 dt_temp=0

 do dt=0,ntau

   tau_temp=tau0+tgrd(dt)*dtau

   do
      if ( tau_temp<=beta .and. tau_temp>=0d0 ) exit
      tau_temp=tau_temp-beta
      if ( dt_temp==0 ) then
         dt_temp=dt
         taumark_temp=1
      endif 
   end do
   !if (dt==0) print*,"taumark",taumark_temp

   taumark=taumark_temp
   do
      if ( taumark/=nh ) then 
         if ( tau_temp < rantau(mod(taumark,nh)+1) .and. tau_temp >= rantau(taumark) ) then               
            call RelativeSpace(v_temp,taumark,dt,taumark0)
            taumark_temp=taumark
            exit
         endif
      elseif ( tau_temp < rantau(1) .or. tau_temp>=rantau(nh) ) then
         call RelativeSpace(v_temp,nh+1,dt,taumark0)
         taumark_temp=taumark
         exit 
      endif
      taumark=mod(taumark,nh)+1
   enddo

 enddo

 !AcFun=AcFun+1

 !if ( AcFun/=0 ) then
   PMinRealSpace(:,:,:,:)=PMinRealSpace(:,:,:,:)+PMRS_temp(:,:,:,:)*delta_tau
   !print*, nia
   !PMinRealSpace(:,:,nia,:)=PMinRealSpace(:,:,nia,:)+1d0*delta_tau
   test=0d0
   do i=0,3
      test=test+PMRS_temp(1,0,i,i)
   enddo
   if (test/=1) then
      print*,PMRS_temp(1,0,0,0),PMRS_temp(1,0,1,1),PMRS_temp(1,0,2,2),PMRS_temp(1,0,3,3),tau_temp
      pause
   endif
   !PMinRealSpace(:,:,:,:)=PMinRealSpace(:,:,:,:)+delta_tau
   !print*,"PMRS",((PMRS_temp(1,0,0,0)+PMRS_temp(1,0,1,1)+PMRS_temp(1,0,2,2)+PMRS_temp(1,0,3,3))/dble(AcFun))
   !print*,"PMRS",PMRS_temp(1,0,0,0)/dble(AcFun),PMRS_temp(1,0,1,1)/dble(AcFun),PMRS_temp(1,0,2,2)/dble(AcFun),&
   !&PMRS_temp(1,0,3,3)/dble(AcFun)
   nc=nc+1
 !endif
 !pause


 end subroutine CollectRecorder
!==================================================!


!----------------------------------------------!
!----------------------------------------------!

subroutine writeconfig(rank)
!--------------------------------------!
 use configuration 
 implicit none
 integer :: i,rank
 character(len=3) :: ranks
 write (ranks,fmt='(i3.3)') rank
 open(10,file='conf'//ranks//'.log',status='replace')
 do i=1,nn
    write(10,'(i2)')spin(i)
 enddo
 !do i=1,sitnum*4
 !   write(10,'(i2)')nhpm(i,0),nhpm(i,1)
 !enddo
 write(10,*)mm,nh,nh1,nh2,nh3,nh4
 do i=0,mm-1
    write(10,*)opstring(i),opstfp(i,0:mxl-1)
 enddo
 close(10)
 end subroutine writeconfig
!------------------------!

 subroutine readconfig(rank)
!---------------------!
 use configuration
 implicit none
 integer :: i,rank
 character(len=3) :: ranks
 write (ranks,fmt='(i3.3)') rank
 print*, 'conf'//ranks//'.log'
 open(10,file='conf'//ranks//'.log',status='old')
 do i=1,nn
    read(10,*)spin(i)
 enddo
 !do i=1,sitnum*4
 !   read(10,*)nhpm(i,0),nhpm(i,1)
 !enddo
 read(10,*)mm,nh,nh1,nh2,nh3,nh4
 allocate(opstring(0:mm-1))
 allocate(tauscale(0:mm-1))
 allocate(vertexlist(0:dxl*mm-1,0:2))
 allocate(vertexlist_map(0:dxl*mm-1))
 allocate(vertexspin(0:mxl-1,0:mm-1)) 
 allocate(spingrp(0:dxl-1,0:mm-1,0:2)) 
 allocate(rantau(nh)) 
 allocate(opstfp(0:mm-1,0:mxl-1))
 opstfp(:,:)=1
 do i=0,mm-1
    read(10,*)opstring(i),opstfp(i,0:mxl-1)
 enddo
 close(10)
 tauscale(:)=0
 end subroutine readconfig

!----------------------------------------------!

 subroutine clearconfig()
!---------------------!
 use configuration
 implicit none
 integer :: i
 mm=nn
 nh=nn
 nh1=0
 nh2=0
 nh3=0
 nh4=0
 !nhpm(:,:)=0
 deallocate(opstring)
 deallocate(tauscale)
 deallocate(vertexlist)
 deallocate(vertexlist_map)
 deallocate(vertexspin) 
 deallocate(spingrp)
 deallocate(rantau) 
 end subroutine clearconfig

!----------------------------------------------!


subroutine initflux(signal,rank)
!-----------------------------------------------------------!
! phase factors for fourier transforms of spin configuration
!-----------------------------------------------------------!
 use configuration
 use vertexupdate
 implicit none

 integer :: signal,typ,cur0,cur1,leg_in,leg_out,rank,option,pre_mark,notzero
 integer :: i,cur2,cur3,leg_tmp,leg_tmp1,idx_in,idx_out,fluxbuild_typ
 real(8) :: w0,w2,w1,jptmp,w3,weight_tmp,weight_tmp1,dd,totalweight
 integer, allocatable :: state(:,:)
 integer, allocatable :: idx(:)
 integer, allocatable :: visit(:)
 real(8), allocatable :: delta(:,:)
 real(8), allocatable :: delta_tmp(:,:)
 character(11) :: fluxname
 allocate(state(0:dxl-1,0:1))
 allocate(delta(0:dxl-1,0:3))
 allocate(delta_tmp(0:dxl-1,0:3))
 allocate(idx(0:dxl-1))
 allocate(visit(0:mxl-1))
 delta(:,:)=0d0
 state(:,:)=0d0
 
 fluxbuild_typ=0d0 ! BC not DBC
 !fluxbuild_typ=1d0 ! heat bath

 if (signal==0) then
   allocate(fluxtable(0:verdeg,0:verdeg,0:dxl-1,0:dxl-1,0:3,4,2))
   allocate(legtab(0:5,0:1))
 endif
 legtab(:,:)=0d0
 fluxtable(:,:,:,:,:,:,:)=0d0
 
 do pre_mark=0,3
   if (rank==0d0) then
      fluxname='flux000.log'
      fluxname(7:7)=achar(48+pre_mark)
      open(10,file=fluxname,status='replace')
   endif
   do typ=1,4
      do cur0=0,verdeg
         do cur1=0,verdeg
            if (weightable(cur0,cur1,typ)==0d0) cycle
            do i=0,mxl-1
               state(i,0)=(mod(int(cur0/(2**(i))),2))*2-1
               state(i+mxl,0)=(mod(int(cur1/(2**(i))),2))*2-1
            enddo
            
            do leg_in=0,dxl-1
               state(:,1)=state(:,0)
               state(leg_in,1)=-state(leg_in,1)
               delta(:,:)=-1d0
               totalweight=0d0

               do leg_out=0,dxl-1
                  state(leg_out,1)=-state(leg_out,1)
                  cur2=0d0
                  cur3=0d0
                  do i=0,mxl-1
                     cur2=cur2+int((state(i,1)+1)*0.5d0)*2**(i)
                     cur3=cur3+int((state(i+mxl,1)+1)*0.5d0)*2**(i)
                  enddo
                  weight_tmp=weightable(cur2,cur3,typ)
                  leg_tmp=leg_out
                  
                  visit(:)=0d0
                  visit(mod(leg_in,mxl))=visit(mod(leg_in,mxl))+1
                  visit(mod(leg_out,mxl))=visit(mod(leg_out,mxl))+1
                  if (pre_mark==1) then
                     if (visit(2)==0 .and. visit(3)==0) then
                     elseif (visit(0)==0 .and. visit(1)==0) then
                     else
                        weight_tmp=0d0
                     endif
                  elseif (pre_mark==2) then
                     if (visit(1)==0 .and. visit(2)==0) then
                     elseif (visit(0)==0 .and. visit(3)==0) then
                     else
                        weight_tmp=0d0
                     endif
                  elseif (pre_mark==3) then
                     if (visit(0)==0 .and. visit(2)==0) then
                     elseif (visit(1)==0 .and. visit(3)==0) then
                     else
                        weight_tmp=0d0
                     endif
                  endif

                  if (fluxbuild_typ==0) then
                     do i=0,dxl-1
                        if (delta(i,1)==-1d0) then
                           delta(i,1)=weight_tmp
                           delta(i,0)=leg_tmp
                           exit
                        else
                           if (weight_tmp>delta(i,1)) then
                              weight_tmp1=delta(i,1)
                              leg_tmp1=delta(i,0)
                              delta(i,1)=weight_tmp
                              delta(i,0)=leg_tmp
                              weight_tmp=weight_tmp1
                              leg_tmp=leg_tmp1
                           else
                           endif
                        endif
                     enddo
                  elseif (fluxbuild_typ==1) then
                     delta(leg_out,1)=weight_tmp
                     delta(leg_out,0)=leg_tmp
                     totalweight=totalweight+weight_tmp
                  endif
                  
                  state(leg_out,1)=-state(leg_out,1)
               enddo

               !print*, "---------------------------------"
               !print*, delta(:,1)
               notzero=0d0
               do i=0,dxl-1
                  if (delta(i,1)/=0d0) then
                     notzero=notzero+1
                     delta_tmp(i,:)=delta(i,:)
                  else
                     exit
                  endif
               enddo
               do i=1,notzero-1
                  delta(i,:)=delta_tmp(notzero-i,:)
               enddo
               !print*, delta(:,1)

               if (fluxbuild_typ==0) then
                  !print*, leg_in,leg_out,cur0,cur1
                  !print*, delta(:,0)
                  !print*, delta(:,1)
                  !pause
                  delta(0,2)=delta(0,1)
                  do i=0,dxl-1
                     idx(int(delta(i,0)))=i
                     delta(i,2)=delta(i-1,2)+delta(i,1)
                  enddo
                  !print*, idx(:)
                  !print*, delta(:,0)
                  !print*, "---------------------------------"
                  
                  idx_in=idx(leg_in)
                  !print*, weightable(cur0,cur1,typ),delta(idx_in,1)
                  do i=0,dxl-1
                     leg_out=int(delta(i,0))
                     idx_out=idx(leg_out)

                     dd=delta(idx_in,2)-delta(mod(idx_out-1+dxl,dxl),2)+delta(0,1)
                     w0=dd
                     w0=min(w0,delta(idx_in,1)+delta(idx_out,1)-dd)
                     w0=min(w0,delta(idx_in,1))
                     w0=min(w0,delta(idx_out,1))
                     !print*, w0
                     w0=max(w0,0d0)
                     fluxtable(cur0,cur1,leg_in,leg_out,pre_mark,typ,1)=w0
                  enddo
               elseif (fluxbuild_typ==1) then
                  do i=0,dxl-1
                     leg_out=int(delta(i,0))
                     idx_out=idx(leg_out)
                     fluxtable(cur0,cur1,leg_in,leg_out,pre_mark,typ,1)=dble(delta(leg_out,1)*delta(leg_in,1))/dble(totalweight)
                  enddo
               endif

               do leg_out=0,dxl-1
                  if (fluxtable(cur0,cur1,leg_in,leg_out,pre_mark,typ,1)==0) then
                     cycle
                  else
                     state(leg_out,1)=-state(leg_out,1)
                     cur2=0d0
                     cur3=0d0
                     do i=0,mxl-1
                        cur2=cur2+int((state(i,1)+1)*0.5d0)*2**(i)
                        cur3=cur3+int((state(i+mxl,1)+1)*0.5d0)*2**(i)
                     enddo
                     weight_tmp=weightable(cur2,cur3,typ)
                     if (weight_tmp==0) then
                        print*, "weight error"
                        pause
                     endif
                     state(leg_out,1)=-state(leg_out,1)
                  endif
               enddo
               
               fluxtable(cur0,cur1,leg_in,:,pre_mark,typ,2)=0d0
               option=0
               do i=0,dxl-1
                  if (i<=dxl-2) fluxtable(cur0,cur1,leg_in,i,pre_mark,typ,2)=&
                  &sum(fluxtable(cur0,cur1,leg_in,i+1:dxl-1,pre_mark,typ,1))
                  if (fluxtable(cur0,cur1,leg_in,i,pre_mark,typ,1)/=0) then
                     option=option+1
                  endif
               enddo

               if (weightable(cur0,cur1,typ)-sum(fluxtable(cur0,cur1,leg_in,:,pre_mark,typ,1))>=0.00001d0) then
                  print*, "NBC error",weightable(cur0,cur1,typ),sum(fluxtable(cur0,cur1,leg_in,:,pre_mark,typ,1))
                  print*, "NBC error",fluxtable(cur0,cur1,leg_in,:,pre_mark,typ,1)
                  print*, "NBC error",delta(:,0)
                  print*, "NBC error",delta(:,1)
                  pause
               endif

               if (rank==0d0) then
                  write(10,*)"----------------------------------------------"
                  write(10,*)"state 1",cur1,state(mxl:dxl-1,0)
                  write(10,*)"state 0",cur0,state(0:mxl-1,0)
                  write(10,*)"option",option
                  write(10,*)"+++++++++++++++++++++++++++++++++++++++++++++++"
                  write(10,*)"leg in=",leg_in,"w=",weightable(cur0,cur1,typ)
                  write(10,*)"leg out 1",fluxtable(cur0,cur1,leg_in,mxl:dxl-1,pre_mark,typ,1)
                  write(10,*)"leg out 0",fluxtable(cur0,cur1,leg_in,0:mxl-1,pre_mark,typ,1)
                  write(10,*)"leg out 1",fluxtable(cur0,cur1,leg_in,mxl:dxl-1,pre_mark,typ,2)
                  write(10,*)"leg out 0",fluxtable(cur0,cur1,leg_in,0:mxl-1,pre_mark,typ,2)
               endif

            enddo
         enddo
      enddo
   enddo
   if (rank==0d0) then
      close(10)
   endif
 enddo
 print*, "BC done"
 !pause
 end subroutine initflux
!----------------------!
!----------------------------------------------!


subroutine initfluxmul(signal,rank)
!-----------------------------------------------------------!
! phase factors for fourier transforms of spin configuration
!-----------------------------------------------------------!
 use configuration
 use vertexupdate
 implicit none

 integer :: signal,typ,cur0,cur1,rank,option,mu_mark,notzero
 integer :: leg_in_0,leg_in_1,leg_out_0,leg_out_1,leg_out_idx,leg_in_idx
 integer :: i,j,k,l,cur2,cur3,leg_tmp,leg_tmp1,idx_in,idx_out,fluxbuild_typ
 integer :: v_dim,dim_dxl,flux_idx,flux_cage,flux_sign,max_cage,max_type
 real(8) :: w0,w2,w1,jptmp,w3,weight_tmp,weight_tmp1,dd,totalweight
 integer, allocatable :: state(:,:)
 integer, allocatable :: idx(:)
 integer, allocatable :: visit(:)
 real(8), allocatable :: delta(:,:)
 real(8), allocatable :: delta_tmp(:,:)
 integer, allocatable :: leg_in(:)
 integer, allocatable :: leg_out(:)
 real(8), allocatable :: loadtab(:)
 integer, allocatable :: loadnum(:)
 real(8), allocatable  :: fluxtamul(:,:,:,:,:,:)
 character(11) :: fluxname

 allocate(loadtab(0:verdeg+1))
 allocate(loadnum(0:verdeg+1))

 lpdim=3
 lpdimax=min(lpdim,3)
 !lpdimax>=4 no enough memory
 vertexdim=dxl**lpdimax

 allocate(state(0:dxl-1,0:1))
 allocate(delta(0:vertexdim-1,0:3))
 allocate(delta_tmp(0:vertexdim-1,0:3))
 allocate(idx(0:vertexdim-1))
 allocate(visit(0:mxl-1))
 allocate(leg_in(0:lpdimax-1))
 allocate(leg_out(0:lpdimax-1))
 delta(:,:)=0d0
 state(:,:)=0d0
 
 fluxbuild_typ=0d0 ! BC not DBC
 !fluxbuild_typ=1d0 ! heat bath
 !fluxbuild_typ=2d0 ! Mp
 !print*, "fluxmul"

 if (signal==0) then
   allocate(fluxtamul(0:verdeg,0:verdeg,0:vertexdim-1,0:vertexdim-1,lpdimax,2))
   allocate(x0(lpdim))
   allocate(x1(lpdim))
   allocate(x2(lpdim))
   allocate(vc(lpdim,0:3))
   allocate(xrelation(lpdim,lpdim))
   allocate(ix(0:lpdim,0:2))
   allocate(state_leg(0:dxl-1,0:1))
 endif
 fluxtamul(:,:,:,:,:,:)=0d0
 max_cage=0
 max_type=0
 !print*, "fluxmul"
 
 do mu_mark=1,lpdimax
   !print*, "mu_mark",mu_mark
   v_dim=dxl**mu_mark
   if (rank==0d0) then
      fluxname='flbi000.log'
      fluxname(7:7)=achar(48+mu_mark-1)
      open(10,file=fluxname,status='replace')
   endif
   !print*, "fluxmul"
   do typ=1,1
      do cur0=0,verdeg
         do cur1=0,verdeg
            !print*,"cur",cur0,cur1
            if (weightable(cur0,cur1,typ)==0d0) cycle
            do i=0,mxl-1
               state(i,0)=(mod(int(cur0/(2**(i))),2))*2-1
               state(i+mxl,0)=(mod(int(cur1/(2**(i))),2))*2-1
            enddo
            
            do leg_in_idx=0,v_dim-1
               !print*, "leg_in_idx",leg_in_idx
               state(:,1)=state(:,0)

               leg_in_0=leg_in_idx
               do j=1,mu_mark
                  dim_dxl=dxl**(j-1)
                  leg_in(j-1)=mod(int(leg_in_0/dim_dxl),dxl)
                  state(leg_in(j-1),1)=-state(leg_in(j-1),1)
               enddo
               !print*, "leg_in",leg_in_idx,leg_in(:)
               delta(:,:)=-1d0
               totalweight=0d0

               do leg_out_idx=0,v_dim-1
                  leg_out_0=leg_out_idx
                  do j=1,mu_mark
                     dim_dxl=dxl**(j-1)
                     leg_out(j-1)=mod(int(leg_out_0/dim_dxl),dxl)
                     state(leg_out(j-1),1)=-state(leg_out(j-1),1)
                  enddo
                  !print*, "leg_out",leg_out_idx,leg_out(:)
                  
                  cur2=0d0
                  cur3=0d0
                  do i=0,mxl-1
                     cur2=cur2+int((state(i,1)+1)*0.5d0)*2**(i)
                     cur3=cur3+int((state(i+mxl,1)+1)*0.5d0)*2**(i)
                  enddo
                  weight_tmp=weightable(cur2,cur3,typ)
                  leg_tmp=leg_out_idx

                  if (fluxbuild_typ==0) then
                     do i=0,v_dim-1
                        if (delta(i,1)==-1d0) then
                           delta(i,1)=weight_tmp
                           delta(i,0)=leg_tmp
                           exit
                        else
                           if (weight_tmp>delta(i,1)) then
                              weight_tmp1=delta(i,1)
                              leg_tmp1=delta(i,0)
                              delta(i,1)=weight_tmp
                              delta(i,0)=leg_tmp
                              weight_tmp=weight_tmp1
                              leg_tmp=leg_tmp1
                           else
                           endif
                        endif
                     enddo
                  elseif (fluxbuild_typ==1) then
                     delta(leg_out_idx,1)=weight_tmp
                     delta(leg_out_idx,0)=leg_tmp
                     totalweight=totalweight+weight_tmp
                  endif
                  
                  do j=1,mu_mark
                     state(leg_out(j-1),1)=-state(leg_out(j-1),1)
                  enddo
               enddo

               !print*, "---------------------------------"
               !print*, delta(:,1)
               notzero=0d0
               do i=0,v_dim-1
                  if (delta(i,1)/=0d0) then
                     notzero=notzero+1
                     delta_tmp(i,:)=delta(i,:)
                  else
                     exit
                  endif
               enddo
               do i=1,notzero-1
                  delta(i,:)=delta_tmp(notzero-i,:)
               enddo
               !print*, delta(:,1)

               if (fluxbuild_typ==0) then
                  !print*, leg_in_idx,leg_out_idx,cur0,cur1
                  !print*, delta(:,0)
                  !print*, delta(:,1)
                  !pause
                  delta(0,2)=delta(0,1)
                  do i=0,v_dim-1
                     idx(int(delta(i,0)))=i
                     delta(i,2)=delta(i-1,2)+delta(i,1)
                  enddo
                  !print*, idx(:)
                  !print*, delta(:,0)
                  !print*, "---------------------------------"
                  
                  idx_in=idx(leg_in_idx)
                  loadnum(verdeg+1)=0
                  !print*, weightable(cur0,cur1,typ),delta(idx_in,1)
                  do i=0,v_dim-1
                     leg_out_idx=int(delta(i,0))
                     idx_out=idx(leg_out_idx)

                     dd=delta(idx_in,2)-delta(mod(idx_out-1+v_dim,v_dim),2)+delta(0,1)
                     w0=dd
                     !print*,"0",w0,dd
                     w0=min(w0,delta(idx_in,1)+delta(idx_out,1)-dd)
                     !print*,"1",w0,delta(idx_in,1)+delta(idx_out,1)-dd
                     w0=min(w0,delta(idx_in,1))
                     !print*,"2", w0,delta(idx_in,1)
                     w0=min(w0,delta(idx_out,1))
                     !print*,"3", w0,delta(idx_out,1)
                     w0=max(w0,0d0)
                     fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,mu_mark,1)=w0
                     
                     flux_idx=loadnum(verdeg+1)-1
                     if (w0/=0d0) then
                        !print*, "w0",w0,loadnum(verdeg+1)
                        if (flux_idx==-1) then
                           loadnum(verdeg+1)=loadnum(verdeg+1)+1
                           flux_idx=loadnum(verdeg+1)-1
                           loadtab(flux_idx)=w0
                           loadnum(flux_idx)=1
                           max_cage=max(max_cage,loadnum(flux_idx))
                        else
                           flux_sign=0
                           do j=0,flux_idx
                              !print*, "loadtab",j,loadtab(j),w0,loadtab(j)==w0
                              if (loadtab(j)==w0) then
                                 flux_sign=1
                                 flux_idx=j
                                 loadnum(flux_idx)=loadnum(flux_idx)+1
                                 max_cage=max(max_cage,loadnum(flux_idx))
                                 exit
                              endif
                           enddo
                           if (flux_sign==0) then
                              loadnum(verdeg+1)=loadnum(verdeg+1)+1
                              flux_idx=loadnum(verdeg+1)-1
                              loadtab(flux_idx)=w0
                              loadnum(flux_idx)=1
                              max_cage=max(max_cage,loadnum(flux_idx))
                           endif
                        endif
                        max_type=max(max_type,loadnum(verdeg+1))
                     endif
                  enddo
                  !print*, "flux_idx",cur0,cur1
                  !print*, "flux_idx",loadnum(verdeg+1)!,loadtab(0:loadnum(verdeg+1)-1),loadnum(0:loadnum(verdeg+1)-1)
                  !print*, "flux_idx",max_type,max_cage
                  !print*,"---------------------------------"
                  

                  if (weightable(cur0,cur1,typ)-sum(fluxtamul(cur0,cur1,leg_in_idx,:,mu_mark,1))>=0.00001d0) then
                     print*, "NBC error 0",weightable(cur0,cur1,typ),sum(fluxtamul(cur0,cur1,leg_in_idx,:,mu_mark,1))
                     print*,"----------------------------------------------"
                     pause
                  endif
               elseif (fluxbuild_typ==1) then
                  loadnum(verdeg+1)=-1
                  do i=0,v_dim-1
                     leg_out_idx=int(delta(i,0))
                     idx_out=idx(leg_out_idx)
                     fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,mu_mark,1)=&
                     &dble(delta(leg_out_idx,1)*delta(leg_in_idx,1))/dble(totalweight)
                     !fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,mu_mark,1)=$
                     !$dble(delta(leg_out_idx,1))/dble(totalweight)

                     flux_idx=loadnum(verdeg+1)
                     if (w0/=0d0) then
                        !print*, "w0",w0
                        if (flux_idx==-1) then
                           loadnum(verdeg+1)=loadnum(verdeg+1)+1
                           flux_idx=loadnum(verdeg+1)
                           loadtab(flux_idx)=w0
                           loadnum(flux_idx)=1
                           max_cage=max(max_cage,loadnum(flux_idx))
                        else
                           flux_sign=0
                           do j=0,flux_idx
                              !print*, "loadtab",j,loadtab(j),w0,loadtab(j)==w0
                              if (loadtab(j)==w0) then
                                 flux_sign=1
                                 flux_idx=j
                                 loadnum(flux_idx)=loadnum(flux_idx)+1
                                 max_cage=max(max_cage,loadnum(flux_idx))
                                 exit
                              endif
                           enddo
                           if (flux_sign==0) then
                              loadnum(verdeg+1)=loadnum(verdeg+1)+1
                              flux_idx=loadnum(verdeg+1)
                              loadtab(flux_idx)=w0
                              loadnum(flux_idx)=1
                              max_cage=max(max_cage,loadnum(flux_idx))
                           endif
                        endif
                        max_type=max(max_type,loadnum(verdeg+1))
                     endif
                  enddo
               endif
            enddo
         enddo
      enddo
   enddo
 enddo

 allocate(fluxsut(0:verdeg,0:verdeg,0:vertexdim-1,max_type,lpdimax,2))
 allocate(fluxnum(0:verdeg,0:verdeg,0:vertexdim-1,0:max_type,0:max_cage,lpdimax))

 do mu_mark=1,lpdimax
   v_dim=dxl**mu_mark
   do typ=1,1
      do cur0=0,verdeg
         do cur1=0,verdeg
            if (weightable(cur0,cur1,typ)==0d0) cycle
            do i=0,mxl-1
               state(i,0)=(mod(int(cur0/(2**(i))),2))*2-1
               state(i+mxl,0)=(mod(int(cur1/(2**(i))),2))*2-1
            enddo
            state(:,1)=state(:,0)
            
            do leg_in_idx=0,v_dim-1
               fluxnum(cur0,cur1,leg_in_idx,:,:,mu_mark)=0

               !print*, "==========================",leg_in_idx,mu_mark
               do leg_out_idx=0,v_dim-1
                  w0=fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,mu_mark,1)
                  !print*, "w0=",w0,flux_idx
                  flux_sign=0d0
                  if (w0==0d0) cycle
                  flux_idx=fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)
                  !print*, "w0=",w0,flux_idx
                  if (flux_idx==0) then
                     fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)=&
                     &fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)+1
                     flux_idx=fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)

                     fluxsut(cur0,cur1,leg_in_idx,flux_idx,mu_mark,1:2)=w0
                     fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark)=&
                     &fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark)+1
                     flux_cage=fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark)
                     fluxnum(cur0,cur1,leg_in_idx,flux_idx,flux_cage,mu_mark)=leg_out_idx
                     flux_sign=1
                  else
                     do i=1,flux_idx
                        weight_tmp=fluxsut(cur0,cur1,leg_in_idx,i,mu_mark,1)
                        if (w0==weight_tmp) then
                           fluxnum(cur0,cur1,leg_in_idx,i,0,mu_mark)=&
                           &fluxnum(cur0,cur1,leg_in_idx,i,0,mu_mark)+1
                           fluxsut(cur0,cur1,leg_in_idx,i,mu_mark,2)=&
                           &fluxsut(cur0,cur1,leg_in_idx,i,mu_mark,2)+w0
                           flux_cage=fluxnum(cur0,cur1,leg_in_idx,i,0,mu_mark)
                           fluxnum(cur0,cur1,leg_in_idx,i,flux_cage,mu_mark)=leg_out_idx
                           flux_sign=1
                           exit
                        endif
                     enddo
                     if (flux_sign==0) then
                        fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)=&
                        &fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)+1
                        flux_idx=fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)

                        fluxsut(cur0,cur1,leg_in_idx,flux_idx,mu_mark,1:2)=w0
                        fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark)=&
                        &fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark)+1
                        flux_cage=fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark)
                        fluxnum(cur0,cur1,leg_in_idx,flux_idx,flux_cage,mu_mark)=leg_out_idx
                        flux_sign=1
                     endif
                  endif

                  if (abs(fluxsut(cur0,cur1,leg_in_idx,flux_idx,mu_mark,1)&
                  &*fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark)&
                  &-fluxsut(cur0,cur1,leg_in_idx,flux_idx,mu_mark,2))>0.00001d0) then
                     print*, "mis count", fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark),&
                     &fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark),&
                     &fluxsut(cur0,cur1,leg_in_idx,flux_idx,mu_mark,1),&
                     &fluxsut(cur0,cur1,leg_in_idx,flux_idx,mu_mark,1)&
                     &*fluxnum(cur0,cur1,leg_in_idx,flux_idx,0,mu_mark),&
                     &fluxsut(cur0,cur1,leg_in_idx,flux_idx,mu_mark,2)
                     pause
                  endif

               enddo

               flux_idx=fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)
               if (weightable(cur0,cur1,typ)-&
               &sum(fluxsut(cur0,cur1,leg_in_idx,1:flux_idx,mu_mark,2))>=0.00001d0) then
                  print*, "NBC error",weightable(cur0,cur1,typ),&
                  &sum(fluxsut(cur0,cur1,leg_in_idx,1:flux_idx,mu_mark,2))
                  print*,"----------------------------------------------"
                  print*, "NBC error",flux_idx,fluxsut(cur0,cur1,leg_in_idx,1:flux_idx,mu_mark,2)
                  print*,"----------------------------------------------"
                  print*, "NBC error",sum(fluxtamul(cur0,cur1,leg_in_idx,:,mu_mark,1))
                  pause
               endif

               flux_idx=fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)
               do i=1, flux_idx
                  flux_cage=fluxnum(cur0,cur1,leg_in_idx,i,0,mu_mark)
                  weight_tmp=fluxsut(cur0,cur1,leg_in_idx,i,mu_mark,1)
                  do j=1, flux_cage
                     leg_out_idx=fluxnum(cur0,cur1,leg_in_idx,i,j,mu_mark)
                     w0=fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,mu_mark,1)
                     if (w0==weight_tmp) then
                     else
                        print*, "fluxmul error",w0,weight_tmp,fluxnum(cur0,cur1,leg_in_idx,0,0,mu_mark)
                        pause
                     endif
                  enddo
               enddo
               
               ! do leg_out_idx=0,v_dim-1
               !    if (fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,mu_mark,1)==0) then
               !       cycle
               !    else
               !       leg_out_0=leg_out_idx
               !       do j=1,mu_mark
               !          dim_dxl=dxl**(j-1)
               !          leg_out(j-1)=mod(int(leg_out_0/dim_dxl),dxl)
               !          state(leg_out(j-1),1)=-state(leg_out(j-1),1)
               !       enddo

               !       cur2=0d0
               !       cur3=0d0
               !       do i=0,mxl-1
               !          cur2=cur2+int((state(i,1)+1)*0.5d0)*2**(i)
               !          cur3=cur3+int((state(i+mxl,1)+1)*0.5d0)*2**(i)
               !       enddo
               !       weight_tmp=weightable(cur2,cur3,typ)
               !       if (weight_tmp==0) then
               !          print*, "weight error"
               !          pause
               !       endif

               !       do j=1,mu_mark
               !          state(leg_out(j-1),1)=-state(leg_out(j-1),1)
               !       enddo
               !    endif
               ! enddo
               
               ! !print*, "---------------------------------"

               ! fluxtamul(cur0,cur1,leg_in_idx,:,mu_mark,2)=0d0
               ! option=0
               ! do i=0,v_dim-1
               !    if (i<=v_dim-2) fluxtamul(cur0,cur1,leg_in_idx,i,mu_mark,2)=&
               !    &sum(fluxtamul(cur0,cur1,leg_in_idx,i+1:v_dim-1,mu_mark,1))
               !    if (fluxtamul(cur0,cur1,leg_in_idx,i,mu_mark,1)/=0) then
               !       option=option+1
               !    endif
               ! enddo
               ! !print*, "---------------------------------3"

               ! if (weightable(cur0,cur1,typ)-sum(fluxtamul(cur0,cur1,leg_in_idx,:,mu_mark,1))>=0.00001d0) then
               !    print*, "NBC error",weightable(cur0,cur1,typ),sum(fluxtamul(cur0,cur1,leg_in_idx,:,mu_mark,1))&
               !    &,totalweight,delta(leg_in_idx,1)
               !    print*,"----------------------------------------------"
               !    ! print*, "NBC error",fluxtamul(cur0,cur1,leg_in_idx,:,mu_mark,1)
               !    ! print*,"----------------------------------------------"
               !    ! print*, "NBC error",delta(:,0)
               !    ! print*,"----------------------------------------------"
               !    ! print*, "NBC error",delta(:,1)
               !    ! print*,"----------------------------------------------"
               !    ! print*, "NBC error",delta(:,2)
               !    pause
               ! endif

               if (rank==0d0) then
                  write(10,*)"----------------------------------------------"
                  write(10,*)"state 1",cur1,state(mxl:dxl-1,0)
                  write(10,*)"state 0",cur0,state(0:mxl-1,0)
                  write(10,*)"option",option
                  write(10,*)"+++++++++++++++++++++++++++++++++++++++++++++++"
                  write(10,*)"leg in=",leg_in_idx,mod(leg_in_idx,dxl),int(leg_in_idx/dxl),"w=",weightable(cur0,cur1,typ)
                  do leg_out_idx=0,v_dim-1
                     write(10,*)"----------------------------------------------"
                     write(10,*)"state 1",cur1,state(mxl:dxl-1,0)
                     write(10,*)"state 0",cur0,state(0:mxl-1,0)
                     write(10,*)"leg in=",leg_in_idx,mod(leg_in_idx,dxl),int(leg_in_idx/dxl),"w=",weightable(cur0,cur1,typ)
                     write(10,*)"leg out=",leg_out_idx,mod(leg_out_idx,dxl),int(leg_out_idx/dxl)
                     write(10,*)"leg out 0",fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,mu_mark,1)
                     write(10,*)"leg out 1",fluxtamul(cur0,cur1,leg_in_idx,leg_out_idx,mu_mark,2)
                     write(10,*)"=============================================="
                  enddo
               endif

            enddo
         enddo
      enddo
   enddo
   if (rank==0d0) then
      close(10)
   endif
 enddo
 print*, "BC Mul done"
 !pause
 end subroutine initfluxmul
!----------------------!

!==================================================!
subroutine initspingrp(i,j,typ)

   use configuration
   implicit none

   integer :: b,op,s0,s1,s2,v0,dv,v1,v2,i,j,k,l,typ,sig,a,s,tmp
   integer :: sitin,spother,sitcr,m,spinpro,m2,lpnum,totalspin
   integer :: l0,l1,l2,l3,ph,g_indx
   integer :: cur0,cur1,g_0,g_1,g_i,bt_0,bt_1,bt
   integer, allocatable :: state(:)
   real(8), external :: ran

   allocate(state(0:dxl-1))

   op=opstring(i)
   sig=mod(op,2)
   b=op/8
   !if (sig==0) then
      !dealtyp(j)=2
      !offoporder(0)=offoporder(0)+1
      !offoporder(offoporder(0))=i
   !else
      !dealtyp(j)=2
      !offoporder(0)=offoporder(0)+1
      !offoporder(offoporder(0))=i
   !endif
   !if (b==bb0 .or. b==sitnum+bb0 .or. b==bb1 .or. b==sitnum+bb1 .or. b==bb2 .or. b==sitnum+bb2) then

   if (sig==0) then
      !dealtyp(j)=2
      !digoporder(0)=digoporder(0)+1
      !digoporder(digoporder(0))=i
      if (b==bb0 .or. b==bb0+sitnum) then
         dealtyp(j)=2
         !digoporder(0)=digoporder(0)+1
         !digoporder(digoporder(0))=i
      else
         dealtyp(j)=2
         !digoporder(0)=digoporder(0)+1
         !digoporder(digoporder(0))=i
      endif
   else
      !if (b==bb0 .or. b==bb0+sitnum) then
         !if (ofcc<=6) then
            !dealtyp(j)=4
            !offoporder(0)=offoporder(0)+1
            !offoporder(offoporder(0))=i
            !ofcc=ofcc+1
         !else
            !dealtyp(j)=2
         !endif
      !else
         dealtyp(j)=2
         !offoporder(0)=offoporder(0)+1
         !offoporder(offoporder(0))=i
      !endif
   endif

   cur0=0
   cur1=0
   do k=0,mxl-1
      s1=int((vertexspin(k,i)+1d0)*0.5d0)
      s0=int((vertexspin(k,i)*opstfp(i,k)+1d0)*0.5d0)
      
   !   print*,s0,s1,k
      state(k)=s0
      state(k+mxl)=s1

      cur0=cur0+s0*2**k
      cur1=cur1+s1*2**k
   enddo
   if (spingrploc(b,0)==0) then
      k=int(ran()*vextag(cur0,cur1,0,0,typ))+1
      g_0=vextag(cur0,cur1,0,k,typ)
      spingrploc(b,0)=g_0
      !print*, "pre spingrploc",k,cur0,cur1,spingrpidx(cur0,cur1,0,:,typ)
      !print*, "pre spingrploc",k,cur0,cur1,spingrpidx(cur0,cur1,1,:,typ)
      !print*, "pre spingrploc",k,cur0,cur1,spingrpidx(cur0,cur1,2,:,typ)
      !print*, "make spingrploc",g_0,"b=",b,sig,"state",state(0:dxl-1)
   else
      g_0=spingrploc(b,0)
      !print*, "load spingrploc",g_0,"b=",b,sig,"state",state(0:dxl-1)
   endif
   !print*,cur0,cur1
   !print*, "tag 1",vextag(cur0,cur1,1,0:3,typ)
   !print*, "tag 0",vextag(cur0,cur1,0,0:3,typ)
   if (cur0==cur1) then
      g_1=g_0
   else
      g_1=g_0
      !if (vextag(cur0,cur1,0,0,typ)==vextag(cur0,cur1,1,0,typ)) then
      !   if (vextag(cur0,cur1,0,0,typ)==3) then
      !      g_1=g_0
      !   elseif (vextag(cur0,cur1,0,0,typ)==2) then
      !      g_i=vextag(cur0,cur1,2,0,typ)
      !      if (g_i==g_0) then
      !         do k=1,2
      !            if (vextag(cur0,cur1,1,k,typ)/=g_i) then
      !               g_1=vextag(cur0,cur1,1,k,typ)
      !               exit
      !            endif
      !         enddo
      !      elseif (g_i/=g_0) then
      !         g_1=g_i
      !      endif
      !   endif
      !endif
   endif
   spingrploc(b,0)=g_1
   bt_0=vextag(cur0,cur1,3,g_0,typ)
   bt_1=vextag(cur0,cur1,4,g_1,typ)
   bt=max(bt_0,bt_1)
   if (bt==4) then
      !print*, "bt=4",bt_0,bt_1,b
      !if (cur0==cur1) then
         !dealtyp(j)=0
         !digoporder(0)=digoporder(0)+1
         !digoporder(digoporder(0))=i
      !else
         !dealtyp(j)=4
         !offoporder(0)=offoporder(0)+1
         !offoporder(offoporder(0))=i
      !endif
      !pause
   endif
   !if ((g_0>=1 .and. g_0<=3) .and. (g_1>=1 .and. g_1<=3)) then
   !   print*, "g_0,g_1",g_0,g_1,cur0,cur1
   !else
   !   print*, "error",cur0,cur1,g_0,g_1
   !   pause
   !endif
   !if (spingrpidx(cur0,cur1,g_0,g_1,bt,0,typ)<=0) then
   !   print*, "error spingrpidx",bt,spingrpidx(cur0,cur1,g_0,g_1,bt,0,typ),spingrpidx(cur0,cur1,g_1,g_0,bt,0,typ)
   !   pause
   !endif
   m=spingrpidx(cur0,cur1,g_0,g_1,bt,1,typ)
   ph=spingrpidx(cur0,cur1,g_0,g_1,bt+1,1,typ)
   !print*, "m,ph",m,ph
   spingrp(:,i,0)=spingrptab(cur0,cur1,m,ph,0:dxl-1,0,typ)
   spingrp(:,i,1)=spingrptab(cur0,cur1,m,ph,0:dxl-1,1,typ)
   spingrp(:,i,2)=spingrptab(cur0,cur1,m,ph,0:dxl-1,2,typ)

   if (spingrp(0,i,0)==0d0 .or. spingrp(0,i,0)<0) then
      print*, "error spingrp(0,i,1)==0d0",cur0,cur1,m,grpbondnum,ph,grpbondepth
      print*, "error spingrp(0,i,1)",spingrptab(cur0,cur1,m,ph,0:dxl-1,0,typ)
      pause
   endif

   ! print*, "i=",i,k,typ,cur0,cur1
   ! print*, "spingrptab",spingrptab(cur0,cur1,g_0,g_1,0:dxl-1,0,typ)
   ! print*, "spingrp",spingrp(:,i,0)
   ! print*, "spingrp",spingrp(:,i,1)
   ! print*, "spingrp",spingrp(:,i,2)
   ! print*, "+++++++++++++++++++++++++"
end subroutine initspingrp
!==================================================!

 subroutine initspingroup(signal,rank)
 !-----------------------------------------------------------!
 ! phase factors for fourier transforms of spin configuration
 !-----------------------------------------------------------!
  use configuration
  use vertexupdate
  implicit none
  integer :: signal,typ,cur0,cur1,leg_in,leg_out,rank,option
  integer :: i,j,k,l,a,cur2,cur3,leg_tmp,leg_tmp1,idx,lpnum,s0,s1
  integer :: site_1,site_2,bond_1,site_t,bondtyp
  integer :: site_3,site_4,bond_2,site_k
  integer :: g_0,g_1,sqrtyp
  real(8) :: w0,w2,w1,jptmp,w3,weight_tmp,weight_tmp1,dd,totalweight
  character(11) :: linkname
  integer, allocatable :: state(:,:)
  integer, allocatable :: bonding(:)
  allocate(state(0:dxl-1,0:1))
  allocate(bonding(0:dxl-1))


  if (signal==0) then
   allocate(spingrptab(0:verdeg,0:verdeg,0:grpbondnum,grpbondepth,0:dxl-1,0:2,4))
   allocate(spingrpidx(0:verdeg,0:verdeg,btn,btn,0:5,0:btn,4))
   allocate(vextag(0:verdeg,0:verdeg,0:4,0:btn,4))
  endif
  spingrptab(:,:,:,:,:,:,:)=0d0
  spingrpidx(:,:,:,:,:,:,:)=-1d0
  vextag(:,:,:,:,:)=0d0
 
  do typ=1,4
    do cur0=0,verdeg
       do cur1=0,verdeg
         if (weightable(cur0,cur1,typ)==0) then
            cycle
         else
            idx=0
            bonding(:)=0d0
            do i=0,mxl-1
               state(i,0)=(mod(int(cur0/(2**(i))),2))*2-1
               state(i+mxl,0)=(mod(int(cur1/(2**(i))),2))*2-1
               if (state(i,0)/=state(i+mxl,0)) then
                  idx=idx+1
                  bonding(i)=1
               endif
            enddo
            state(:,1)=state(:,0)
            do i=0,1
               !print*, "state",i,state(0+i*mxl:mxl-1+i*mxl,0)
               !print*, abs(sum(state(0+i*mxl:mxl-1+i*mxl,0))),mxl+1,mxl-1,0
               if (abs(sum(state(0+i*mxl:mxl-1+i*mxl,0)))==mxl) then
                  vextag(cur0,cur1,i,0,typ)=0

                  vextag(cur0,cur1,i+3,1,typ)=4
                  vextag(cur0,cur1,i+3,2,typ)=4
                  vextag(cur0,cur1,i+3,3,typ)=4
               elseif (abs(sum(state(0+i*mxl:mxl-1+i*mxl,0)))==mxl-2) then
                  vextag(cur0,cur1,i,0,typ)=3
                  vextag(cur0,cur1,i,1,typ)=1
                  vextag(cur0,cur1,i,2,typ)=2
                  vextag(cur0,cur1,i,3,typ)=3

                  
                  vextag(cur0,cur1,i+3,1,typ)=2
                  vextag(cur0,cur1,i+3,2,typ)=2
                  vextag(cur0,cur1,i+3,3,typ)=2
               elseif (abs(sum(state(0+i*mxl:mxl-1+i*mxl,0)))==0) then
                  vextag(cur0,cur1,i,0,typ)=2
                  if (state(0+i*mxl,0)==state(1+i*mxl,0)) then
                     vextag(cur0,cur1,i,1,typ)=2
                     vextag(cur0,cur1,i,2,typ)=3
                     
                     vextag(cur0,cur1,i+3,1,typ)=4
                     vextag(cur0,cur1,i+3,2,typ)=2
                     vextag(cur0,cur1,i+3,3,typ)=2
                  elseif (state(0+i*mxl,0)==state(2+i*mxl,0)) then
                     vextag(cur0,cur1,i,1,typ)=1
                     vextag(cur0,cur1,i,2,typ)=2
                     
                     vextag(cur0,cur1,i+3,1,typ)=2
                     vextag(cur0,cur1,i+3,2,typ)=2
                     vextag(cur0,cur1,i+3,3,typ)=4
                  elseif (state(0+i*mxl,0)==state(3+i*mxl,0)) then
                     vextag(cur0,cur1,i,1,typ)=1
                     vextag(cur0,cur1,i,2,typ)=3
                     
                     vextag(cur0,cur1,i+3,1,typ)=2
                     vextag(cur0,cur1,i+3,2,typ)=4
                     vextag(cur0,cur1,i+3,3,typ)=2
                  endif
               endif
            enddo
            if (idx==0) then
               vextag(cur0,cur1,2,0,typ)=0
            elseif (idx==2) then
               if (bonding(0)==bonding(1) .and. bonding(2)==bonding(3)) then
                  vextag(cur0,cur1,2,0,typ)=1
               elseif (bonding(0)==bonding(3) .and. bonding(1)==bonding(2)) then
                  vextag(cur0,cur1,2,0,typ)=2
               elseif (bonding(0)==bonding(2) .and. bonding(1)==bonding(3)) then
                  vextag(cur0,cur1,2,0,typ)=3
               endif
            endif
!==================================================================
            if (cur0==cur1 .or. idx==2) then
               spingrpidx(cur0,cur1,:,:,:,0,typ)=0
               do i=0,grpbondnum
                  bonding(:)=0d0
                  if (i==0) then
                     lpnum=1
                     do j=0,mxl-1
                        spingrptab(cur0,cur1,i,1,j,0,typ)=mod(j+mxl,dxl)
                        spingrptab(cur0,cur1,i,1,mod(j+mxl,dxl),0,typ)=j
                        spingrptab(cur0,cur1,i,1,j,1,typ)=lpnum
                        spingrptab(cur0,cur1,i,1,mod(j+mxl,dxl),1,typ)=lpnum
                        spingrptab(cur0,cur1,i,1,lpnum,2,1)=1
                        bonding(j)=lpnum
                        lpnum=lpnum+1
                     enddo
                     spingrptab(cur0,cur1,i,0,0,2,typ)=lpnum-1
                     bondtyp=0
                  else
                     lpnum=1
                     option=0
                     g_0=mod((i-1),btn)+1
                     g_1=int((i-1)/btn)+1
                     if (cur0==cur1 .and. g_0/=g_1) cycle
                     !print*, "option",option,"grpbondepth",grpbondepth
                     do j=1,grpbondepth
                        lpnum=1
                        !print*, "option",option
                        do a=1,grpbondepth
                           bond_1=vexgrptab(i,j,a,0,typ)
                           bond_2=vexgrptab(i,j,a,1,typ)
                           if (bond_1<0 .or. bond_2<0) cycle
                           site_1=bondtab(1,bond_1,1)
                           site_2=bondtab(2,bond_1,1)
                           site_3=bondtab(1,bond_2,1)+mxl
                           site_4=bondtab(2,bond_2,1)+mxl
                           !print*, "site 1 2", bond_1,site_1,site_2
                           !if (site_1==site_2 .or. site_3==site_4) pause

                           state(site_1,1)=-state(site_1,1)
                           state(site_3,1)=-state(site_3,1)
                           state(site_2,1)=-state(site_2,1)
                           state(site_4,1)=-state(site_4,1)
                           !print*, "state 1", state(0:mxl-1,1)
                           cur2=0d0
                           cur3=0d0
                           do k=0,mxl-1
                              s1=int((state(k,1)+1d0)*0.5d0)
                              s0=int((state(k+mxl,1)+1d0)*0.5d0)
                              cur2=cur2+s0*2**k
                              cur3=cur3+s1*2**k
                           enddo
                           !print*, weightable(cur2,cur3,typ)==weightable(cur0,cur1,typ)&
                           !&,cur0,cur1,cur2,cur3!,&
                           !&weightable(cur2,cur3,typ),weightable(cur0,cur1,typ)
                           if (weightable(cur2,cur3,typ)==weightable(cur0,cur1,typ)) then
                              option=option+1
                              !if (option>=3) then
                              !   print*, "option",option
                              !   pause
                              !endif
                              do l=1,2
                                 site_t=bondtab(l,bond_1,typ)
                                 site_k=bondtab(l,bond_2,typ)+mxl
                                 !print*, bond_1,site_t, bond_2,site_k
                                 !if (site_t<0 .or. site_k<0) pause
                                 bonding(site_t)=bond_1
                                 bonding(site_k)=bond_2
                                 spingrptab(cur0,cur1,i,j,site_t,0,typ)=site_k
                                 spingrptab(cur0,cur1,i,j,site_k,0,typ)=site_t
                                 spingrptab(cur0,cur1,i,j,site_t,1,typ)=lpnum
                                 spingrptab(cur0,cur1,i,j,site_k,1,typ)=lpnum
                              enddo
                              spingrptab(cur0,cur1,i,j,lpnum,2,1)=2
                              lpnum=lpnum+1
                              bondtyp=1
                           else
                              bondtyp=2
                           endif
                           state(site_1,1)=-state(site_1,1)
                           state(site_3,1)=-state(site_3,1)
                           state(site_2,1)=-state(site_2,1)
                           state(site_4,1)=-state(site_4,1)
                           if (bondtyp==2) then
                              exit
                           endif
                        enddo
                        if (bondtyp==2) then
                           lpnum=1
                           do l=0,mxl-1
                              bonding(l)=bond_1
                              spingrptab(cur0,cur1,i,j,l,0,typ)=mod(l+mxl,dxl)
                              spingrptab(cur0,cur1,i,j,mod(l+mxl,dxl),0,typ)=l
                              spingrptab(cur0,cur1,i,j,l,1,typ)=lpnum
                              spingrptab(cur0,cur1,i,j,mod(l+mxl,dxl),1,typ)=lpnum
                           enddo
                           spingrptab(cur0,cur1,i,j,0,2,1)=1
                           spingrptab(cur0,cur1,i,j,1,2,1)=mxl
                           spingrptab(cur0,cur1,i,j,2:mxl-1,2,1)=0
                        else
                           idx=0
                           do l=0,mxl-1
                              if (bonding(l)==0) then
                                 spingrptab(cur0,cur1,i,j,l,0,typ)=mod(l+mxl,dxl)
                                 spingrptab(cur0,cur1,i,j,mod(l+mxl,dxl),0,typ)=l
                                 spingrptab(cur0,cur1,i,j,l,1,typ)=lpnum
                                 spingrptab(cur0,cur1,i,j,mod(l+mxl,dxl),1,typ)=lpnum
                                 idx=idx+1
                              endif
                           enddo
                           if (idx>0) then
                              spingrptab(cur0,cur1,i,j,lpnum,2,1)=idx
                              spingrptab(cur0,cur1,i,j,0,2,1)=lpnum
                           endif
                        endif
                        !print*, "state 1", state(mxl:dxl-1,1)
                        !print*, "state 0", state(0:mxl-1,1)
                        !print*,"0",spingrptab(cur0,cur1,i,j,0:dxl-1,0,typ)
                        !print*,"1",spingrptab(cur0,cur1,i,j,0:dxl-1,1,typ)
                        !print*,"2",spingrptab(cur0,cur1,i,j,0:dxl-1,2,typ)
                        !print*,"================================================"
                        !if (spingrptab(cur0,cur1,i,j,0,1,typ)<=0) then
                        !   print*, "error spingrptab",cur0,cur1,i,j
                        !
                        !endif
                        
                        spingrpidx(cur0,cur1,g_0,g_1,2*bondtyp,0,typ)=spingrpidx(cur0,cur1,g_0,g_1,2*bondtyp,0,typ)+1
                        idx=spingrpidx(cur0,cur1,g_0,g_1,2*bondtyp,0,typ)
                        spingrpidx(cur0,cur1,g_0,g_1,2*bondtyp,idx,typ)=i
                        spingrpidx(cur0,cur1,g_0,g_1,2*bondtyp+1,idx,typ)=j
                     
                     enddo
                  endif
               enddo
            endif
         endif

          !print*, "cur0",cur0,"cur1",cur1 
          !print*, "state 1", state(mxl:dxl-1,1)
          !print*, "state 0", state(0:mxl-1,1)
          !k=vextag(cur0,cur1,0,0,typ)
          !print*,"tag 0",k,vextag(cur0,cur1,0,1:k,typ)
          !k=vextag(cur0,cur1,1,0,typ)
          !print*,"tag 1",k,vextag(cur0,cur1,1,1:k,typ)
          !print*,"tag 2",vextag(cur0,cur1,2,0,typ)
          !do j=1,btn
          !   do i=1,btn
                !g_0=mod((i-1),btn)+1
                !g_1=int((i-1)/btn)+1
                !print*, "0",i,"1",j
                !print*,spingrpidx(cur0,cur1,i,j,0,0,typ)
                !print*,spingrpidx(cur0,cur1,i,j,2,0,typ)
                !print*,spingrpidx(cur0,cur1,i,j,4,0,typ)
                !print*, "+++++++++++++++++++++++++++++++++"
                !do l=1,k
                !   g_0=spingrpidx(cur0,cur1,i,j,2,l,typ)
                !   g_1=spingrpidx(cur0,cur1,i,j,3,l,typ)
                !   print*,"0",spingrptab(cur0,cur1,g_0,g_1,0:dxl-1,0,typ)
                !   print*,"1",spingrptab(cur0,cur1,g_0,g_1,0:dxl-1,1,typ)
                !   print*,"2",spingrptab(cur0,cur1,g_0,g_1,0:dxl-1,2,typ)
                !   print*, "--------------------------------"
                !enddo
          !   enddo
          !enddo
          !print*, "--------------------------------"

       enddo
    enddo
  enddo

  !pause

   !  do typ=1,4
   !   do cur0=0,verdeg
   !      do cur1=0,verdeg
   !        if (weightable(cur0,cur1,typ)==0) then
   !           cycle
   !        else
   !           idx=0
   !           do i=0,mxl-1
   !              state(i,0)=(mod(int(cur0/(2**(i))),2))*2-1
   !              state(i+mxl,0)=(mod(int(cur1/(2**(i))),2))*2-1
   !              if (state(i,0)/=state(i+mxl,0)) then
   !                 state(idx,1)=i
   !                 idx=idx+1
   !              endif
   !           enddo
   !           state(:,1)=state(:,0)
   !           bonding(:)=0d0
   !           if (cur0==cur1 .or. idx==2) then
   !              do i=0,grpbondnum
   !                 print*,"---------------------------------"
   !                 print*, "cur0",cur0,"cur1",cur1,"bond",i,"bondgrp",vexgrptab(i,0:grpbondepth,1)
   !                 print*, spingrpidx(cur0,cur1,0,:,typ)
   !                 print*, spingrpidx(cur0,cur1,1,:,typ)
   !                 print*, spingrpidx(cur0,cur1,2,:,typ)
   !                 print*, state(mxl:dxl-1,0)
   !                 print*, state(0:mxl-1,0)
   !                 print*, spingrptab(cur0,cur1,i,mxl:dxl-1,0,typ)
   !                 print*, spingrptab(cur0,cur1,i,0:mxl-1,0,typ)
   !                 print*, spingrptab(cur0,cur1,i,mxl:dxl-1,1,typ)
   !                 print*, spingrptab(cur0,cur1,i,0:mxl-1,1,typ)
   !                 print*, spingrptab(cur0,cur1,i,:,2,typ)
   !              enddo
   !           endif
   !        endif
   !      enddo
   !   enddo
   ! enddo

  end subroutine initspingroup
!----------------------!

 subroutine initvexgrptab()
!-----------------------------------------------------------!
  use configuration
  use vertexupdate
  implicit none
  integer :: i,j,k,l
  integer :: b_0,b_1,g_0,g_1

  if (bondmaker==0) then
   allocate(bondgrp(0:1,0:1,4))
   bondgrp(:,:,:)=0d0
   grpbondnum=1
   grpbondepth=1
   bondgrp(0,0,1)=mxl
   !------------------!
   bondgrp(1,0,1)=0
   bondgrp(1,1,1)=1
  elseif (bondmaker==1) then
   allocate(bondgrp(0:3,0:1,4))
   bondgrp(:,:,:)=0d0
   grpbondnum=3
   grpbondepth=1
   bondgrp(0,0,1)=mxl
   !------------------!
   bondgrp(1,0,1)=1
   bondgrp(1,1,1)=1
   !------------------!
   bondgrp(2,0,1)=1
   bondgrp(2,1,1)=2
   !------------------!
   bondgrp(3,0,1)=1
   bondgrp(3,1,1)=3
  elseif (bondmaker==2) then
   allocate(bondgrp(0:3,0:2,4))
   bondgrp(:,:,:)=0d0
   grpbondnum=3
   grpbondepth=2
   bondgrp(0,0,1)=mxl
   !------------------!
   bondgrp(1,0,1)=0
   bondgrp(1,1,1)=1
   bondgrp(1,2,1)=3
   !------------------!
   bondgrp(2,0,1)=0
   bondgrp(2,1,1)=2
   bondgrp(2,2,1)=4
   !------------------!
   bondgrp(3,0,1)=0
   bondgrp(3,1,1)=5
   bondgrp(3,2,1)=6
   !------------------!
  elseif (bondmaker==3) then
   allocate(bondgrp(0:15,0:2,4))
   bondgrp(:,:,:)=0d0
   grpbondnum=15
   grpbondepth=2
   bondgrp(0,0,1)=mxl
   !------------------!
   bondgrp(1,0,1)=3
   bondgrp(1,1,1)=2
   bondgrp(1,2,1)=8
   !------------------!
   bondgrp(2,0,1)=3
   bondgrp(2,1,1)=2
   bondgrp(2,2,1)=9
   !------------------!
   bondgrp(3,0,1)=3
   bondgrp(3,1,1)=2
   bondgrp(3,2,1)=12
   !------------------!
   bondgrp(4,0,1)=3
   bondgrp(4,1,1)=3
   bondgrp(4,2,1)=8
   !------------------!
   bondgrp(5,0,1)=3
   bondgrp(5,1,1)=3
   bondgrp(5,2,1)=9
   !------------------!
   bondgrp(6,0,1)=3
   bondgrp(6,1,1)=3
   bondgrp(6,2,1)=12
   !------------------!
   bondgrp(7,0,1)=3
   bondgrp(7,1,1)=6
   bondgrp(7,2,1)=8
   !------------------!
   bondgrp(8,0,1)=3
   bondgrp(8,1,1)=6
   bondgrp(8,2,1)=9
   !------------------!
   bondgrp(9,0,1)=3
   bondgrp(9,1,1)=6
   bondgrp(9,2,1)=12
   !------------------!
   bondgrp(10,0,1)=5
   bondgrp(10,1,1)=2
   bondgrp(10,2,1)=-1
   !------------------!
   bondgrp(11,0,1)=5
   bondgrp(11,1,1)=3
   bondgrp(11,2,1)=-1
   !------------------!
   bondgrp(12,0,1)=5
   bondgrp(12,1,1)=6
   bondgrp(12,2,1)=-1
   !------------------!
   bondgrp(13,0,1)=5
   bondgrp(13,1,1)=8
   bondgrp(13,2,1)=-1
   !------------------!
   bondgrp(14,0,1)=5
   bondgrp(14,1,1)=9
   bondgrp(14,2,1)=-1
   !------------------!
   bondgrp(15,0,1)=5
   bondgrp(15,1,1)=12
   bondgrp(15,2,1)=-1
   !------------------!
  elseif (bondmaker==4) then
   allocate(bondgrp(3,0:1,4))
   bondgrp(:,:,:)=0d0
   grpbondnum=3
   grpbondepth=1
   bondgrp(0,0,1)=mxl
   !------------------!
   bondgrp(1,0,1)=4
   bondgrp(1,1,1)=4
   !------------------!
   bondgrp(2,0,1)=4
   bondgrp(2,1,1)=5
   !------------------!
   bondgrp(3,0,1)=4
   bondgrp(3,1,1)=6
   !------------------!
  endif

  btn=grpbondnum
  grpbondnum=grpbondnum*grpbondnum
  allocate(vexgrptab(0:grpbondnum,0:grpbondepth,0:grpbondepth,0:1,4))
  vexgrptab(:,:,:,:,:)=0
  do i=1, grpbondnum
   g_0=mod(i-1,btn)+1
   g_1=int((i-1)/btn)+1

   do k=1,grpbondepth
      do l=1,grpbondepth
         b_0=l
         b_1=mod(b_0-1+k-1,grpbondepth)+1
         b_0=bondgrp(g_0,b_0,1)
         b_1=bondgrp(g_1,b_1,1)
         vexgrptab(i,k,l,0,1)=b_0
         vexgrptab(i,k,l,1,1)=b_1
      enddo
      !print*, vexgrptab(i,k,:,0,1)
      !print*, vexgrptab(i,k,:,1,1)
      !print*, "+++++++++++++++++++++"
   enddo
  enddo
  !pause

 end subroutine initvexgrptab
!==================================================!


!==================================================!

subroutine saveconfig(step, ranks, tempidx)
!--------------------------------------!
 use configuration 
 implicit none
 integer :: i,ranks,step,tempidx
 integer :: i1,i2,i3,i4,ni
 character(len=5) :: file_idx
 ni=int(ntem)

 if (step==0) then
   allocate(betable(0:ni))
   if (ranks==0) then
      open(10, file="beta.log", status='replace')
      close(10)
   endif
   do i=0,ni
      if (i<=20) then
         if (mod(i,1)==0) then
            betable(i)=1
            if (ranks==0) call makedir(i)
         else
            betable(i)=0
         endif
      elseif (i<=100) then
         if (mod(i,10)==0) then
            betable(i)=1
            if (ranks==0) call makedir(i)
         else
            betable(i)=0
         endif
      elseif (i<=1000) then
         if (mod(i,100)==0) then
            betable(i)=1
            if (ranks==0) call makedir(i)
         else
            betable(i)=0
         endif
      else
         if (mod(i,100)==0) then
            betable(i)=1
            if (ranks==0) call makedir(i)
         else
            betable(i)=0
         endif
      endif
   enddo
 elseif (step==1) then
   !'conf'//ranks//'.log'
   if (betable(tempidx)==1) then
      call copyconfig(tempidx,ranks)
   endif
 endif


 end subroutine saveconfig
!------------------------!
subroutine makedir(i)
!--------------------------------------!
 use configuration
 implicit none
 integer :: i,rank,step,tempidx
 integer :: i1,i2,i3,i4
 character(len=100) :: file_idx
 character(len=100) :: folder_path, file_path_head, file_path_tail, command1, command2, command3
 file_path_head="./"
 file_idx="0000"

 i1=int(i/1000)
 i2=int(mod(i,1000)/100)
 i3=int(mod(i,100)/10)
 i4=int(mod(i,10))

 file_idx(1:1)=char(i1+48)
 file_idx(2:2)=char(i2+48)
 file_idx(3:3)=char(i3+48)
 file_idx(4:4)=char(i4+48)

 command1="rm -r "//trim(file_path_head)//trim(file_idx)
 command2="mkdir -p "//trim(file_path_head)//trim(file_idx)
 !print*, "command1=", trim(command1)
 !print*, "command2=", trim(command2)
 !pause
 call execute_command_line(trim(command1))
 call execute_command_line(trim(command2))
 
 open(10, file=trim(file_path_head)//trim(file_idx)//'/'//"beta.log", status='new')
 write(10,*) "beta=",temp0+dtem*i
 close(10)
 open(10, file="beta.log", position='append')
 write(10,*) "beta=",temp0+dtem*i, " idx=", trim(file_idx)
 close(10)


 end subroutine makedir
!------------------------!

subroutine copyconfig(i,rank)
!--------------------------------------!
 use configuration
 implicit none
 integer :: i,rank,step,tempidx
 integer :: i1,i2,i3,i4
 character(len=3) :: ranks
 character(len=5) :: file_idx
 character(len=100) :: folder_path, file_path_head, file_path_tail, command1, command2, command3
 file_path_head="./"
 file_idx="0000"
 write (ranks,fmt='(i3.3)') rank

 i1=int(i/1000)
 i2=int(mod(i,1000)/100)
 i3=int(mod(i,100)/10)
 i4=int(mod(i,10))

 file_idx(1:1)=char(i1+48)
 file_idx(2:2)=char(i2+48)
 file_idx(3:3)=char(i3+48)
 file_idx(4:4)=char(i4+48)

 command1="cp -rf "//'./'//'conf'//ranks//'.log'//' '//trim(file_path_head)//trim(file_idx)//'/'
 !print*, "command1=", trim(command1)
 call execute_command_line(trim(command1))


 end subroutine copyconfig
!------------------------!

subroutine timemeasure(i)
   use configuration
   integer :: i

   call cpu_time(time1)

   if (i==0) then
      time0=time1
   elseif (i==1) then
      print*, "time=", time1-time0
      open(10, file="time.log", position='append')
      write(10,*) time1-time0
      close(10)
   elseif (i==2) then
      open(10, file="time.log", status='replace')
      close(10)
   endif

end subroutine timemeasure