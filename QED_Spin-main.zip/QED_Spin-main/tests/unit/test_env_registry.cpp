// =============================================================================
// tests/unit/test_env_registry.cpp
//
// The environment registry (include/ed/core/config.h): one meaning of
// "set" for every value type, no duplicate rows, and the unknown-name scan.
// =============================================================================
#include "common/catch2_harness.h"

#include <cstdlib>
#include <set>
#include <string>

#include <ed/core/config.h>

namespace {
struct ScopedEnv {
    std::string name;
    explicit ScopedEnv(const char* n, const char* v) : name(n) { ::setenv(n, v, 1); }
    ~ScopedEnv() { ::unsetenv(name.c_str()); }
};
}  // namespace

TEST_CASE("env registry: rows are unique and well formed", "[env]") {
    std::set<std::string> seen;
    for (const auto& r : ed::env::rows()) {
        const std::string n = r.name;
        REQUIRE((n.rfind("ED_", 0) == 0 || n.rfind("QED_", 0) == 0));
        REQUIRE(seen.insert(n).second);           // no duplicates
        REQUIRE(std::string(r.meaning).size() > 0);
        REQUIRE(std::string(r.scope).size() > 0);
    }
    REQUIRE(seen.size() > 10);
    REQUIRE(ed::env::is_registered("ED_SYM_SECTOR_CSR_BUDGET_GIB"));
    REQUIRE_FALSE(ed::env::is_registered("ED_SYM_SECTOR_CSR_BUDGET_GIBB"));
}

TEST_CASE("env registry: a flag set to 0 is OFF, presence alone never enables", "[env]") {
    const char* n = "ED_MEM_GUARD_OFF";
    ::unsetenv(n);
    REQUIRE(ed::env::flag(n, false) == false);
    REQUIRE(ed::env::flag(n, true) == true);
    REQUIRE_FALSE(ed::env::tristate(n).has_value());
    // Any case, zero in any integer spelling, trailing blanks: every one parses (not malformed)
    // and every one is off. "False" used to parse but read as ON.
    for (const char* off :
         {"0", "false", "off", "no", "OFF", "False", "Off", "No", "fAlSe", "00", "+0", "-0", "0 ", "false\t"}) {
        ScopedEnv e(n, off);
        INFO(off);
        REQUIRE(ed::env::parses_flag(off));
        REQUIRE(ed::env::flag(n, true) == false);
        REQUIRE(ed::env::tristate(n).value() == false);
    }
    for (const char* on : {"1", "true", "yes", "2", "True", "ON", "Yes", "-1", "01"}) {
        ScopedEnv e(n, on);
        INFO(on);
        REQUIRE(ed::env::parses_flag(on));
        REQUIRE(ed::env::flag(n, false) == true);
    }
    {
        ScopedEnv e(n, "");                        // empty == unset
        REQUIRE(ed::env::flag(n, false) == false);
        REQUIRE(ed::env::flag(n, true) == true);
        REQUIRE_FALSE(ed::env::tristate(n).has_value());
    }
}

TEST_CASE("env registry: a number falls back to the default when unset, empty or unparsable", "[env]") {
    const char* r = "ED_SYM_SECTOR_CSR_BUDGET_GIB";
    ::unsetenv(r);
    REQUIRE(ed::env::real(r, 1e-8) == 1e-8);
    {
        ScopedEnv e(r, "1e-6");
        REQUIRE(ed::env::real(r, 1e-8) == 1e-6);
    }
    {
        ScopedEnv e(r, "");
        REQUIRE(ed::env::real(r, 1e-8) == 1e-8);
    }
    {
        ScopedEnv e(r, "x");
        REQUIRE(ed::env::real(r, 1e-8) == 1e-8);
    }
}

TEST_CASE("env registry: snapshot lists what is set; unknown() catches a misspelt name", "[env]") {
    ScopedEnv good("ED_SYM_SECTOR_CSR_BUDGET_GIB", "7");
    ScopedEnv typo("ED_SYM_SECTOR_CSR_BUDGT_GIB", "7");
    ScopedEnv harness("ED_TEST_HARNESS_VAR", "x");
    bool in_snapshot = false;
    for (const auto& kv : ed::env::snapshot())
        in_snapshot = in_snapshot || (kv.first == "ED_SYM_SECTOR_CSR_BUDGET_GIB" && kv.second == "7");
    REQUIRE(in_snapshot);
    const auto unk = ed::env::unknown();
    const std::set<std::string> u(unk.begin(), unk.end());
    REQUIRE(u.count("ED_SYM_SECTOR_CSR_BUDGT_GIB") == 1);
    REQUIRE(u.count("ED_SYM_SECTOR_CSR_BUDGET_GIB") == 0);
    REQUIRE(u.count("ED_TEST_HARNESS_VAR") == 0);  // harness namespace is not scanned
    REQUIRE(ed::env::dump("ED_SYM_SECTOR_CSR_BUDGET_GIB").find("ED_SYM_SECTOR_CSR_BUDGET_GIB") != std::string::npos);
}
