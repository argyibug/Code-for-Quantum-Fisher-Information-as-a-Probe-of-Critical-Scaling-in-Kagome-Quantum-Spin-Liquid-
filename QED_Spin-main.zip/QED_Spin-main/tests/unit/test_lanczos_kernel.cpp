// =============================================================================
// test_lanczos_kernel (Catch2 v3)
//
// Regression tests for `ed::krylov::lanczos_kernel`, the single Lanczos
// algorithm body shared by the CPU and GPU backends. These tests pin:
//
//   1. Full-CGS2 reorth produces a ground-state Ritz value matching the
//      dense reference on a Heisenberg chain.
//   2. Orthogonality of the returned Krylov basis is preserved at
//      ~ machine epsilon * M (CGS2 guarantee).
//   3. The breakdown path (||w|| < tol) terminates cleanly.
//   4. aux_ortho_ptrs deflation, the convergence_check cadence and
//      misuse rejection.
// =============================================================================

#include "common/catch2_harness.h"

#include <ed/krylov/krylov_schur.h>
#include <ed/krylov/lanczos.h>
#include <ed/krylov/tridiag.h>
#include <ed/matvec/cpu_backend.h>

#include <algorithm>
#include <cmath>
#include <complex>
#include <random>
#include <vector>

#include <Eigen/Dense>
#include <Eigen/Eigenvalues>

using namespace ed_tests;
using ed::krylov::lanczos_kernel;
using ed::krylov::LanczosKernelOptions;
using ed::krylov::ReorthPolicy;
using ed::matvec::default_cpu_backend;
using Complex = std::complex<double>;

namespace {

/// Run the kernel with full CGS2 reorth and a kept basis.
struct KernelResult {
    std::vector<double> alpha;
    std::vector<double> beta;
    ed::krylov::KrylovBasis<Complex> basis;
};

KernelResult run_kernel(const Operator& op, std::size_t dim, const std::vector<Complex>& v0, std::size_t max_iter) {
    LanczosKernelOptions opts;
    opts.max_iter = max_iter;
    opts.reorth = ReorthPolicy::FullCGS2;
    opts.keep_basis = true;

    auto& be = default_cpu_backend();
    auto matvec = [&op](const Complex* in, Complex* out, std::size_t n) { op.apply(in, out, n); };
    auto R = lanczos_kernel(be, matvec, dim, v0.data(), opts);
    KernelResult kr;
    kr.alpha = std::move(R.alpha);
    kr.beta = std::move(R.beta);
    kr.basis = std::move(R.basis);
    return kr;
}

} // namespace

// ----------------------------------------------------------------------------
// Test 1: the full-reorth kernel's lowest Ritz value matches the dense
// ground-state energy of a real Heisenberg chain.
// ----------------------------------------------------------------------------
TEST_CASE("unified Lanczos kernel ground state matches the dense reference", "[krylov][kernel][regression]") {
    constexpr int N = 6;
    constexpr auto dim = std::size_t{1} << N;
    auto op = build_heisenberg_chain(N, /*J=*/1.0, /*periodic=*/true);
    auto ref = reference_from_operator(*op, dim);

    auto v0 = random_unit_vector(dim, /*seed=*/0xC0FFEEu);
    auto kr = run_kernel(*op, dim, v0, /*max_iter=*/40);

    const std::size_t M = kr.alpha.size();
    REQUIRE(M >= 5);
    REQUIRE(kr.beta.size() == M + 1);
    REQUIRE(kr.basis.size() == M);

    Eigen::MatrixXd T = Eigen::MatrixXd::Zero(M, M);
    for (std::size_t i = 0; i < M; ++i) {
        T(i, i) = kr.alpha[i];
        if (i + 1 < M) {
            T(i, i + 1) = kr.beta[i + 1];
            T(i + 1, i) = kr.beta[i + 1];
        }
    }
    Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> es(T);
    REQUIRE(es.info() == Eigen::Success);
    INFO("E0 lanczos=" << es.eigenvalues()(0) << " E0 dense=" << ref.eigs.front());
    REQUIRE(std::abs(es.eigenvalues()(0) - ref.eigs.front()) < 1e-8);
}

// ----------------------------------------------------------------------------
// Test 3: orthogonality of the returned basis.
//
//   ||V^H V - I||_F <= M * eps * something_small
//
// CGS2 typically holds this to ~ M * O(eps). We allow 1e-10 for M=40.
// ----------------------------------------------------------------------------
TEST_CASE("unified Lanczos kernel basis is orthonormal to ~M*eps", "[krylov][kernel][orthogonality]") {
    constexpr int N = 6;
    constexpr auto dim = std::size_t{1} << N;
    auto op = build_heisenberg_chain(N, /*J=*/1.0, /*periodic=*/true);

    auto v0 = random_unit_vector(dim, /*seed=*/0xFACEFEEDu);
    auto kr = run_kernel(*op, dim, v0, /*max_iter=*/40);

    const std::size_t M = kr.basis.size();
    REQUIRE(M >= 5);

    auto& be = default_cpu_backend();
    double max_off_diag = 0.0;
    double max_diag_err = 0.0;
    for (std::size_t i = 0; i < M; ++i) {
        for (std::size_t j = i; j < M; ++j) {
            const Complex z = be.dot(kr.basis[i], kr.basis[j], dim);
            const double mag = std::abs(z);
            if (i == j) {
                max_diag_err = std::max(max_diag_err, std::abs(mag - 1.0));
            } else {
                max_off_diag = std::max(max_off_diag, mag);
            }
        }
    }
    INFO("M=" << M << " max_off_diag=" << max_off_diag << " max_diag_err=" << max_diag_err);
    REQUIRE(max_off_diag < 1e-10);
    REQUIRE(max_diag_err < 1e-12);
}

// ----------------------------------------------------------------------------
// Test 4: Breakdown path. A 1-D Hilbert space (e.g. fully-polarised
// single-state sector) should immediately break down after one step.
// ----------------------------------------------------------------------------
TEST_CASE("unified Lanczos kernel handles trivial 1-state breakdown", "[krylov][kernel][edge]") {
    // Synthetic: a "matvec" that returns 0 on dim=1 simulates an
    // invariant subspace. Real Heisenberg N=1 has dim=2; we use a
    // hand-rolled 1-D op so the test is deterministic.
    auto& be = default_cpu_backend();

    auto matvec = [](const Complex* in, Complex* out, std::size_t n) {
        // H = 0; w = 0 -> beta_1 = 0 -> breakdown.
        std::fill(out, out + n, Complex{0, 0});
        (void)in;
    };

    std::vector<Complex> v0 = {Complex{1.0, 0.0}};

    LanczosKernelOptions opts;
    opts.max_iter = 20;
    opts.reorth = ReorthPolicy::FullCGS2;
    opts.keep_basis = true;

    auto R = lanczos_kernel(be, matvec, /*local_n=*/1, v0.data(), opts);

    // alpha[0] = <v, 0> = 0; beta[1] = ||0|| = 0; loop breaks.
    REQUIRE(R.iters_done == 1);
    REQUIRE(R.alpha.size() == 1);
    REQUIRE(R.alpha[0] == 0.0);
    REQUIRE(R.beta.size() == 2);
    REQUIRE(R.beta[1] == 0.0);
}

// ----------------------------------------------------------------------------
// Test: `aux_ortho_ptrs` enforces orthogonality of the entire basis
// against a caller-supplied fixed vector set, every CGS2 pass.
//
// Algorithmic scenario (mirrors thick-restart Krylov-Schur per-cycle):
//   * Build the ground-state Ritz vector of an N=6 Heisenberg chain
//     by running the kernel once.
//   * Run the kernel a SECOND time, on the same operator + a different
//     seed, with `aux_ortho_ptrs = { ground_state_ptr }`. Every basis
//     vector the kernel emits must be numerically orthogonal to
//     ground_state, and the resulting tridiagonal's smallest Ritz
//     value must be the FIRST EXCITED energy of the dense reference,
//     not the ground state (because the ground component was projected
//     out of every Krylov vector).
// ----------------------------------------------------------------------------
TEST_CASE("lanczos_kernel `aux_ortho_ptrs` projects out the ground state and "
          "recovers the first excited state (KS restart-cycle idiom)",
          "[krylov][kernel][aux_ortho]") {
    constexpr int N = 6;
    constexpr auto dim = std::size_t{1} << N;
    auto op = build_heisenberg_chain(N, /*J=*/1.0, /*periodic=*/true);
    auto ref = reference_from_operator(*op, dim);
    REQUIRE(ref.eigs.size() >= 2);

    auto& be = default_cpu_backend();
    auto matvec = [&op](const Complex* in, Complex* out, std::size_t n) { op->apply(in, out, n); };

    // Pass 1: get the ground-state Ritz vector. Run lanczos_kernel, then
    // diagonalise the tridiagonal and reconstruct y_0 = sum_j S(j,0)*V_j.
    auto v0_a = random_unit_vector(dim, /*seed=*/0xA110CAU);
    LanczosKernelOptions opts_a;
    opts_a.max_iter = 30;
    opts_a.reorth = ReorthPolicy::FullCGS2;
    opts_a.keep_basis = true;

    auto R_a = lanczos_kernel(be, matvec, dim, v0_a.data(), opts_a);
    const std::size_t M_a = R_a.alpha.size();
    REQUIRE(M_a >= 5);

    // Diagonalise the (M_a x M_a) tridiagonal via Eigen.
    Eigen::MatrixXd T_a = Eigen::MatrixXd::Zero(M_a, M_a);
    for (std::size_t i = 0; i < M_a; ++i) {
        T_a(i, i) = R_a.alpha[i];
        if (i + 1 < M_a) {
            T_a(i, i + 1) = R_a.beta[i + 1];
            T_a(i + 1, i) = R_a.beta[i + 1];
        }
    }
    Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> es_a(T_a);
    REQUIRE(es_a.info() == Eigen::Success);
    INFO("E0 dense=" << ref.eigs[0] << " E0 lanczos=" << es_a.eigenvalues()(0));
    REQUIRE(std::abs(es_a.eigenvalues()(0) - ref.eigs[0]) < 1e-8);

    // Reconstruct y_0 = sum_j S(j,0) * V_j  on host as a plain
    // ComplexVector. (We could use Backend::axpy here too, but a host
    // loop is clearer for a test.)
    std::vector<Complex> y0(dim, Complex{0.0, 0.0});
    for (std::size_t j = 0; j < M_a; ++j) {
        const double sj = es_a.eigenvectors()(static_cast<int>(j), 0);
        const Complex* V_j = R_a.basis[j];
        for (std::size_t i = 0; i < dim; ++i) y0[i] += sj * V_j[i];
    }

    // Sanity: y_0 should be unit norm.
    double y0_norm_sq = 0.0;
    for (const auto& z : y0) y0_norm_sq += std::norm(z);
    REQUIRE(std::abs(std::sqrt(y0_norm_sq) - 1.0) < 1e-8);

    // Pass 2: run lanczos_kernel from a DIFFERENT seed, with
    // aux_ortho_ptrs = { y0.data() }. Per the kernel's documented
    // contract, the caller must pre-orthogonalise v0 against the aux
    // set; the kernel then keeps every subsequent V_j orthogonal to
    // both V_0 AND the aux set via CGS2. Mirror KS's pre-step here.
    auto v0_b = random_unit_vector(dim, /*seed=*/0xB055AU);
    {
        // Twice-is-enough projection of v0 against y0, then renorm.
        for (int pass = 0; pass < 2; ++pass) {
            const Complex c = be.dot(y0.data(), v0_b.data(), dim);
            for (std::size_t i = 0; i < dim; ++i) v0_b[i] -= c * y0[i];
        }
        double n2 = 0.0;
        for (const auto& z : v0_b) n2 += std::norm(z);
        const double s = 1.0 / std::sqrt(n2);
        for (auto& z : v0_b) z *= s;
    }

    LanczosKernelOptions opts_b;
    opts_b.max_iter = 30;
    opts_b.reorth = ReorthPolicy::FullCGS2;
    opts_b.keep_basis = true;
    opts_b.aux_ortho_ptrs = {y0.data()};

    auto R_b = lanczos_kernel(be, matvec, dim, v0_b.data(), opts_b);
    const std::size_t M_b = R_b.alpha.size();
    REQUIRE(M_b >= 5);

    // Basis-to-y0 orthogonality. CGS2-quality projection gives ~1e-12
    // for the basis vectors V_1..V_{M-1} that the kernel built; V_0 was
    // hand-projected by the caller above. We check ALL of them now.
    double max_overlap = 0.0;
    for (std::size_t j = 0; j < M_b; ++j) {
        const Complex c = be.dot(y0.data(), R_b.basis[j], dim);
        max_overlap = std::max(max_overlap, std::abs(c));
    }
    INFO("max |<y0, V_j>| after aux_ortho_ptrs projection: " << max_overlap);
    REQUIRE(max_overlap < 1e-10);

    // Diagonalise the new tridiagonal. With the ground state projected
    // out of every Krylov vector, the smallest Ritz value should be the
    // FIRST EXCITED energy of the dense spectrum.
    Eigen::MatrixXd T_b = Eigen::MatrixXd::Zero(M_b, M_b);
    for (std::size_t i = 0; i < M_b; ++i) {
        T_b(i, i) = R_b.alpha[i];
        if (i + 1 < M_b) {
            T_b(i, i + 1) = R_b.beta[i + 1];
            T_b(i + 1, i) = R_b.beta[i + 1];
        }
    }
    Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> es_b(T_b);
    REQUIRE(es_b.info() == Eigen::Success);
    INFO("E0 (deflated kernel) = " << es_b.eigenvalues()(0) << "  E1 (dense ref)   = " << ref.eigs[1]
                                   << "  E0 (dense ref)   = " << ref.eigs[0]);
    REQUIRE(std::abs(es_b.eigenvalues()(0) - ref.eigs[1]) < 1e-7);
    // The smallest Ritz value must NOT be the ground state; the
    // dense E0/E1 gap on N=6 PBC Heisenberg is well above the
    // numerical tolerance.
    REQUIRE(std::abs(es_b.eigenvalues()(0) - ref.eigs[0]) > std::abs(ref.eigs[1] - ref.eigs[0]) - 1e-8);
}

// ----------------------------------------------------------------------------
// Test: `convergence_check` callback fires at the documented cadence
// and short-circuits the run when it returns `true`.
//
// `LanczosKernelOptions::convergence_check` is the kernel's early-exit
// hook — when set, the kernel calls it every
// `convergence_check_interval` iterations with the current
// (alpha, beta) tridiagonal. Returning `true` terminates the loop
// without consuming the rest of `max_iter`. The block lanes wire their Paige gate
// through it. Without a unit test the callback can rot silently.
//
// Two sections:
//   1. A counting probe verifies the callback fires at exactly
//      `convergence_check_interval` cadence (every 5 iterations
//      here), with the correct alpha/beta sizes at each call. The
//      probe always returns `false`, so the run consumes the full
//      `max_iter`.
//   2. A Paige-bound check on the lowest Ritz value (tridiag_eig) on a
//      6-site PBC Heisenberg chain converges to E_0 in ~10-20 iterations; with
//      `max_iter = 200` the run should exit FAR before that cap. We
//      pin (a) `iters_done < max_iter`, (b) the converged E_0
//      matches the dense reference, and (c) the basis size equals
//      the iteration count (no off-by-one between the early-exit
//      decision and the basis-storage bookkeeping).
// ----------------------------------------------------------------------------
TEST_CASE("lanczos_kernel `convergence_check` fires on cadence and "
          "short-circuits when satisfied",
          "[krylov][kernel][convergence_check]") {
    constexpr int N = 6;
    constexpr auto dim = std::size_t{1} << N;
    auto op = build_heisenberg_chain(N, /*J=*/1.0, /*periodic=*/true);
    auto ref = reference_from_operator(*op, dim);

    auto& be = default_cpu_backend();
    auto matvec = [&op](const Complex* in, Complex* out, std::size_t n) { op->apply(in, out, n); };
    auto v0 = random_unit_vector(dim, /*seed=*/0xC0DECAFEU);

    SECTION("counting probe fires every `interval` iterations") {
        struct Probe {
            std::size_t calls = 0;
            std::vector<std::size_t> alpha_sizes_at_call;
            std::vector<std::size_t> beta_sizes_at_call;
        };
        Probe probe;

        LanczosKernelOptions opts;
        opts.max_iter = 22;
        opts.reorth = ReorthPolicy::FullCGS2;
        opts.keep_basis = true;
        opts.convergence_check_interval = 5;
        opts.convergence_check = [&probe](const std::vector<double>& a, const std::vector<double>& b) {
            probe.calls++;
            probe.alpha_sizes_at_call.push_back(a.size());
            probe.beta_sizes_at_call.push_back(b.size());
            return false;  // never short-circuit
        };

        auto R = lanczos_kernel(be, matvec, dim, v0.data(), opts);

        REQUIRE(R.iters_done == 22);
        // With interval=5 and 22 iterations, the kernel calls the
        // probe at iters j = 4, 9, 14, 19 (i.e. (j+1) % 5 == 0).
        REQUIRE(probe.calls == 4);
        // At call j the kernel has just pushed alpha[j] and beta[j+1],
        // so alpha.size() == j + 1 and beta.size() == j + 2 (with
        // beta[0] preloaded).
        REQUIRE(probe.alpha_sizes_at_call == std::vector<std::size_t>{5, 10, 15, 20});
        REQUIRE(probe.beta_sizes_at_call == std::vector<std::size_t>{6, 11, 16, 21});
    }

    SECTION("a Paige-bound check on the lowest Ritz value exits before max_iter") {
        LanczosKernelOptions opts;
        opts.max_iter = 200;
        opts.reorth = ReorthPolicy::FullCGS2;
        opts.keep_basis = true;
        opts.convergence_check_interval = 5;
        opts.convergence_check = [](const std::vector<double>& a, const std::vector<double>& b) {
            const std::size_t m = a.size();
            const auto t = ed::krylov::tridiag_eig(a, b, m, /*vectors=*/true);
            return std::abs(b[m]) * std::abs(t.z(m - 1, 0)) < 1e-8 * std::max(1.0, std::abs(t.values[0]));
        };

        auto R = lanczos_kernel(be, matvec, dim, v0.data(), opts);

        // Early exit must have fired well below the cap.
        INFO("iters_done=" << R.iters_done << " (cap=" << opts.max_iter << ")");
        REQUIRE(R.iters_done < opts.max_iter);
        REQUIRE(R.iters_done >= 5);                 // at least one cadence hit
        REQUIRE(R.basis.size() == R.iters_done);    // no off-by-one

        // Pin E_0 against the dense reference. Lanczos with full CGS2 reorth on a 6-site PBC
        // chain converges E_0 to better than 1e-10 within 30 iterations; we ask for 1e-8 to
        // match the callback's bound.
        const auto t = ed::krylov::tridiag_eig(R.alpha, R.beta, R.alpha.size(), /*vectors=*/false);
        INFO("E_0 (lanczos, early-exit) = " << t.values[0] << "  E_0 (dense)         = " << ref.eigs.front());
        REQUIRE(std::abs(t.values[0] - ref.eigs.front()) < 1e-8);
    }
}

// ----------------------------------------------------------------------------
// Test 5: Rejection of zero initial vector and missing keep_basis.
// ----------------------------------------------------------------------------
TEST_CASE("unified Lanczos kernel rejects misuse", "[krylov][kernel][edge]") {
    auto& be = default_cpu_backend();
    auto matvec = [](const Complex*, Complex*, std::size_t) {};

    SECTION("zero initial vector") {
        std::vector<Complex> v0(8, Complex{0, 0});
        LanczosKernelOptions opts;
        opts.max_iter = 4;
        opts.reorth = ReorthPolicy::FullCGS2;
        opts.keep_basis = true;
        REQUIRE_THROWS_AS(lanczos_kernel(be, matvec, 8, v0.data(), opts), std::invalid_argument);
    }

    SECTION("reorth requested without keep_basis") {
        std::vector<Complex> v0(8, Complex{1.0, 0.0});
        LanczosKernelOptions opts;
        opts.max_iter = 4;
        opts.reorth = ReorthPolicy::FullCGS2;
        opts.keep_basis = false;
        REQUIRE_THROWS_AS(lanczos_kernel(be, matvec, 8, v0.data(), opts), std::invalid_argument);
    }
}

// -----------------------------------------------------------------------------
// LocalDGKS3 reorthogonalization (moved from test_minimalist_collapse).
// -----------------------------------------------------------------------------
TEST_CASE("lanczos_kernel converges under LocalDGKS3 reorth policy", "[lanczos][reorth][local_dgks3]") {
    constexpr std::uint64_t N = 4;
    auto H = build_heisenberg_chain(N, /*J=*/1.0, /*periodic=*/true);
    const std::size_t dim = static_cast<std::size_t>(1ull << N);

    ed::matvec::CpuBackend be;
    auto matvec = H->bind<ed::matvec::CpuBackend>();
    REQUIRE(matvec);

    std::mt19937_64 rng(0xC0FFEEull);
    std::uniform_real_distribution<double> dist(-1.0, 1.0);
    std::vector<Complex> seed(dim);
    for (auto& z : seed) z = Complex{dist(rng), dist(rng)};

    LanczosKernelOptions opts;
    opts.max_iter = 12;
    opts.reorth = ReorthPolicy::LocalDGKS3;
    opts.keep_basis = false;

    auto res = lanczos_kernel(be, matvec, dim, seed.data(), opts);

    // A non-trivial run with a well-formed tridiagonal.
    REQUIRE(res.iters_done >= 4u);
    REQUIRE(res.alpha.size() == res.iters_done);
    REQUIRE(res.beta.size() == res.iters_done + 1);
    for (auto a : res.alpha) REQUIRE(std::isfinite(a));
    for (auto b : res.beta) {
        REQUIRE(std::isfinite(b));
        REQUIRE(b >= 0.0);
    }
}

// -----------------------------------------------------------------------------
// tridiag_eig: the one tridiagonal eigensolve, in lanczos_kernel's convention.
// -----------------------------------------------------------------------------
TEST_CASE("tridiag_eig solves the Lanczos tridiagonal", "[krylov][tridiag]") {
    std::mt19937_64 rng(0x7D1A6ull);
    std::uniform_real_distribution<double> dist(-1.0, 1.0);
    const std::size_t m = 9;
    std::vector<double> alpha(m), beta(m + 1);
    for (auto& a : alpha) a = dist(rng);
    for (auto& b : beta) b = dist(rng);   // beta[0] and beta[m] lie outside the m x m block

    Eigen::MatrixXd T = Eigen::MatrixXd::Zero(m, m);
    for (std::size_t i = 0; i < m; ++i) {
        T(i, i) = alpha[i];
        if (i + 1 < m) T(i, i + 1) = T(i + 1, i) = beta[i + 1];
    }
    Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> es(T);

    const auto t = ed::krylov::tridiag_eig(alpha, beta, m, /*vectors=*/true);
    REQUIRE(t.values.size() == m);
    REQUIRE(t.vectors.size() == m * m);
    double wsum = 0.0;
    for (const double w : t.weights()) wsum += w;
    CHECK(std::abs(wsum - 1.0) < 1e-13);
    for (std::size_t j = 0; j < m; ++j) {
        CHECK(std::abs(t.values[j] - es.eigenvalues()(static_cast<Eigen::Index>(j))) < 1e-13);
        Eigen::VectorXd z(m);
        for (std::size_t i = 0; i < m; ++i) z(static_cast<Eigen::Index>(i)) = t.z(i, j);
        CHECK((T * z - t.values[j] * z).norm() < 1e-13);
    }

    const auto v = ed::krylov::tridiag_eig(alpha, beta, m, /*vectors=*/false);
    REQUIRE(v.vectors.empty());
    for (std::size_t j = 0; j < m; ++j) CHECK(std::abs(v.values[j] - t.values[j]) < 1e-13);

    // A leading block: the first 4 steps only.
    const auto lead = ed::krylov::tridiag_eig(alpha, beta, 4, /*vectors=*/false);
    Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> e4(T.topLeftCorner(4, 4));
    for (std::size_t j = 0; j < 4; ++j)
        CHECK(std::abs(lead.values[j] - e4.eigenvalues()(static_cast<Eigen::Index>(j))) < 1e-13);

    CHECK(ed::krylov::tridiag_eig(alpha, beta, 0, true).values.empty());
    const auto one = ed::krylov::tridiag_eig(alpha, beta, 1, true);
    CHECK(one.values[0] == alpha[0]);
    CHECK(std::abs(one.weights()[0] - 1.0) < 1e-15);

    alpha[3] = std::nan("");
    CHECK_THROWS_AS(ed::krylov::tridiag_eig(alpha, beta, m, true), ed::ConvergenceError);
}

// tridiag_ends: the gates' O(m) form must read what tridiag_eig reads, also when the lowest pair
// has converged (decaying trailing couplings: a tiny last component, the Paige regime).
TEST_CASE("tridiag_ends matches tridiag_eig at the ends of the spectrum", "[krylov][tridiag]") {
    std::mt19937_64 rng(0x3E4D5ull);
    std::uniform_real_distribution<double> dist(-1.0, 1.0);
    for (const std::size_t m : {std::size_t{1}, std::size_t{2}, std::size_t{5}, std::size_t{40}, std::size_t{200}}) {
        for (int trial = 0; trial < 6; ++trial) {
            INFO("m " << m << " trial " << trial);
            std::vector<double> alpha(m), beta(m + 1);
            for (auto& a : alpha) a = dist(rng);
            for (auto& b : beta) b = 0.05 + std::abs(dist(rng));
            if (trial % 2)   // Lanczos-like: the couplings decay past the middle
                for (std::size_t i = m / 2; i <= m; ++i) beta[i] *= std::pow(0.6, static_cast<double>(i - m / 2));
            const auto full = ed::krylov::tridiag_eig(alpha, beta, m, /*vectors=*/true);
            const std::size_t c = std::min<std::size_t>(4, m);
            const auto ends = ed::krylov::tridiag_ends(alpha, beta, m, c);
            REQUIRE(ends.values.size() == c);
            REQUIRE(ends.vectors.size() == m * c);
            CHECK(std::abs(ends.top - full.values[m - 1]) < 1e-13);
            for (std::size_t j = 0; j < c; ++j) {
                CHECK(std::abs(ends.values[j] - full.values[j]) < 1e-13);
                for (std::size_t i = 0; i < m; ++i)
                    CHECK(std::abs(std::abs(ends.z(i, j)) - std::abs(full.z(i, j))) < 1e-10);
                // The Paige bound the gates compare with their thresholds.
                const double bound_full = beta[m] * std::abs(full.z(m - 1, j));
                const double bound_ends = beta[m] * std::abs(ends.z(m - 1, j));
                CHECK(std::abs(bound_ends - bound_full) <= 1e-10 * bound_full + 1e-13); // the gates judge >= 1e-9 scale
            }
        }
    }
    std::vector<double> alpha{0.1, 0.2, std::nan("")}, beta{0.0, 0.5, 0.5, 0.5};
    CHECK_THROWS_AS(ed::krylov::tridiag_ends(alpha, beta, 3, 1), ed::ConvergenceError);
    CHECK(ed::krylov::tridiag_ends(alpha, beta, 0, 1).values.empty());
}

// The real host backend (P6.4): Lanczos and Krylov-Schur on a real symmetric matrix through
// BasicCpuBackend<double> agree with the complex backend on the same matrix and with the dense
// spectrum.
TEST_CASE("BasicCpuBackend<double> runs the Krylov kernels on a real symmetric matrix", "[krylov][real]") {
    const std::size_t n = 300;
    std::mt19937_64 rng(0x5EA1ull);
    std::uniform_real_distribution<double> dist(-1.0, 1.0);
    Eigen::MatrixXd A = Eigen::MatrixXd::Zero(static_cast<Eigen::Index>(n), static_cast<Eigen::Index>(n));
    for (std::size_t i = 0; i < n; ++i) // banded, sparse-ish, symmetric
        for (std::size_t j = i; j < std::min(n, i + 6); ++j) {
            const double a = dist(rng);
            A(static_cast<Eigen::Index>(i), static_cast<Eigen::Index>(j)) = a;
            A(static_cast<Eigen::Index>(j), static_cast<Eigen::Index>(i)) = a;
        }
    Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> es(A);
    const Eigen::MatrixXcd Ac = A.cast<std::complex<double>>();

    ed::matvec::BasicCpuBackend<double> rb;
    ed::matvec::CpuBackend cb;
    auto apply_r = [&](const double* in, double* out, std::size_t m) {
        Eigen::Map<Eigen::VectorXd>(out, static_cast<Eigen::Index>(m)) =
            A * Eigen::Map<const Eigen::VectorXd>(in, static_cast<Eigen::Index>(m));
    };
    auto apply_c = [&](const std::complex<double>* in, std::complex<double>* out, std::size_t m) {
        Eigen::Map<Eigen::VectorXcd>(out, static_cast<Eigen::Index>(m)) =
            Ac * Eigen::Map<const Eigen::VectorXcd>(in, static_cast<Eigen::Index>(m));
    };
    std::vector<double> v0(n);
    for (auto& x : v0) x = dist(rng);
    std::vector<std::complex<double>> v0c(v0.begin(), v0.end());

    // Lanczos, full reorthogonalisation: the same tridiagonal on both backends.
    ed::krylov::LanczosKernelOptionsT<double> ro;
    ro.max_iter = 80;
    ed::krylov::LanczosKernelOptions co;
    co.max_iter = 80;
    const auto lr = ed::krylov::lanczos_kernel(rb, apply_r, n, v0.data(), ro);
    const auto lc = ed::krylov::lanczos_kernel(cb, apply_c, n, v0c.data(), co);
    REQUIRE(lr.alpha.size() == lc.alpha.size());
    for (std::size_t j = 0; j < lr.alpha.size(); ++j) REQUIRE(std::abs(lr.alpha[j] - lc.alpha[j]) < 1e-12);
    const auto tr = ed::krylov::tridiag_eig(lr.alpha, lr.beta, lr.alpha.size(), false);
    REQUIRE(std::abs(tr.values[0] - es.eigenvalues()(0)) < 1e-10);

    // Krylov-Schur, the 5 lowest pairs with vectors.
    ed::krylov::KrylovSchurOptions ko;
    ko.num_eigs = 5;
    ko.max_iter = 200;
    ko.tolerance = 1e-10;
    ko.compute_vectors = true;
    const auto kr = ed::krylov::krylov_schur_kernel(rb, apply_r, n, v0.data(), ko);
    const auto kc = ed::krylov::krylov_schur_kernel(cb, apply_c, n, v0c.data(), ko);
    REQUIRE(kr.converged);
    REQUIRE(kr.eigenvalues.size() == 5);
    std::vector<double> er = kr.eigenvalues, ec = kc.eigenvalues;
    std::sort(er.begin(), er.end());
    std::sort(ec.begin(), ec.end());
    for (std::size_t i = 0; i < 5; ++i) {
        REQUIRE(std::abs(er[i] - es.eigenvalues()(static_cast<Eigen::Index>(i))) < 1e-9);
        REQUIRE(std::abs(er[i] - ec[i]) < 1e-9);
    }
    for (std::size_t i = 0; i < kr.eigenvectors.size(); ++i) {
        const Eigen::Map<const Eigen::VectorXd> x(kr.eigenvectors[i].get(), static_cast<Eigen::Index>(n));
        REQUIRE((A * x - kr.eigenvalues[i] * x).norm() < 1e-8);
    }
}
