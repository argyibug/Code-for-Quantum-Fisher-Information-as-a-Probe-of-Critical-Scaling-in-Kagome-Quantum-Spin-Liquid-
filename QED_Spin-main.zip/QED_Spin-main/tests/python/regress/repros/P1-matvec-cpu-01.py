# AUDIT-ID: P1-matvec-cpu-01
# DEVICE: cpu
# SECONDS: 200
"""Claim: try_group_path (src/solvers/little_group/lg_stars.cpp:135-142) declines the whole star as soon as
any WANTED irrep of the little co-group is 2-dimensional. With no irrep selection every irrep is wanted, so at
Gamma of a C6v triangular torus even the 1-dim (A1, A2, B1, B2) blocks are solved as ProjectedBlockOp
(W^dagger H_k W: serial scatter + full k-sector H_k apply + gather) instead of as a group sector of dimension
|k-sector|/|P|.

Test (5x5 triangular torus, N=25, Heisenberg, n_up=12, translations + C6v given explicitly, flip/TR off):
  discovery: Gamma star, all irreps wanted, ED_SYM_PROFILE=1 -> stderr shows the decline, block labels.
  tA  : only_irrep=[a]      (a = a 1-dim irrep)  -> group-sector path
  tAE : only_irrep=[a, e]   (e = a 2-dim irrep)  -> W path for both
  tE  : only_irrep=[e]                           -> W path
  (tAE - tE) is the cost of the SAME 1-dim block when it rides the W path (setup is shared and cancels).
CONFIRMED when the decline is logged with all irreps wanted, the A-energy agrees between the two paths
(1e-8), and (tAE - tE) >= 3 * tA (tA includes its own setup, so this is conservative).

RESTATED 2026-10-02 (P6 groundwork). P1.2 put every 1-dim irrep on the group-sector path whatever else is
wanted (no decline since 8258057), so the form above can no longer see the claim that remains: a 2-dim irrep
still runs on the isotypic W path, whose block costs far more than a group sector of the same star. Plan
target (P6.3): a 2-dim block within 2.5x the A1 block's time. Now: tA = only_irrep=[a], tE = only_irrep=[e]
(each with its own setup), the A energy still checked on both sides of the old split.
CONFIRMED when tE > 2.5 tA; NOT_REPRODUCED when tE <= 2.5 tA.

RESTATED 2026-10-02 (P6.7 gate 39d45991, cpu variant 62612918): the blocks take a few seconds, so one
call's hiccup read 9.4x where reruns read 0.4-1.3x. tA and tE are each the fastest of three calls.
"""

import json
import os
import subprocess
import sys
import time

L, N_UP = 5, 12


def worker(cfg):
    import qed
    from support.triangular import TriangularTorus

    lat = TriangularTorus(((L, 0), (0, L)))
    N = lat.N
    b = qed.input.HamiltonianBuilder(N)
    b.heisenberg([(i, j) for (i, j, _) in lat.bonds()], J=1.0)
    H = b.to_operator()
    spec = qed.Symmetry(spatial=None, sz=N_UP, spin_flip="off", time_reversal="off").resolve(H)
    A = lat.translation_group()
    spec.abelian = A
    spec.residues = [list(p) for _, p in lat.point_group()]
    idx = {tuple(a): i for i, a in enumerate(A)}
    t1, t2 = lat.momentum_generators()
    spec.only_momentum = [[(idx[tuple(t1)], 1 + 0j), (idx[tuple(t2)], 1 + 0j)]]
    spec.only_irrep = list(cfg["irreps"])
    from qed._verbs import _device

    t0 = time.perf_counter()
    raw = qed._core.sectors.eigs(
        H,
        spec,
        k=1,
        vectors=False,
        dense_max_dim=64,
        allow_partial=True,
        device=_device.resolve("cpu"),
        prune=False,
        window=float(cfg["window"]),
    )
    dt = time.perf_counter() - t0
    levels = [
        dict(
            E=float(l.energy), k0=int(l.k0), irrep=int(l.irrep), irrep_dim=int(l.irrep_dim), block_dim=int(l.block_dim)
        )
        for l in raw.levels
    ]
    print("RESULT " + json.dumps(dict(t=dt, levels=levels)), flush=True)


def run(irreps, window):
    env = dict(os.environ, ED_SYM_PROFILE="1")
    p = subprocess.run(
        [sys.executable, os.path.abspath(__file__), "--worker", json.dumps(dict(irreps=irreps, window=window))],
        env=env,
        capture_output=True,
        text=True,
        timeout=280,
    )
    res = None
    for line in p.stdout.splitlines():
        if line.startswith("RESULT "):
            res = json.loads(line[7:])
    if res is None:
        raise RuntimeError(f"worker rc={p.returncode}: {p.stderr[-800:]}")
    return res, p.stderr


def main():
    try:
        disc, err0 = run([], 1e3)
        declined = "two-dimensional irrep is wanted" in err0
        one = sorted([l for l in disc["levels"] if l["irrep_dim"] == 1], key=lambda l: l["E"])
        two = sorted([l for l in disc["levels"] if l["irrep_dim"] > 1], key=lambda l: l["E"])
        if not one or not two:
            print(f"REPRO: INCONCLUSIVE Gamma star lacks a 1-dim or 2-dim block: {disc['levels']} declined={declined}")
            return
        a, e = one[0], two[0]
        rA = min((run([a["irrep"]], 0.0)[0] for _ in range(3)), key=lambda r: r["t"])
        rAE, errAE = run([a["irrep"], e["irrep"]], 0.0)
        rE = min((run([e["irrep"]], 0.0)[0] for _ in range(3)), key=lambda r: r["t"])
    except Exception as ex:
        print(f"REPRO: INCONCLUSIVE {type(ex).__name__}: {ex}")
        return
    eA_1 = min(l["E"] for l in rA["levels"] if l["irrep"] == a["irrep"])
    eA_2 = min(l["E"] for l in rAE["levels"] if l["irrep"] == a["irrep"])
    print("discovery levels:", disc["levels"])
    print(f"tA={rA['t']:.2f}s tE={rE['t']:.2f}s tAE={rAE['t']:.2f}s")
    ratio = rE["t"] / max(rA["t"], 1e-9)
    key = (
        f"A block dim {a['block_dim']} E block dim {e['block_dim']} tE/tA = {ratio:.1f}x (target <= 2.5x) "
        f"declined_all_irreps={declined} |dE_A|={abs(eA_1 - eA_2):.1e}"
    )
    if abs(eA_1 - eA_2) > 1e-8:
        print(f"REPRO: INCONCLUSIVE the A energy differs between runs {key}")
    elif ratio > 2.5:
        print(f"REPRO: CONFIRMED the 2-dim block costs {key}")
    else:
        print(f"REPRO: NOT_REPRODUCED {key}")


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "--worker":
        worker(json.loads(sys.argv[2]))
    else:
        main()
