"""The grid's models and its dense oracle.

The term vocabulary and the dense matrices are support.oracle's, the models support.models'
(re-exported here: the regress repros and the bench import them from grid.models). Oracle
answers every grid cell from the dense matrix of a model's term list.
"""

from __future__ import annotations

import cmath
import functools
import itertools
import math

import numpy as np

from support.models import (  # noqa: F401
    MODELS,
    Model,
    chain,
    kagome_bq,
    square_ring,
    triangular,
    xyz_chain,
)
from support.oracle import (  # noqa: F401
    Term,
    _apply,
    _expand,
    adjoint,
    apply_perm,
    compose,
    dense,
    dot,
    fourier,
    joint_eigenspace,
    ring,
    scale,
    sparse,
    state_map,
    triple,
)

# ---------------------------------------------------------------------------
# Dense oracle
# ---------------------------------------------------------------------------


def _block_eigh(M, key, real):
    """eigh of a Hermitian M that is block diagonal in the labels ``key`` of the basis states
    (checked exactly), block by block (real arithmetic when M is real); eigenvalues ascending."""
    dim = M.shape[0]
    assert not np.any(M[key[:, None] != key[None, :]]), "matrix is not block diagonal in the given labels"
    E, V = np.zeros(dim), np.zeros((dim, dim), complex)
    col = 0
    for b in np.unique(key):
        idx = np.flatnonzero(key == b)
        Mb = M[np.ix_(idx, idx)]
        e, v = np.linalg.eigh(Mb.real if real else Mb)
        E[col : col + len(idx)] = e
        V[idx, col : col + len(idx)] = v
        col += len(idx)
    order = np.argsort(E, kind="stable")
    return E[order], V[:, order]


def _labels_of(m):
    """Basis-state labels H is block diagonal in: n_up under U(1), its parity under Sz parity."""
    pop = np.array([bin(s).count("1") for s in range(1 << m.N)])
    return pop if m.u1 else (pop % 2 if m.parity else np.zeros_like(pop))


def _terms_key(terms):
    return tuple((complex(c), tuple(ops)) for c, ops in terms)


def _init_key(init):
    """A hashable key for an initial ensemble (see Oracle.lehmann): an eigbasis tuple by identity
    (eigbasis is lru_cached, one object per selection; the memo holds it, so the id stays its
    own), a basis mask by its bytes."""
    if init is None:
        return None
    if isinstance(init, tuple):
        return ("basis", id(init))
    return ("mask", np.asarray(init, bool).tobytes())


@functools.lru_cache(maxsize=None)
def oracle(name):
    m = MODELS[name]
    H = dense(m.terms, m.N)
    assert np.allclose(H, H.conj().T, atol=1e-12), f"{name}: dense H not Hermitian"
    real = not np.any(H.imag)
    E, V = _block_eigh(H, _labels_of(m), real)
    return Oracle(m, H, E, V)


class Oracle:
    def __init__(self, m, H, E, V):
        self.m, self.H, self.E, self.V = m, H, E, V
        dim = 1 << m.N
        self.pop = np.array([bin(s).count("1") for s in range(dim)])
        # A dynamics reference depends on (probe, T, initial ensemble) only, which most symmetry
        # contents share: its small results are memoised (_memoised), and the last pole set is
        # kept, since a cell asks for the same poles in lehmann and in its sum rule.
        self._memo = {}
        self._poles = None

    # -- spectra --------------------------------------------------------
    def block(self, mask):
        idx = np.flatnonzero(mask)
        return np.linalg.eigvalsh(self.H[np.ix_(idx, idx)])

    def spectrum(self, sel=None):
        if sel is None:
            return self.E
        kind, val = sel
        if kind == "n_up":
            return self.block(self.pop == val)
        if kind == "parity":
            return self.block(self.pop % 2 == val)
        if kind == "S":
            return self.spin_block(val)
        if kind == "sub":
            return self.subspace(val)[0]
        raise ValueError(sel)

    # -- symmetry-resolved subspaces (momenta, stars, little-group irreps) ---------
    # A selection is described by permutations only; U_g acts on basis states as
    # support.oracle.state_map (qed's convention). The subspaces are built from projectors over
    # those permutations and H's dense matrix, never from the library's sectors.
    @functools.lru_cache(maxsize=None)
    def _imgs(self, perm):
        return state_map(perm, self.m.N)

    @functools.lru_cache(maxsize=None)
    def conjugation_invariant(self):
        """H commutes with complex conjugation K in the S^z basis: H is real."""
        return not np.any(self.H.imag)

    def time_reversal_invariant(self):
        """H commutes with complex conjugation K (H real) or with the spin time reversal
        Theta = prod_i (i sigma^y_i) K: U|s> = (-1)^{n_up(s)} |s with every bit flipped>,
        Theta H Theta^-1 = U H* U^dagger. Either maps momentum q to -q."""
        if not np.any(self.H.imag):
            return True
        flip = np.arange(1 << self.m.N) ^ ((1 << self.m.N) - 1)
        sign = np.where(self.pop % 2 == 0, 1.0, -1.0)
        UHU = self.H.conj()[np.ix_(flip, flip)] * np.outer(sign[flip], sign[flip])
        return bool(np.allclose(UHU, self.H, atol=1e-12))

    @staticmethod
    def abelian_elements(gens, orders, q):
        """[(element, chi)] of the abelian group generated by ``gens`` (independent, of the given
        orders) for the momentum q: U_T v = exp(-2 pi i q_a / L_a) v on each generator."""
        N = len(gens[0])
        out = []
        for ns in itertools.product(*(range(L) for L in orders)):
            el, chi = tuple(range(N)), 1.0 + 0j
            for g, n, L, qa in zip(gens, ns, orders, q):
                for _ in range(n):
                    el = compose(g, el)
                chi *= cmath.exp(-2j * math.pi * qa * n / L)
            out.append((el, chi))
        assert len({e for e, _ in out}) == len(out), "generators not independent"
        return out

    @functools.lru_cache(maxsize=None)
    def momentum_space(self, elems, chis):
        """Orthonormal basis of the joint eigenspace U_a = chi_a (an abelian group listed whole)."""
        return joint_eigenspace(self.m.N, list(elems), list(chis))

    def _charvec(self, v, elems):
        """(<v|U_a|v>) over the elements, rounded (a momentum's label)."""
        return tuple(
            complex(round(c.real, 6), round(c.imag, 6)) + 0j
            for c in (np.vdot(v, apply_perm(self._imgs(a), v)) for a in elems)
        )

    def _momenta(self, gens, orders):
        """{q: basis} over every momentum of the generated group, with a nonempty space."""
        out = {}
        for q in itertools.product(*(range(L) for L in orders)):
            els = self.abelian_elements(gens, orders, q)
            B = self.momentum_space(tuple(e for e, _ in els), tuple(c for _, c in els))
            if B.shape[1]:
                out[q] = B
        return out

    def _image_momentum(self, B, g, gens, orders):
        """The momentum of U_g applied to the momentum space B."""
        w = apply_perm(self._imgs(g), B[:, 0])
        q = []
        for a, L in zip(gens, orders):
            c = np.vdot(w, apply_perm(self._imgs(a), w))
            q.append(int(round(-cmath.phase(c) / (2 * math.pi) * L)) % L)
        return tuple(q)

    def _irreducible_copies(self, B, little, tol=1e-8):
        """[(E, V, traces)] -- each irreducible copy of the little group in the eigenspaces of H
        inside the momentum space B: its energy, its orthonormal basis V (full basis) and
        {g: tr(U_g on V)} over ``little``. A cluster of degenerate levels is split into copies by
        the eigenspaces of a generic element of the commutant, (1/|G|) sum_g M_g Y M_g^dagger
        with Y random Hermitian (M_g = U_g on the cluster)."""
        E, X = np.linalg.eigh(B.conj().T @ self.H @ B)
        W = B @ X
        rng = np.random.default_rng(12345)
        out, a = [], 0
        for b in range(1, len(E) + 1):
            if b < len(E) and E[b] - E[a] <= tol:
                continue
            V = W[:, a:b]
            M = {g: V.conj().T @ apply_perm(self._imgs(g), V) for g in little}
            w = b - a
            Y = rng.normal(size=(w, w)) + 1j * rng.normal(size=(w, w))
            Y = Y + Y.conj().T
            C = sum(Mg @ Y @ Mg.conj().T for Mg in M.values()) / len(M)
            ev, Z = np.linalg.eigh(C)
            gtol = 1e-7 * (1.0 + np.max(np.abs(ev)))
            s = 0
            for t in range(1, w + 1):
                if t < w and ev[t] - ev[s] <= gtol:
                    continue
                Zi = Z[:, s:t]
                out.append(
                    (float(E[a:b].mean()), V @ Zi, {g: complex(np.trace(Zi.conj().T @ Mg @ Zi)) for g, Mg in M.items()})
                )
                s = t
            a = b
        return out

    @functools.lru_cache(maxsize=None)
    def subspace(self, key):
        """(E, W) of H on a symmetry-resolved subspace, W in the full basis. ``key``:
        ("mom", gens, orders, qs, group, tr): the momenta qs and their stars under the group,
        closed under q -> -q when tr (time reversal folds a star with its reverse);
        ("char", gens, orders, group, R, chi): at every momentum the coset element R fixes (each
        must be its own star), the little-group irreducible copies on which tr U_R = chi;
        ("irrep", elems, chis, chars, group, n_up): in the Sz sector n_up, at the momentum chis
        (over the abelian group listed whole), the copies whose traces match chars ((R, chi)
        pairs), with the copies mapped to every other member of the star."""
        kind = key[0]
        Es, Ws = [], []
        if kind == "mom":
            _, gens, orders, qs, group, tr = key
            spaces = self._momenta(gens, orders)
            want = set()
            for q in qs:
                want |= {self._image_momentum(spaces[q], g, gens, orders) for g in group}
            if tr:  # time reversal closes each star under q -> -q
                want |= {tuple((-a) % L for a, L in zip(q, orders)) for q in want}
            for q in sorted(want):
                B = spaces[q]
                E, X = np.linalg.eigh(B.conj().T @ self.H @ B)
                Es.append(E)
                Ws.append(B @ X)
        elif kind == "char":
            _, gens, orders, group, R, chi = key
            spaces = self._momenta(gens, orders)
            for q, B in spaces.items():
                if self._image_momentum(B, R, gens, orders) != q:
                    continue
                star = {self._image_momentum(B, g, gens, orders) for g in group}
                assert len(star) == 1, f"momentum {q} fixed by R has a star of {len(star)}"
                little = [g for g in group if self._image_momentum(B, g, gens, orders) == q]
                for E, V, tr in self._irreducible_copies(B, little):
                    if abs(tr[R] - chi) < 1e-6:
                        Es.append(np.full(V.shape[1], E))
                        Ws.append(V)
        elif kind == "irrep":
            _, elems, chis, chars, group, n_up = key
            B = self.momentum_space(elems, chis)
            # each column lives on one orbit, hence in one Sz sector
            B = B[:, self.pop[np.argmax(np.abs(B), axis=0)] == n_up]
            k = self._charvec(B[:, 0], elems)
            little = [g for g in group if self._charvec(apply_perm(self._imgs(g), B[:, 0]), elems) == k]
            to_star = {}
            for g in group:  # one group element per star member
                to_star.setdefault(self._charvec(apply_perm(self._imgs(g), B[:, 0]), elems), g)
            for E, V, tr in self._irreducible_copies(B, little):
                if all(R in tr and abs(tr[R] - c) < 1e-6 for R, c in chars):
                    for g in to_star.values():
                        Es.append(np.full(V.shape[1], E))
                        Ws.append(apply_perm(self._imgs(g), V))
        else:
            raise ValueError(key)
        if not Es:
            return np.zeros(0), np.zeros((1 << self.m.N, 0), complex)
        E, W = np.concatenate(Es), np.concatenate(Ws, axis=1)
        order = np.argsort(E, kind="stable")
        return E[order], W[:, order]

    def spin_block(self, S):
        w, U = self.s2_eig()
        P = U[:, np.abs(w - S * (S + 1)) < 1e-6]
        return np.linalg.eigvalsh(P.conj().T @ self.H @ P)

    @functools.lru_cache(maxsize=None)
    def s2_eig(self):
        return _block_eigh(self.s2(), self.pop, real=True)  # S^2 is real and conserves n_up

    @functools.lru_cache(maxsize=None)
    def s2(self):
        N = self.m.N
        t = []
        for i in range(N):
            for j in range(N):
                t += dot(i, j)
        return dense(t, N)

    # -- thermodynamics --------------------------------------------------
    @staticmethod
    def thermo(E, T):
        T = np.asarray(T, float)
        e0 = E.min()
        out = {"E": [], "C": [], "S": [], "F": []}
        for t in T:
            b = 1.0 / t
            w = np.exp(-b * (E - e0))
            Z = w.sum()
            e = (w * E).sum() / Z
            e2 = (w * E * E).sum() / Z
            lnZ = math.log(Z) - b * e0
            out["E"].append(e)
            out["C"].append(b * b * (e2 - e * e))
            out["S"].append(lnZ + b * e)
            out["F"].append(-lnZ / b)
        return {k: np.array(v) for k, v in out.items()}

    # -- dynamics --------------------------------------------------------
    def _memoised(self, key, init, compute):
        if key not in self._memo:
            self._memo[key] = (compute(), init)  # init held: an eigbasis key is its id
        return self._memo[key][0]

    def lehmann(self, obs_terms, omega, eta, T=None, deg_tol=1e-8, init=None):
        """S(omega) = sum_m p_m sum_n |<n|O|m>|^2 L(omega - E_n + E_m), with p_m the ground
        manifold (T=0) or Boltzmann weights over the initial states; ``init`` (a basis mask)
        restricts the initial states to the eigenstates of H inside that block, or is the
        (E, W) eigenbasis of the initial states itself (a spin tower, from ``eigbasis``)."""
        omega = np.asarray(omega, float)

        def compute():
            pos, wt = self.lehmann_poles(obs_terms, T, deg_tol, init)
            om = omega[:, None]
            S = np.zeros(len(omega))
            for a in range(0, len(pos), 1 << 16):  # chunks: 161 x 2^16 doubles at a time
                p, w = pos[None, a : a + (1 << 16)], wt[None, a : a + (1 << 16)]
                S += (w * eta / math.pi / ((om - p) ** 2 + eta**2)).sum(axis=1)
            return S

        key = ("S", _terms_key(obs_terms), omega.tobytes(), eta, T, deg_tol, _init_key(init))
        return self._memoised(key, init, compute).copy()

    def weight_inside(self, obs_terms, lo, hi, eta, T=None, deg_tol=1e-8, init=None):
        """sum over the poles of their weight times the fraction of their Lorentzian (width eta)
        inside [lo, hi]; ``init`` as in lehmann."""

        def compute():
            pos, wt = self.lehmann_poles(obs_terms, T, deg_tol, init)
            inside = (np.arctan((hi - pos) / eta) - np.arctan((lo - pos) / eta)) / math.pi
            return float(np.sum(wt * inside))

        key = ("inside", _terms_key(obs_terms), lo, hi, eta, T, deg_tol, _init_key(init))
        return self._memoised(key, init, compute)

    def lehmann_poles(self, obs_terms, T=None, deg_tol=1e-8, init=None):
        """(positions, weights) of the poles of S(omega): weight p_m |<n|O|m>|^2 at E_n - E_m
        (T > 0) or E_n - E_0 averaged over the ground manifold (T = 0); ``init`` as in lehmann."""
        key = (_terms_key(obs_terms), T, deg_tol, _init_key(init))
        if self._poles is None or self._poles[0] != key:
            Eb, Vi, p = self._initial(T, deg_tol, init)
            live = np.flatnonzero(p > 1e-14)
            # |<n|O|m>|^2 over the initial states that carry weight (at T = 0 the ground
            # manifold): O applied sparse, then one product with V^dagger
            W = np.abs(self.V.conj().T @ (sparse(obs_terms, self.m.N) @ Vi[:, live])) ** 2
            ref = np.full(len(live), Eb[0]) if (T is None or T == 0) else Eb[live]
            pos = (self.E[:, None] - ref[None, :]).ravel()
            wt = (W * p[None, live]).ravel()
            keep = wt > 1e-15 * wt.sum()  # symmetry zeros (roundoff); negligible to the sum
            self._poles = (key, pos[keep], wt[keep], init)  # init held: an eigbasis key is its id
        return self._poles[1], self._poles[2]

    def _initial(self, T, deg_tol, init):
        """(E_m, |m> columns, p_m) of the initial ensemble."""
        if isinstance(init, tuple):
            Eb, Vi = init
        elif init is not None:
            idx = np.flatnonzero(init)
            Eb, Vb = np.linalg.eigh(self.H[np.ix_(idx, idx)])
            Vi = np.zeros((len(self.E), len(Eb)), complex)
            Vi[idx] = Vb
        else:
            Eb, Vi = self.E, self.V
        if T is None or T == 0:
            p = (Eb - Eb[0] < deg_tol).astype(float)
        else:
            p = np.exp(-(Eb - Eb[0]) / T)
        return Eb, Vi, p / p.sum()

    def norm_weight(self, obs_terms, T=None, deg_tol=1e-8, init=None):
        """<O^dagger O> in the initial ensemble, sum_m p_m ||O|m>||^2 (no eigenbasis of H)."""

        def compute():
            Eb, Vi, p = self._initial(T, deg_tol, init)
            live = np.flatnonzero(p > 1e-14)
            OV = sparse(obs_terms, self.m.N) @ Vi[:, live]
            return float((p[live] * np.sum(np.abs(OV) ** 2, axis=0)).sum())

        key = ("norm", _terms_key(obs_terms), T, deg_tol, _init_key(init))
        return self._memoised(key, init, compute)

    def rayleigh(self, vec):
        """(Rayleigh energy, residual ||Hv - Ev||) of a normalised vector."""
        v = np.asarray(vec, complex)
        v = v / np.linalg.norm(v)
        hv = self.H @ v
        e = float(np.vdot(v, hv).real)
        return e, float(np.linalg.norm(hv - e * v))

    def mask(self, sel):
        if sel is None:
            return None
        kind, val = sel
        if kind == "n_up":
            return self.pop == val
        if kind == "parity":
            return self.pop % 2 == val
        raise ValueError(sel)

    # -- expectation values ------------------------------------------------
    @functools.lru_cache(maxsize=None)
    def eigbasis(self, sel):
        """(E, W): eigenpairs of H inside the selection, W in the full basis."""
        if sel is None:
            return self.E, self.V
        if sel[0] == "sub":
            return self.subspace(sel[1])
        if sel[0] == "S":
            w, U = self.s2_eig()
            P = U[:, np.abs(w - sel[1] * (sel[1] + 1)) < 1e-6]
            E, V = np.linalg.eigh(P.conj().T @ self.H @ P)
            return E, P @ V
        idx = np.flatnonzero(self.mask(sel))
        E, V = np.linalg.eigh(self.H[np.ix_(idx, idx)])
        W = np.zeros((len(self.E), len(E)), complex)
        W[idx] = V
        return E, W

    def cluster_pair_traces(self, sel, op_terms, emax, tol=1e-8):
        """[(E, dim, Tr(P_E A_a^dag A_b), Tr(P_E A_a))] over the degenerate clusters of H inside the
        selection up to energy emax (only those columns of the eigenbasis are touched)."""
        E, W = self.eigbasis(sel)
        n = int(np.searchsorted(E, emax + 1e-7, side="right"))
        while n < len(E) and E[n] - E[n - 1] <= tol:
            n += 1  # finish the cluster at the edge
        W = W[:, :n]
        X = np.stack([sparse(t, self.m.N) @ W for t in op_terms])  # (ops, dim, n)
        out, a = [], 0
        for b in range(1, n + 1):
            if b == n or E[b] - E[a] > tol:
                Xc = X[:, :, a:b]
                T = np.einsum("adm,bdm->ab", Xc.conj(), Xc)
                t = np.einsum("dm,adm->a", W[:, a:b].conj(), Xc)
                out.append((float(E[a]), b - a, T, t))
                a = b
        return out

    def thermal_expect(self, sel, obs_list, T):
        """<O>(T) = Tr(e^{-H/T} O) / Z over the selection, one row per operator."""
        E, W = self.eigbasis(sel)
        out = []
        for terms in obs_list:
            d = np.sum(W.conj() * (sparse(terms, self.m.N) @ W), axis=0)
            row = []
            for t in np.asarray(T, float):
                w = np.exp(-(E - E.min()) / t)
                row.append(complex((w * d).sum() / w.sum()))
            out.append(row)
        return np.array(out)

    def cluster_traces(self, sel, obs_terms, tol=1e-8):
        """[(E, dim, Tr(P_E O))] over the degenerate clusters of H inside the selection --
        what any partner choice must reproduce as sum over the cluster of multiplicity x <O>."""
        E, W = self.eigbasis(sel)
        diag = np.sum(W.conj() * (sparse(obs_terms, self.m.N) @ W), axis=0)
        out, a = [], 0
        for b in range(1, len(E) + 1):
            if b == len(E) or E[b] - E[a] > tol:
                out.append((float(E[a]), b - a, complex(diag[a:b].sum())))
                a = b
        return out
