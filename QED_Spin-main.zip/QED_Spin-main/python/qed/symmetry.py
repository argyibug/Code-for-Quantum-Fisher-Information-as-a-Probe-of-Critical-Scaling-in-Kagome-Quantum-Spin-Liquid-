"""Site permutations: the builders and group helpers behind ``Symmetry(spatial=...)``.

A permutation is a ``list[int]`` of length ``num_sites``. It acts on states as
``(U_p s)_i = s_{p[i]}``: site ``i`` of the image carries the spin site ``p[i]`` carried, so an
operator on site ``k`` moves to site ``p^-1(k)`` (``Operator.image``), and
``translation(N, 1)`` (``p[i] = i - 1``) shifts every spin by one site, ``i -> i + 1``.
Composition is ``(a o b)[i] = a[b[i]]`` (``b`` first).

.. code-block:: python

    import qed

    t = qed.symmetry.translation(6, 1)
    r = qed.symmetry.reflection_1d(6)
    G = qed.symmetry.generate_group([t, r])          # D6, 12 elements
    qed.eigs(H, 4, sym=qed.Symmetry(spatial=[t, r]))
"""

from __future__ import annotations

from ._core.symmetry import (  # type: ignore[attr-defined]
    compose,
    generate_group,
    identity,
    order,
    power,
    reflection_1d,
    site_swap,
    translation,
)
from ._groups import split_nonabelian
from ._perm import close_group
from ._verbs.symmetry import irrep_characters_of, momentum_of

__all__ = [
    "close_group",
    "split_nonabelian",
    "identity",
    "compose",
    "power",
    "order",
    "translation",
    "reflection_1d",
    "site_swap",
    "generate_group",
    "momentum_of",
    "irrep_characters_of",
]
